export const environment = {
    production: false,
    dev: true,
    name: 'dev',
    api: 'http://10.9.136.223:61003/',
    ein: '',
    userRole: ''
};
