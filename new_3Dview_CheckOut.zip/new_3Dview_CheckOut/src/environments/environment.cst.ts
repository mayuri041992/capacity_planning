export const environment = {
  production: false,
  name: 'cst',
  api: 'http://10.9.136.224:61008/',
  ein: '',
  userRole: ''
};
