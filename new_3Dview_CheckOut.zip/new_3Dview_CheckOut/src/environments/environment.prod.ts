export const environment = {
  production: true,
  api: 'http://wssrims.rg.vm5.nat.bt.com:61025/',
  ein: '',
  userRole: ''
};
