let srims_sr12_data = {
  "modelData": {
    name: '7750 SR-12',
    backUrl: 'http://bt-srims-stacked-view.bb-test-domain.com',
    lightMode: true,
    layerX: 0.25,
    fontLoading: false,
    fontPath: null,
    mouseXmod: 80,
    verticalPixelAdjust: 0,
    horizontalPixelAdjust: 105,
    clickZOffset: 10,
    hoverHex: '#ffffff',
    cameraZoom: true,
    statusSelectAllActive: true,
    statusSelectAllTitle: 'Select All',
    "stats": {
      "active": false
    },
    "pointLight": {
      "active": true,
      "pointLights": [{
          "color": "white",
          "position": {
            "x": 0,
            "y": 150,
            "z": 700
          },
          "intensity": 1.2
        },
        {
          "color": "white",
          "position": {
            "x": 0,
            "y": 150,
            "z": -700
          },
          "intensity": 1.2
        },
        {
          "color": "white",
          "position": {
            "x": -700,
            "y": 150,
            "z": 0
          },
          "intensity": 1.2
        },
        {
          "color": "white",
          "position": {
            "x": 700,
            "y": 150,
            "z": 0
          },
          "intensity": 1.2
        },
        {
          "color": "white",
          "position": {
            "x": 0,
            "y": 1150,
            "z": 0
          },
          "intensity": 1.2
        }
      ]
    },
    "cameraSettings": {
      "smartCam": true,
      "active": true,
      "distance": 45,
      "minDistance": 1,
      "maxDistance": 10000,
      "minZoom": 1,
      "maxZoom": 10000,
      "rotateSpeed": 0.2,
      "position": {
        "x": 0,
        "y": 50,
        "z": 500
      },
      "lookAt": {
        "x": 0,
        "y": 7,
        "z": -6
      }
    },
    "models": {
      "rotationalOverride": {
        "x": 0,
        "y": 0,
        "z": 0
      },
      "avaliableModels": [{
          "id": "Alcatel 7750SR CORE",
          "gltf": "SR12.gltf"
        },
        {
          "id": "Slot Cover -Level1",
          "gltf": "slotCover.gltf"
        },
        {
          "id": "Slot Cover -Level2",
          "gltf": "Generic_Card_Half_large_screw.gltf"
        },
        {
          "id": "Port",
          "gltf": "port.gltf"
        },

        {
          "id": "Traffic",
          "gltf": "Generic_Card.gltf"
        },
        {
          "id": "Switch",
          "gltf": "Generic_Card_AB.gltf"
        },
        {
          "id": "10GigE",
          "gltf": "Generic_Card_Half.gltf"
        },
        {
          "id": "Slot Cover -Power",
          "gltf": "Power_Cover.gltf"
        },
        {
          "id": "Power",
          "gltf": "Power_Unit.gltf"
        }, {
          "id": "Slot Cover -Fan Tray",
          "gltf": "Fan_Cover.gltf"
        },
        {
          "id": "Fan Tray",
          "gltf": "Fan_Unit.gltf"
        },
        {
          "id": "10GigE SFP",
          "gltf": "SPF.gltf"
        },

        {
          "id": "GigE SFP",
          "gltf": "SPF.gltf"
        },

        {
          "id": "100GigE CFP",
          "gltf": "CPF.gltf"
        }
      ]
    },
    "statusList": [{
        "uniqueName": "free",
        "displayName": "Free",
      },
      {
        "uniqueName": "used",
        "displayName": "Used",
      },
      {
        "uniqueName": "reserved",
        "displayName": "Reserved",
      },
      {
        "uniqueName": "inflight",
        "displayName": "Inflight",
      },
      {
        "uniqueName": "cabled-up",
        "displayName": "Cabled Up",
      },
      {
        "uniqueName": "un-cabled",
        "displayName": "Un-Cabled",

      }
    ],
    "productList": [{
        "uniqueName": "broadband",
        "displayName": "Broadband",
      },
      {
        "uniqueName": "ethernet_Access",
        "displayName": "Ethernet Access",
      },
      {
        "uniqueName": "backhaul",
        "displayName": "Backhaul",
      },
      {
        "uniqueName": "p2pe",
        "displayName": "P2PE",
      },
      {
        "uniqueName": "voice",
        "displayName": "Voice",
      },
      {
        "uniqueName": "infrastructure",
        "displayName": "Infrastructure",
      },
      {
        "uniqueName": "blocked",
        "displayName": "Blocked",
      },
      {
        "uniqueName": "prtc",
        "displayName": "PRTC",
      },
    ],
    "deviceInfo": {
      "siteName": "Epslion Telecommunication Epslion Global Hubs",
      "deviceDetails": [{
          "title": "SNE ID",
          "value": '20963658',
        },
        {
          "title": "DNS Name",
          "value": '20963658@DNS',
        },
        {
          "title": "IP Address",
          "value": '142.6.1.1',
        }, {
          "title": "1141 Code",
          "value": 'YAZNS',
        },
        {
          "title": "Device Usage",
          "value": 'MSE',
        },
        {
          "title": "Device Model",
          "value": '7750-SR-12',
        },
        {
          "title": "Device Type",
          "value": 'Edge Rt',
        }, {
          "title": "Device Version",
          "value": '16.SR.12',
        }, {
          "title": "Node Type",
          "value": 'Metro',
        },
        {
          "title": "Phase Enabled",
          "value": 'Yes',
        },
        {
          "title": "CPM Type",
          "value": 'CPM 5',
        },
        {
          "title": "Market Type",
          "value": 'Market B',
        },
        {
          "title": "Actual Chassis Speed",
          "value": '1 Tbps',
        },
        {
          "title": "Potential Chassis Speed",
          "value": '2 Tbps',
        },
        {
          "title": "1G Free Ports",
          "value": '15',
        },
        {
          "title": "1G Reserved Ports",
          "value": '12',
        },
        {
          "title": "10G Free Ports",
          "value": '16',
        }, {
          "title": "10G Reserved Ports",
          "value": '14',
        }, {
          "title": "Free Slots",
          "value": '4',
        },
        {
          "title": "Used Slots",
          "value": '8',
        },
        {
          "title": "10G Free Ports",
          "value": '6',
        }
      ]
    },
    "defaultInfo": {
      "title": "7750 SR-12:578490",
      "info": {
        "Device": "",
        "Spec Type": "Edge Rt",
        "Spec Name": "7750 SR-12",
        "Spec Version": "(N/A)",
        "Usage": "Edge Ethernet Switch",
        "Type": "Device",
        "Inventory Status": "Installed",
        "Operational Status": "Operational",
        "Created Date": "7/7/2008",
        "Installed Date": "2008-10-15 13:29:56.0",
        "Last Modified Date": "20/9/2019",
        "DeviceManager": "2912",
        "DNSName": "acc-aln1-lo1.dd-b.21cn-infra.bt.com",
        "DNSNameAlias": "acc-aln1-lo1.dd-b.21cn-infra.bt.com",
        "IPValue": "217.35.217.207",
        "Standby NE id": "",
        "Parent POSI Location": "",
        "Network Product": "",
        "Site Type": "",
        "SNE Sofware Version": "",
        "Network": "21CN",
        "Worker Standby Indicator": "Worker",
        "SyncE Capable": "",
        "NouName": "",
        "Chassis": "",
        "Chassis Spec Name": "Alcatel 7750SR CORE",
        "Chassis Spec Version": "(N/A)",
        "Manufacturer": "ALN",
        "MTOSIName": "/shelf=1",
        "Chassis Created Date": "7/7/2008",
        "Chassis Last Modified Date": "19/9/2019",
        "Chassis Inventory Status": "",
        "Slots Count": 17,
        "Slots Used": 1,
        "Total Ports": 651,
        "Available Ports": 60,
        "Reserved Ports": 97,
        "Faulty Ports": 0,
        "Ports with Connectivity": 591,
        "Locality": "BPZ/A"
      }
    },
    "childReferenceMap": [{
      "id": "Alcatel 7750SR CORE",
      "renderInfo": {
        "info": {
          "Spec Name": "Alcatel 7750SR CORE",
          "Spec Version": "(N/A)",
          "Manufacturer": "ALN",
          "MTOSIName": "/shelf=1",
          "Created Date": "7/7/2008",
          "Last Modified Date": "19/9/2019",
          "Inventory Status": "Installed",
          "Type": "Chassis",
          "Locality": "BPZ/A",
          "DeviceManager": "2912",
          "DNSName": "acc-aln1-lo1.dd-b.21cn-infra.bt.com",
          "DNSNameAlias": "acc-aln1-lo1.dd-b.21cn-infra.bt.com",
          "IPValue": "217.35.217.207"
        },
        "model": {
          "hasStatus": true,
          "emissive": 0.1,
          "name": "CORE",
          "hasInteraction": true,
          "id": "578490:/shelf=1:CORE",
          "reflectivity": 10,
          "opacity": 1,
          "status": null
        },
        "sizing": {
          "depth": 620.0,
          "width": 450.5,
          "height": 609.5
        },
        "positioning": {
          "x": 0.0,
          "y": 0.0,
          "z": 0.0
        }
      },
      "childReferenceMap": [{
        "id": "578490:/shelf=1/slot=1",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=1",
            "Created Date": "20/9/2019",
            "Last Modified Date": "27/8/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=1",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=1",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 18.6,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "I/O Module",
              "Spec Type": "Traffic",
              "Installed Version": "(Rev C - v3)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=1",
              "Level": "Level1",
              "Created Date": "7/7/2008",
              "Last Modified Date": "27/8/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:I/O Module:ALN:(Rev C - v3)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=1",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=1/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=1/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=1/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=1/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": "free",
                "productName": "broadband",
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 0.333,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "FastE",
              "renderInfo": {
                "info": {
                  "Spec Name": "FastE [60] Elect",
                  "Spec Type": "FastE",
                  "Installed Version": "(N/A)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=1/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "7/7/2008",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "Ethernet Access",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "FastE:FastE [60] Elect:ALN:(N/A)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=1/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": "free",
                  "productName": "broadband",
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/1",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=1",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": "used",
                    "productName": "voice",
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 3.161,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/2",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=2",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": "used",
                    "productName": "voice",
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 10.323,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/3",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=3",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": "used",
                    "productName": "voice",
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 17.484,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/4",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=4",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": "inflight",
                    "productName": "p2pe",
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 24.645,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/5",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=5",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": "inflight",
                    "productName": "p2pe",
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 31.806,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/6",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=6",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": "inflight",
                    "productName": "p2pe",
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 38.968,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/7",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=7",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": "inflight",
                    "productName": "p2pe",
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 46.129,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/8",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=8",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 53.29,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/9",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=9",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 60.452,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/10",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=10",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 67.613,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/11",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=11",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=11",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=11",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 74.774,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/12",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=12",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=12",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=12",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 81.935,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/13",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=13",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=13",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=13",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 89.097,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/14",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=14",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=14",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=14",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 96.258,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/15",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=15",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=15",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=15",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 103.419,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/16",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=16",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=16",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=16",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 110.581,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/17",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=17",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=17",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=17",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 117.742,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/18",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=18",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=18",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=18",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 124.903,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/19",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=19",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=19",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=19",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 132.065,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/20",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=20",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=20",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=20",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 139.226,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/21",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=21",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=21",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=21",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 146.387,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/22",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=22",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=22",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=22",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 153.548,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/23",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=23",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=23",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=23",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 160.71,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/24",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=24",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=24",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=24",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 167.871,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/25",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=25",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=25",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=25",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 175.032,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/26",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=26",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=26",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=26",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 182.194,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/27",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=27",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=27",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=27",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 189.355,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/28",
                    "Port Signal Type": "Ethernet",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=28",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=28",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "Ethernet LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=28",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 196.516,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/29",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=29",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=29",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=29",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 203.677,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/30",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=30",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=30",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=30",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 210.839,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/31",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=31",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=31",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=31",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 3.161,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/32",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=32",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=32",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=32",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 10.323,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/33",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=33",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=33",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=33",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 17.484,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/34",
                    "Port Signal Type": "Ethernet",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=34",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=34",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "Ethernet LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=34",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 24.645,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/35",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=35",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=35",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=35",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 31.806,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/36",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=36",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=36",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=36",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 38.968,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/37",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=37",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=37",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=37",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 46.129,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/38",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=38",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=38",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=38",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 53.29,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/39",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=39",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=39",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=39",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 60.452,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/40",
                    "Port Signal Type": "Ethernet",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=40",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=40",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "Ethernet LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=40",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 67.613,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/41",
                    "Port Signal Type": "Ethernet",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=41",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=41",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "Ethernet LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=41",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 74.774,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/42",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=42",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=42",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=42",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 81.935,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/43",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=43",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=43",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=43",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 89.097,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/44",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=44",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=44",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=44",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 96.258,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/45",
                    "Port Signal Type": "Ethernet",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=45",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=45",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "Ethernet LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=45",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 103.419,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/46",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=46",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=46",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=46",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 110.581,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/47",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=47",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=47",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=47",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 117.742,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/48",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=48",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=48",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=48",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 124.903,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/49",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=49",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=49",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=49",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 132.065,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/50",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=50",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=50",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=50",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 139.226,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/51",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=51",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=51",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=51",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 146.387,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/52",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=52",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=52",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=52",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 153.548,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/53",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=53",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=53",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=53",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 160.71,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/54",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=54",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=54",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=54",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 167.871,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/55",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=55",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=55",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=55",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 175.032,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/56",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=56",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=56",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=56",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 182.194,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/57",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=57",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=57",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=57",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 189.355,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/58",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=58",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=58",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=58",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 196.516,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/59",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=59",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=59",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=59",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 203.677,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "1/1/60",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=1/port=60",
                    "Id": "578490:/shelf=1/slot=1/sub_slot=1/port=60",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=1/port=60",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 210.839,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }]
            }]
          }, {
            "id": "578490:/shelf=1/slot=1/sub_slot=2",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=1/sub_slot=2",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=1/sub_slot=2",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=1/sub_slot=2",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 218.667,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "20-port GE MDA-XP",
                  "Spec Type": "GigE",
                  "Installed Version": "(N/A)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=1/sub_slot=2",
                  "Level": "Level2",
                  "Created Date": "30/4/2019",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "Ethernet Access",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "GigE:20-port GE MDA-XP:ALN:(N/A)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=1/sub_slot=2",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/1/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/2/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/3/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/4/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/5/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/6/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=7",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=7",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=7",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/7/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=7/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=7/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=7/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=8",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=8",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=8",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/8/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=8/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=8/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=8/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=9",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=9",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=9",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/9/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=9/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=9/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=9/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=10",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=10",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=10",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/10/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=10/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=10/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=10/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=11",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=11",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=11",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=11",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=11",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=11",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/11/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=11/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=11/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=11/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=12",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=12",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=12",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=12",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=12",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=12",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/12/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=12/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=12/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=12/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=13",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=13",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=13",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=13",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=13",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=13",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/13/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=13/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=13/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=13/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=14",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=14",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=14",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=14",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=14",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=14",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/14/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=14/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=14/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=14/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=15",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=15",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=15",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=15",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=15",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=15",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/15/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=15/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=15/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=15/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=16",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=16",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=16",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=16",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=16",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=16",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/16/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=16/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=16/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=16/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=17",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=17",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=17",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=17",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=17",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=17",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/17/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=17/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=17/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=17/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=18",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=18",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=18",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=18",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=18",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=18",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/18/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=18/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=18/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=18/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=19",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=19",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=19",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=19",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=19",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=19",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/19/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=19/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=19/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=19/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=20",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=20",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=1/sub_slot=2/subsub_slot=20",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=20",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=20",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=20",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "1/2/20/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=1/sub_slot=2/subsub_slot=20/port=1",
                        "Id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=20/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=1/sub_slot=2/subsub_slot=20/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=2",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=2",
            "Created Date": "20/9/2019",
            "Last Modified Date": "27/8/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=2",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=2",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 53.05,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "I/O Module",
              "Spec Type": "Traffic",
              "Installed Version": "(Rev C - v3)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=2",
              "Level": "Level1",
              "Created Date": "7/7/2008",
              "Last Modified Date": "27/8/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:I/O Module:ALN:(Rev C - v3)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=2",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=2/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=2/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=2/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=2/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 0.333,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "FastE",
              "renderInfo": {
                "info": {
                  "Spec Name": "FastE [60] Elect",
                  "Spec Type": "FastE",
                  "Installed Version": "(N/A)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=2/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "7/7/2008",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "Ethernet Access",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "FastE:FastE [60] Elect:ALN:(N/A)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=2/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/1",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=1",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 3.161,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/2",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=2",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 10.323,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/3",
                    "Port Signal Type": "Ethernet",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=3",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "Ethernet LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 17.484,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/4",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=4",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 24.645,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/5",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=5",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 31.806,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/6",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=6",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 38.968,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/7",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=7",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 46.129,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/8",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=8",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 53.29,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/9",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=9",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 60.452,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/10",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=10",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 67.613,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/11",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=11",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=11",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=11",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 74.774,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/12",
                    "Port Signal Type": "Ethernet",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=12",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=12",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "Ethernet LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=12",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 81.935,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/13",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=13",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=13",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=13",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 89.097,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/14",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=14",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=14",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=14",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 96.258,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/15",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=15",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=15",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=15",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 103.419,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/16",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=16",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=16",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=16",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 110.581,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/17",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=17",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=17",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=17",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 117.742,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/18",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=18",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=18",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=18",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 124.903,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/19",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=19",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=19",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=19",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 132.065,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/20",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=20",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=20",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=20",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 139.226,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/21",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=21",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=21",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=21",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 146.387,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/22",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=22",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=22",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=22",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 153.548,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/23",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=23",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=23",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=23",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 160.71,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/24",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=24",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=24",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=24",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 167.871,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/25",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=25",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=25",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=25",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 175.032,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/26",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=26",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=26",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=26",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 182.194,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/27",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=27",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=27",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=27",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 189.355,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/28",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=28",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=28",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=28",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 196.516,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/29",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=29",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=29",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=29",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 203.677,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/30",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=30",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=30",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=30",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 210.839,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/31",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=31",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=31",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=31",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 3.161,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/32",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=32",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=32",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=32",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 10.323,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/33",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=33",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=33",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=33",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 17.484,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/34",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=34",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=34",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=34",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 24.645,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/35",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=35",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=35",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=35",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 31.806,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/36",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=36",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=36",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=36",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 38.968,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/37",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=37",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=37",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=37",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 46.129,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/38",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=38",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=38",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=38",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 53.29,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/39",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=39",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=39",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=39",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 60.452,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/40",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=40",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=40",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=40",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 67.613,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/41",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=41",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=41",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=41",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 74.774,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/42",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=42",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=42",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=42",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 81.935,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/43",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=43",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=43",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=43",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 89.097,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/44",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=44",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=44",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=44",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 96.258,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/45",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=45",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=45",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=45",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 103.419,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/46",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=46",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=46",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=46",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 110.581,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/47",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=47",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=47",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=47",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 117.742,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/48",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=48",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=48",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=48",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 124.903,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/49",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=49",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=49",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=49",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 132.065,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/50",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=50",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=50",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=50",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 139.226,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/51",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=51",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=51",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=51",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 146.387,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/52",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=52",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=52",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=52",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 153.548,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/53",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=53",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=53",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=53",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 160.71,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/54",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=54",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=54",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=54",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 167.871,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/55",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=55",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=55",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=55",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 175.032,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/56",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=56",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=56",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=56",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 182.194,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/57",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=57",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=57",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=57",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 189.355,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/58",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=58",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=58",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=58",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 196.516,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/59",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=59",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=59",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=59",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 203.677,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "2/1/60",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=1/port=60",
                    "Id": "578490:/shelf=1/slot=2/sub_slot=1/port=60",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=1/port=60",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 210.839,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }]
            }]
          }, {
            "id": "578490:/shelf=1/slot=2/sub_slot=2",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=2/sub_slot=2",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=2/sub_slot=2",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=2/sub_slot=2",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 218.667,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "20-port GE MDA-XP",
                  "Spec Type": "GigE",
                  "Installed Version": "(N/A)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=2/sub_slot=2",
                  "Level": "Level2",
                  "Created Date": "30/4/2019",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "Ethernet Access",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "GigE:20-port GE MDA-XP:ALN:(N/A)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=2/sub_slot=2",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/1/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/2/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/3/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/4/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#800080",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/5/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#800080",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/6/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#800080",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=7",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=7",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=7",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/7/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=7/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=7/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#800080",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=7/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=8",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=8",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=8",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/8/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=8/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=8/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#32CD32",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=8/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=9",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=9",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=9",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/9/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=9/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=9/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=9/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=10",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 2.667,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=10",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=10",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/10/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=10/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=10/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#800080",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=10/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=11",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=11",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=11",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=11",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=11",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=11",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/11/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=11/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=11/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=11/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=12",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=12",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=12",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=12",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=12",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=12",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/12/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=12/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=12/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=12/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=13",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=13",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=13",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=13",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=13",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=13",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/13/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=13/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=13/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=13/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=14",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=14",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=14",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=14",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=14",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=14",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/14/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=14/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=14/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=14/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=15",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=15",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=15",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=15",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=15",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=15",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/15/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=15/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=15/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=15/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=16",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=16",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=16",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=16",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=16",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=16",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/16/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=16/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=16/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=16/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=17",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=17",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=17",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=17",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=17",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=17",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/17/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=17/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=17/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=17/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=18",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=18",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=18",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=18",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=18",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=18",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/18/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=18/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=18/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=18/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=19",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=19",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=19",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=19",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=19",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=19",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/19/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=19/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=19/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=19/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=20",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=20",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=2/sub_slot=2/subsub_slot=20",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=20",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 18.333,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=20",
                      "Level": "Level3",
                      "Created Date": "30/4/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=20",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "2/2/20/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=2/sub_slot=2/subsub_slot=20/port=1",
                        "Id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=20/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=2/sub_slot=2/subsub_slot=20/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }]
        }]
      }, {
        "id": "Slot Cover -Level1",
        "renderInfo": {
          "info": {
            "MTOSIName": "",
            "Created Date": "",
            "Last Modified Date": "",
            "Type": ""
          },
          "model": {
            "color": "",
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 87.5,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": []
      }, {
        "id": "Slot Cover -Level1",
        "renderInfo": {
          "info": {
            "MTOSIName": "",
            "Created Date": "",
            "Last Modified Date": "",
            "Type": ""
          },
          "model": {
            "color": "",
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 121.95,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": []
      }, {
        "id": "578490:/shelf=1/slot=5",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=5",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=5",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=5",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 156.4,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "10GE Multicore IMM Module",
              "Spec Type": "Traffic",
              "Installed Version": "(12Pt Lic)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=5",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:10GE Multicore IMM Module:ALN:(12Pt Lic)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=5",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=5/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=5/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "17/9/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=5/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=5/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 437.25
              },
              "positioning": {
                "x": 0.0,
                "y": 0.0,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "Virtual",
              "renderInfo": {
                "info": {
                  "Spec Name": "Dummy IMM Module",
                  "Spec Type": "Virtual",
                  "Installed Version": "(1Tb)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=5/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "7/6/2019",
                  "Last Modified Date": "17/9/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "Virtual:Dummy IMM Module:ALN:(1Tb)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=5/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "17/9/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=5/sub_slot=1/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 32.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "7/6/2019",
                      "Last Modified Date": "17/9/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "5/1/1/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "17/9/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=5/sub_slot=1/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 72.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "7/6/2019",
                      "Last Modified Date": "17/9/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "5/1/2/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "17/9/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=5/sub_slot=1/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 113.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "7/6/2019",
                      "Last Modified Date": "17/9/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "5/1/3/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "17/9/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=5/sub_slot=1/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 153.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "7/6/2019",
                      "Last Modified Date": "17/9/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "5/1/4/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "17/9/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=5/sub_slot=1/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 194.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "7/6/2019",
                      "Last Modified Date": "17/9/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "5/1/5/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "17/9/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=5/sub_slot=1/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 234.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "7/6/2019",
                      "Last Modified Date": "17/9/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "5/1/6/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=5/sub_slot=1/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 275.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 315.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 356.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "578490:/shelf=1/slot=5/sub_slot=1/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 396.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=11",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=11",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=11",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=11",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 190.85,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Switch",
          "renderInfo": {
            "info": {
              "Spec Name": "Switch Fabric /CPU  Module",
              "Spec Type": "Switch",
              "Installed Version": "(V5 Fixed)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=11",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Switch:Switch Fabric /CPU  Module:ALN:(V5 Fixed)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=11",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=11/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=11/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "17/9/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=11/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=11/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 13.4,
                "height": 17.0
              },
              "positioning": {
                "x": 10.5,
                "y": 210.0,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "FastE",
              "renderInfo": {
                "info": {
                  "Spec Name": "FastE Logical Card [2]",
                  "Spec Type": "FastE",
                  "Installed Version": "(7750)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=11/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "7/6/2019",
                  "Last Modified Date": "17/9/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "FastE:FastE Logical Card [2]:ALN:(7750)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=11/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 13.4,
                  "height": 17.0
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "A/Mgt/1",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=11/sub_slot=1/port=1",
                    "Id": "578490:/shelf=1/slot=11/sub_slot=1/port=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "NotAvailable",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=11/sub_slot=1/port=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 0
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 4.0,
                    "y": 3.0,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "A/Mgt/2",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=11/sub_slot=1/port=2",
                    "Id": "578490:/shelf=1/slot=11/sub_slot=1/port=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "NotAvailable",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=11/sub_slot=1/port=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 0
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 4.0,
                    "y": 10.0,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=12",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=12",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=12",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=12",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 225.3,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Switch",
          "renderInfo": {
            "info": {
              "Spec Name": "Switch Fabric /CPU  Module",
              "Spec Type": "Switch",
              "Installed Version": "(V5 Fixed)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=12",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Switch:Switch Fabric /CPU  Module:ALN:(V5 Fixed)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=12",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=12/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=12/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "17/9/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=12/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=12/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 13.4,
                "height": 17.0
              },
              "positioning": {
                "x": 10.5,
                "y": 210.0,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "FastE",
              "renderInfo": {
                "info": {
                  "Spec Name": "FastE Logical Card [2]",
                  "Spec Type": "FastE",
                  "Installed Version": "(7750)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=12/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "7/6/2019",
                  "Last Modified Date": "17/9/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "FastE:FastE Logical Card [2]:ALN:(7750)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=12/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 13.4,
                  "height": 17.0
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "B/Mgt/1",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=12/sub_slot=1/port=1",
                    "Id": "578490:/shelf=1/slot=12/sub_slot=1/port=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "NotAvailable",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=12/sub_slot=1/port=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 0
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 4.0,
                    "y": 3.0,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "B/Mgt/2",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=12/sub_slot=1/port=2",
                    "Id": "578490:/shelf=1/slot=12/sub_slot=1/port=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "NotAvailable",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=12/sub_slot=1/port=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 0
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 4.0,
                    "y": 10.0,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=6",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=6",
            "Created Date": "20/9/2019",
            "Last Modified Date": "27/8/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=6",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=6",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 259.75,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "10GE Multicore IMM Module",
              "Spec Type": "Traffic",
              "Installed Version": "(12Pt Lic)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=6",
              "Level": "Level1",
              "Created Date": "12/6/2019",
              "Last Modified Date": "27/8/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:10GE Multicore IMM Module:ALN:(12Pt Lic)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=6",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=6/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=6/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=6/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=6/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 437.25
              },
              "positioning": {
                "x": 0.0,
                "y": 0.0,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "Virtual",
              "renderInfo": {
                "info": {
                  "Spec Name": "Dummy IMM Module",
                  "Spec Type": "Virtual",
                  "Installed Version": "(1Tb)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=6/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "12/6/2019",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "Virtual:Dummy IMM Module:ALN:(1Tb)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=6/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=6/sub_slot=1/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 32.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "12/6/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "6/1/1/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=6/sub_slot=1/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 72.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "12/6/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "6/1/2/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=6/sub_slot=1/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 113.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "12/6/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "6/1/3/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=6/sub_slot=1/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 153.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "12/6/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "6/1/4/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=6/sub_slot=1/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 194.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "12/6/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "6/1/5/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=6/sub_slot=1/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 234.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE LR SFP+",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(1Tb)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "12/6/2019",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE LR SFP+:ALN:(1Tb)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "6/1/6/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=6/sub_slot=1/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "NotAvailable",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 275.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 315.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 356.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "578490:/shelf=1/slot=6/sub_slot=1/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "",
                    "Created Date": "",
                    "Last Modified Date": "",
                    "Type": ""
                  },
                  "model": {
                    "color": "",
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 396.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=7",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=7",
            "Created Date": "20/9/2019",
            "Last Modified Date": "27/8/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=7",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=7",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 294.2,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "I/O Module",
              "Spec Type": "Traffic",
              "Installed Version": "(Rev C - v3)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=7",
              "Level": "Level1",
              "Created Date": "9/5/2014",
              "Last Modified Date": "27/8/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:I/O Module:ALN:(Rev C - v3)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=7",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=7/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=7/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=7/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=7/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 0.333,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "FastE",
              "renderInfo": {
                "info": {
                  "Spec Name": "FastE [60] Elect",
                  "Spec Type": "FastE",
                  "Installed Version": "(N/A)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=7/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "9/5/2014",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "Ethernet Access",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "FastE:FastE [60] Elect:ALN:(N/A)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=7/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/1",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=1",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#0000FF",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 3.161,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/2",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=2",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 10.323,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/3",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=3",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 17.484,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/4",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=4",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 24.645,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/5",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=5",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 31.806,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/6",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=6",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 38.968,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/7",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=7",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 46.129,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/8",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=8",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 53.29,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/9",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=9",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 60.452,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/10",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=10",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 67.613,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/11",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=11",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=11",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=11",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 74.774,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/12",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=12",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=12",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=12",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 81.935,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/13",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=13",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=13",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=13",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 89.097,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/14",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=14",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=14",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=14",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 96.258,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/15",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=15",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=15",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=15",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 103.419,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/16",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=16",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=16",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=16",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 110.581,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/17",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=17",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=17",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=17",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 117.742,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/18",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=18",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=18",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=18",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 124.903,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/19",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=19",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=19",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=19",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 132.065,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/20",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=20",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=20",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=20",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 139.226,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/21",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=21",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=21",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=21",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 146.387,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/22",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=22",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=22",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=22",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 153.548,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/23",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=23",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=23",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=23",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 160.71,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/24",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=24",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=24",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=24",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 167.871,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/25",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=25",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=25",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=25",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 175.032,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/26",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=26",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=26",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=26",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 182.194,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/27",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=27",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=27",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=27",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 189.355,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/28",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=28",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=28",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=28",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 196.516,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/29",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=29",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=29",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=29",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 203.677,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/30",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=30",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=30",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=30",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 8.0,
                    "y": 210.839,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/31",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=31",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=31",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=31",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 3.161,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/32",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=32",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=32",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=32",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 10.323,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/33",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=33",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=33",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=33",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 17.484,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/34",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=34",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=34",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=34",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 24.645,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/35",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=35",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=35",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=35",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 31.806,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/36",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=36",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=36",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=36",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 38.968,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/37",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=37",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=37",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=37",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 46.129,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/38",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=38",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=38",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=38",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 53.29,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/39",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=39",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=39",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=39",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 60.452,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/40",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=40",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=40",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=40",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 67.613,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/41",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=41",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=41",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=41",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 74.774,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/42",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=42",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=42",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=42",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 81.935,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/43",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=43",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=43",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=43",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 89.097,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/44",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=44",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=44",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=44",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 96.258,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/45",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=45",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=45",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=45",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 103.419,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/46",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=46",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=46",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=46",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 110.581,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/47",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=47",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=47",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=47",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 117.742,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/48",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=48",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=48",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=48",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 124.903,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/49",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=49",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=49",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=49",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 132.065,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/50",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=50",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=50",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=50",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 139.226,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/51",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=51",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=51",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=51",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 146.387,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/52",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=52",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=52",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=52",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 153.548,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/53",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=53",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=53",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=53",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 160.71,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/54",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=54",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=54",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=54",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 167.871,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/55",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=55",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=55",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=55",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 175.032,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/56",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=56",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=56",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=56",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 182.194,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/57",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=57",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=57",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=57",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 189.355,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/58",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=58",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=58",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=58",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 196.516,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/59",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=59",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=59",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=59",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 203.677,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }, {
                "id": "Port",
                "renderInfo": {
                  "info": {
                    "Name": "7/1/60",
                    "Port Signal Type": "FastE",
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=1/port=60",
                    "Id": "578490:/shelf=1/slot=7/sub_slot=1/port=60",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "20/9/2019",
                    "Operational Status": "Operational",
                    "ConnectorType": "",
                    "ToDPhSync": "",
                    "InterfaceType": "",
                    "Type": "PhysicalPort",
                    "EmEventTpName": "",
                    "DuplexMode": "Unknown",
                    "Windowtype": "",
                    "SyncReference": ""
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#FFFF00",
                    "name": "FastE LP",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=1/port=60",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": 2
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 5.5,
                    "height": 4.5
                  },
                  "positioning": {
                    "x": 21.0,
                    "y": 210.839,
                    "z": 1.0
                  }
                },
                "childReferenceMap": []
              }]
            }]
          }, {
            "id": "578490:/shelf=1/slot=7/sub_slot=2",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=7/sub_slot=2",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=7/sub_slot=2",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=7/sub_slot=2",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 218.667,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "GigE [10]",
                  "Spec Type": "GigE",
                  "Installed Version": "(Rev B)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=7/sub_slot=2",
                  "Level": "Level2",
                  "Created Date": "9/7/2014",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "GigE:GigE [10]:ALN:(Rev B)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=7/sub_slot=2",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/1/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/2/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/3/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/4/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/5/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/6/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=7",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=7",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=7",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/7/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=7/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=7/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=7/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=8",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=8",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=8",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/8/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=8/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=8/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=8/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=9",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=9",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=9",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/9/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=9/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=9/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=9/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=7/sub_slot=2/subsub_slot=10",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=10",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=10",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "7/2/10/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=7/sub_slot=2/subsub_slot=10/port=1",
                        "Id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=10/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=7/sub_slot=2/subsub_slot=10/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=8",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=8",
            "Created Date": "20/9/2019",
            "Last Modified Date": "27/8/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=8",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=8",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 328.65,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "I/O Module",
              "Spec Type": "Traffic",
              "Installed Version": "(Rev C - v3)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=8",
              "Level": "Level1",
              "Created Date": "9/7/2014",
              "Last Modified Date": "27/8/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:I/O Module:ALN:(Rev C - v3)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=8",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "Slot Cover -Level2",
            "renderInfo": {
              "info": {
                "MTOSIName": "",
                "Created Date": "",
                "Last Modified Date": "",
                "Type": ""
              },
              "model": {
                "color": "",
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 0.333,
                "z": 1.0
              }
            },
            "childReferenceMap": []
          }, {
            "id": "578490:/shelf=1/slot=8/sub_slot=2",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=8/sub_slot=2",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=8/sub_slot=2",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=8/sub_slot=2",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 218.667,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "GigE [10]",
                  "Spec Type": "GigE",
                  "Installed Version": "(Rev B)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=8/sub_slot=2",
                  "Level": "Level2",
                  "Created Date": "9/7/2014",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "GigE:GigE [10]:ALN:(Rev B)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=8/sub_slot=2",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/1/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/2/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/3/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/4/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/5/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/6/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=7",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=7",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=7",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/7/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=7/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=7/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=7/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=8",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=8",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=8",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/8/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=8/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=8/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=8/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=9",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=9",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=9",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/9/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=9/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=9/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=9/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=8/sub_slot=2/subsub_slot=10",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(ROHS 6/6)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=10",
                      "Level": "Level3",
                      "Created Date": "9/7/2014",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(ROHS 6/6)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=10",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "8/2/10/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=8/sub_slot=2/subsub_slot=10/port=1",
                        "Id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=10/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#FFFF00",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=8/sub_slot=2/subsub_slot=10/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=9",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=9",
            "Created Date": "20/9/2019",
            "Last Modified Date": "19/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=9",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=9",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 363.1,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "I/O Module",
              "Spec Type": "Traffic",
              "Installed Version": "(Rev C - v3)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=9",
              "Level": "Level1",
              "Created Date": "7/7/2008",
              "Last Modified Date": "19/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:I/O Module:ALN:(Rev C - v3)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=9",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=9/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=9/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "19/9/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=9/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=9/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 0.333,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "10GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "1 x 10GB MDA",
                  "Spec Type": "10GigE",
                  "Installed Version": "(Rev 7)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=9/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "26/9/2012",
                  "Last Modified Date": "19/9/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "10GigE:1 x 10GB MDA:ALN:(Rev 7)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=9/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=9/sub_slot=1/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=1/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "19/9/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=1/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=1/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 105.0,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE SFP Opt",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=1/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "26/9/2012",
                      "Last Modified Date": "19/9/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=1/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/1/1/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=1/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=1/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=1/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }, {
            "id": "578490:/shelf=1/slot=9/sub_slot=2",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=9/sub_slot=2",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=9/sub_slot=2",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=9/sub_slot=2",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 218.667,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "GigE [10]",
                  "Spec Type": "GigE",
                  "Installed Version": "(Rev B)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=9/sub_slot=2",
                  "Level": "Level2",
                  "Created Date": "7/7/2008",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "Ethernet Access",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "GigE:GigE [10]:ALN:(Rev B)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=9/sub_slot=2",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/1/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/2/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#32CD32",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/3/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#32CD32",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/4/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/5/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/6/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=7",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=7",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=7",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/7/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=7/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=7/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#32CD32",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=7/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=8",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=8",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=8",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/8/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=8/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=8/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=8/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=9",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=9",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=9",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/9/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=9/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=9/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=9/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=9/sub_slot=2/subsub_slot=10",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=10",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=10",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "9/2/10/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=9/sub_slot=2/subsub_slot=10/port=1",
                        "Id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=10/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=9/sub_slot=2/subsub_slot=10/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=10",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=10",
            "Created Date": "20/9/2019",
            "Last Modified Date": "19/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=10",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=10",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 300.0,
            "width": 34.45,
            "height": 437.25
          },
          "positioning": {
            "x": 397.55,
            "y": 63.6,
            "z": 1.0
          }
        },
        "childReferenceMap": [{
          "id": "Traffic",
          "renderInfo": {
            "info": {
              "Spec Name": "I/O Module",
              "Spec Type": "Traffic",
              "Installed Version": "(Rev C - v3)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=10",
              "Level": "Level1",
              "Created Date": "7/7/2008",
              "Last Modified Date": "19/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Traffic:I/O Module:ALN:(Rev C - v3)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=10",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 300.0,
              "width": 34.45,
              "height": 437.25
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": 1.0
            }
          },
          "childReferenceMap": [{
            "id": "578490:/shelf=1/slot=10/sub_slot=1",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=10/sub_slot=1",
                "Created Date": "20/9/2019",
                "Last Modified Date": "19/9/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=10/sub_slot=1",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=10/sub_slot=1",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 0.333,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "10GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "1 x 10GB MDA",
                  "Spec Type": "10GigE",
                  "Installed Version": "(Rev 7)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=10/sub_slot=1",
                  "Level": "Level2",
                  "Created Date": "26/9/2012",
                  "Last Modified Date": "19/9/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "10GigE:1 x 10GB MDA:ALN:(Rev 7)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=10/sub_slot=1",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=10/sub_slot=1/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=1/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=1/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=1/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 105.0,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "10GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "10GigE SFP Opt",
                      "Spec Type": "10GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=1/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "26/9/2012",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "10GigE SFP:10GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=1/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/1/1/1",
                        "Port Signal Type": "10GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=1/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=1/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "10GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=1/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }, {
            "id": "578490:/shelf=1/slot=10/sub_slot=2",
            "renderInfo": {
              "info": {
                "MTOSIName": "/shelf=1/slot=10/sub_slot=2",
                "Created Date": "20/9/2019",
                "Last Modified Date": "27/8/2019",
                "Type": "Holder"
              },
              "model": {
                "hasStatus": true,
                "emissive": 0.1,
                "color": "grey",
                "name": "/shelf=1/slot=10/sub_slot=2",
                "hasInteraction": true,
                "id": "578490:/shelf=1/slot=10/sub_slot=2",
                "reflectivity": 10,
                "opacity": 1,
                "status": ""
              },
              "sizing": {
                "depth": 300.0,
                "width": 34.45,
                "height": 218.625
              },
              "positioning": {
                "x": 0.0,
                "y": 218.667,
                "z": 1.0
              }
            },
            "childReferenceMap": [{
              "id": "GigE",
              "renderInfo": {
                "info": {
                  "Spec Name": "GigE [10]",
                  "Spec Type": "GigE",
                  "Installed Version": "(Rev B)",
                  "Manufacturer": "ALN",
                  "Type": "Card",
                  "MTOSIName": "/shelf=1/slot=10/sub_slot=2",
                  "Level": "Level2",
                  "Created Date": "7/7/2008",
                  "Last Modified Date": "27/8/2019",
                  "Inventory Status": "",
                  "Technical RFS Date": "",
                  "SlotFreeCapacityUsageCard": "Ethernet Access",
                  "WiringType": "",
                  "ToDPhEnabled": ""
                },
                "model": {
                  "hasStatus": true,
                  "emissive": 0.1,
                  "color": "grey",
                  "name": "GigE:GigE [10]:ALN:(Rev B)",
                  "hasInteraction": true,
                  "id": "578490:/shelf=1/slot=10/sub_slot=2",
                  "reflectivity": 10,
                  "opacity": 1,
                  "status": ""
                },
                "sizing": {
                  "depth": 300.0,
                  "width": 34.45,
                  "height": 218.625
                },
                "positioning": {
                  "x": 0.0,
                  "y": 0.0,
                  "z": 1.0
                }
              },
              "childReferenceMap": [{
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=1",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=1",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=1",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=1",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 12.545,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=1",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=1",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/1/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=1/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=1/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=1/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=2",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=2",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=2",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=2",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 33.091,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=2",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=2",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/2/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=2/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=2/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=2/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=3",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=3",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=3",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=3",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 53.636,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=3",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=3",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/3/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=3/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=3/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#32CD32",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=3/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=4",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=4",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=4",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=4",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 74.182,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=4",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=4",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/4/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=4/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=4/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=4/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=5",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=5",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=5",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=5",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 94.727,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=5",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=5",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/5/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=5/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=5/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=5/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=6",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=6",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=6",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=6",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 115.273,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=6",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=6",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/6/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=6/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=6/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=6/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=7",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=7",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=7",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=7",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 135.818,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=7",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=7",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/7/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=7/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=7/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#32CD32",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=7/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 0
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=8",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=8",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=8",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=8",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 156.364,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=8",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "Ethernet Access",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=8",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/8/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=8/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=8/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=8/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=9",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=9",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=9",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=9",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 176.909,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=9",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=9",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/9/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=9/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=9/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=9/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }, {
                "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=10",
                "renderInfo": {
                  "info": {
                    "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=10",
                    "Created Date": "20/9/2019",
                    "Last Modified Date": "27/8/2019",
                    "Type": "Holder"
                  },
                  "model": {
                    "hasStatus": true,
                    "emissive": 0.1,
                    "color": "#B3B6B5",
                    "name": "/shelf=1/slot=10/sub_slot=2/subsub_slot=10",
                    "hasInteraction": true,
                    "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=10",
                    "reflectivity": 10,
                    "opacity": 1,
                    "status": ""
                  },
                  "sizing": {
                    "depth": 300.0,
                    "width": 13.4,
                    "height": 8.5
                  },
                  "positioning": {
                    "x": 10.5,
                    "y": 197.455,
                    "z": 1.0
                  }
                },
                "childReferenceMap": [{
                  "id": "GigE SFP",
                  "renderInfo": {
                    "info": {
                      "Spec Name": "GigE SFP Opt",
                      "Spec Type": "GigE SFP",
                      "Installed Version": "(N/A)",
                      "Manufacturer": "ALN",
                      "Type": "Plugin",
                      "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=10",
                      "Level": "Level3",
                      "Created Date": "7/7/2008",
                      "Last Modified Date": "27/8/2019",
                      "Inventory Status": "",
                      "Technical RFS Date": "",
                      "SlotFreeCapacityUsagePlugin": "",
                      "WiringType": "",
                      "ToDPhEnabled": ""
                    },
                    "model": {
                      "hasStatus": true,
                      "emissive": 0.1,
                      "color": "grey",
                      "name": "GigE SFP:GigE SFP Opt:ALN:(N/A)",
                      "hasInteraction": true,
                      "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=10",
                      "reflectivity": 10,
                      "opacity": 1,
                      "status": ""
                    },
                    "sizing": {
                      "depth": 300.0,
                      "width": 13.4,
                      "height": 8.5
                    },
                    "positioning": {
                      "x": 0.0,
                      "y": 0.0,
                      "z": 1.0
                    }
                  },
                  "childReferenceMap": [{
                    "id": "Port",
                    "renderInfo": {
                      "info": {
                        "Name": "10/2/10/1",
                        "Port Signal Type": "GigE",
                        "MTOSIName": "/shelf=1/slot=10/sub_slot=2/subsub_slot=10/port=1",
                        "Id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=10/port=1",
                        "Created Date": "20/9/2019",
                        "Last Modified Date": "20/9/2019",
                        "Operational Status": "Operational",
                        "ConnectorType": "",
                        "ToDPhSync": "",
                        "InterfaceType": "",
                        "Type": "PhysicalPort",
                        "EmEventTpName": "",
                        "DuplexMode": "Unknown",
                        "Windowtype": "",
                        "SyncReference": ""
                      },
                      "model": {
                        "hasStatus": true,
                        "emissive": 0.1,
                        "color": "#0000FF",
                        "name": "GigE LP",
                        "hasInteraction": true,
                        "id": "578490:/shelf=1/slot=10/sub_slot=2/subsub_slot=10/port=1",
                        "reflectivity": 10,
                        "opacity": 1,
                        "status": 2
                      },
                      "sizing": {
                        "depth": 300.0,
                        "width": 11.4,
                        "height": 6.5
                      },
                      "positioning": {
                        "x": 1.0,
                        "y": 1.0,
                        "z": 1.0
                      }
                    },
                    "childReferenceMap": []
                  }]
                }]
              }]
            }]
          }]
        }]
      }, {
        "id": "578490:/shelf=1/slot=13",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=13",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=13",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=13",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 245.0,
            "width": 137.8,
            "height": 310.0
          },
          "positioning": {
            "x": 18.55,
            "y": 151.0,
            "z": -376
          }
        },
        "childReferenceMap": [{
          "id": "Fan Tray",
          "renderInfo": {
            "info": {
              "Spec Name": "Enhanced Fan Tray",
              "Spec Type": "Fan Tray",
              "Installed Version": "(Fixed)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=13",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Fan Tray:Enhanced Fan Tray:ALN:(Fixed)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=13",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 245.0,
              "width": 137.8,
              "height": 310.0
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": -2.0
            }
          },
          "childReferenceMap": []
        }]
      }, {
        "id": "578490:/shelf=1/slot=14",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=14",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=14",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=14",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 245.0,
            "width": 137.8,
            "height": 310.0
          },
          "positioning": {
            "x": 156.35,
            "y": 151.0,
            "z": -376
          }
        },
        "childReferenceMap": [{
          "id": "Fan Tray",
          "renderInfo": {
            "info": {
              "Spec Name": "Enhanced Fan Tray",
              "Spec Type": "Fan Tray",
              "Installed Version": "(Fixed)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=14",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Fan Tray:Enhanced Fan Tray:ALN:(Fixed)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=14",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 245.0,
              "width": 137.8,
              "height": 310.0
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": -2.0
            }
          },
          "childReferenceMap": []
        }]
      }, {
        "id": "578490:/shelf=1/slot=15",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=15",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=15",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=15",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 245.0,
            "width": 137.8,
            "height": 310.0
          },
          "positioning": {
            "x": 294.15,
            "y": 151.0,
            "z": -376
          }
        },
        "childReferenceMap": [{
          "id": "Fan Tray",
          "renderInfo": {
            "info": {
              "Spec Name": "Enhanced Fan Tray",
              "Spec Type": "Fan Tray",
              "Installed Version": "(Fixed)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=15",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Fan Tray:Enhanced Fan Tray:ALN:(Fixed)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=15",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 245.0,
              "width": 137.8,
              "height": 310.0
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": -2.0
            }
          },
          "childReferenceMap": []
        }]
      }, {
        "id": "578490:/shelf=1/slot=16",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=16",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=16",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=16",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 245.0,
            "width": 413.4,
            "height": 50.0
          },
          "positioning": {
            "x": 18.55,
            "y": 485,
            "z": -376
          }
        },
        "childReferenceMap": [{
          "id": "Power",
          "renderInfo": {
            "info": {
              "Spec Name": "DC PSU-175APEM-3",
              "Spec Type": "Power",
              "Installed Version": "(Fixed)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=16",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Power:DC PSU-175APEM-3:ALN:(Fixed)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=16",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 245.0,
              "width": 413.4,
              "height": 50.0
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": -2.0
            }
          },
          "childReferenceMap": []
        }]
      }, {
        "id": "578490:/shelf=1/slot=17",
        "renderInfo": {
          "info": {
            "MTOSIName": "/shelf=1/slot=17",
            "Created Date": "20/9/2019",
            "Last Modified Date": "17/9/2019",
            "Type": "Holder"
          },
          "model": {
            "hasStatus": true,
            "emissive": 0.1,
            "color": "grey",
            "name": "/shelf=1/slot=17",
            "hasInteraction": true,
            "id": "578490:/shelf=1/slot=17",
            "reflectivity": 10,
            "opacity": 1,
            "status": ""
          },
          "sizing": {
            "depth": 245.0,
            "width": 413.4,
            "height": 50.0
          },
          "positioning": {
            "x": 18.55,
            "y": 535.0,
            "z": -376.0
          }
        },
        "childReferenceMap": [{
          "id": "Power",
          "renderInfo": {
            "info": {
              "Spec Name": "DC PSU-175APEM-3",
              "Spec Type": "Power",
              "Installed Version": "(Fixed)",
              "Manufacturer": "ALN",
              "Type": "Card",
              "MTOSIName": "/shelf=1/slot=17",
              "Level": "Level1",
              "Created Date": "7/6/2019",
              "Last Modified Date": "17/9/2019",
              "Inventory Status": "",
              "Technical RFS Date": "",
              "SlotFreeCapacityUsageCard": "",
              "WiringType": "",
              "ToDPhEnabled": ""
            },
            "model": {
              "hasStatus": true,
              "emissive": 0.1,
              "color": "grey",
              "name": "Power:DC PSU-175APEM-3:ALN:(Fixed)",
              "hasInteraction": true,
              "id": "578490:/shelf=1/slot=17",
              "reflectivity": 10,
              "opacity": 1,
              "status": ""
            },
            "sizing": {
              "depth": 245.0,
              "width": 413.4,
              "height": 50.0
            },
            "positioning": {
              "x": 0.0,
              "y": 0.0,
              "z": -2.0
            }
          },
          "childReferenceMap": []
        }]
      }]
    }]
  }
};
module.exports = srims_sr12_data;
