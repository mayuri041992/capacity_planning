import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppService } from './core/services/app-service/app.service';
import { LoginService } from './core/services/login-service/login.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [AppService, LoginService],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    window['CURRENT_USER'] = {
      EIN : '7777777',
      GroupName: 'PRE_PROD_CE_ADMIN^PRE_PROD_CE_DESIGNER'
  };
    expect(component).toBeTruthy();
  });
  it('should define ngOninit', () => {
    // window['CURRENT_USER'] = {
    //     EIN : '7777777',
    //     GroupName: 'PRE_PROD_CE_ADMIN^PRE_PROD_CE_DESIGNER'
    // };
    // const service: LoginService = TestBed.get(LoginService);
    // service.EIN = '7777777';
    // service.GroupName = 'PRE_PROD_CE_ADMIN^PRE_PROD_CE_DESIGNER';
    // expect(service.EIN).toBeDefined();
    component.ngOnInit();
    expect(component.ngOnInit).toBeDefined();
  });
});
