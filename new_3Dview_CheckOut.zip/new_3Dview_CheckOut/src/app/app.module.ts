import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {  BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SharedModule } from './shared/shared.module';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastModule } from 'primeng/toast';
import { NgxLoadingModule } from 'ngx-loading';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MessageService } from 'primeng/api';
import { LoginService } from './core/services/login-service/login.service';
import { AccessGurad } from './core/access-guards/access-guard';
import { InterceptorService } from './core/interceptor/interceptor.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { DashboardCapacityComponent } from './components/dashboard-capacity/dashboard-capacity.component';
import { GoogleChartsModule } from 'angular-google-charts';
import { ForecastLineService } from './core/services/product-line-forecast-service/product-line-forecast.service';
import { DetailedSiteComponent } from './components/detailed-site/detailed-site.component';
import { TabViewModule } from 'primeng/tabview';
import * as Chart from 'chart.js';
import 'chartjs-plugin-datalabels';
import { DiversityReportComponent } from './components/divercity-report/divercity-report.component';
import { ChassisViewComponent } from './components/chassis-view/chassis-view.component';
import { ChassisViewService } from './core/services/chassis-view-service/chassis-view.service';



@NgModule({
  declarations: [
    AppComponent,
    DashboardCapacityComponent,
    DetailedSiteComponent,
    DiversityReportComponent,
    ChassisViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxLoadingModule,
    TableModule,
    PaginatorModule,
    NgbModule,
    ToastModule,
    SharedModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    NgxSpinnerModule,
    GoogleChartsModule,
    TabViewModule
  ],
  providers: [ { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true},
    MessageService, LoginService, NgbActiveModal, AccessGurad, ForecastLineService, ChassisViewService,
    NgbActiveModal, { provide: HashLocationStrategy, useClass: LocationStrategy }],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppModule { }
