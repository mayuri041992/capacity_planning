import { Component, OnInit } from '@angular/core';
import { Meta } from '@angular/platform-browser';
import { environment } from '../environments/environment';
import { LoginService } from './core/services/login-service/login.service';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { Router } from '@angular/router';
import { fromEvent } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [Location, {provide: LocationStrategy, useClass: PathLocationStrategy}],
})
export class AppComponent implements OnInit {
  location: Location;
  constructor(private meta: Meta, private loginService: LoginService, location: Location,
              private router: Router) {
    this.location = location;
    this.meta.addTag({ name: 'http-equiv', content: 'IE=edge' });
    meta.addTag({ charset: 'UTF-8' });
    this.loginService.GroupName  =  'PRE_PROD_CE_ADMIN^PRE_PROD_CE_DESIGNER';
    this.loginService.EIN = '612642711';
    // tslint:disable-next-line:no-string-literal
    if ( window['CURRENT_USER']) {
      // tslint:disable-next-line:no-string-literal
      this.loginService.EIN = environment.ein = window['CURRENT_USER'].EIN;
      // tslint:disable-next-line:no-string-literal
      this.loginService.GroupName = environment.userRole = window['CURRENT_USER'].GroupName;
    }
  }
  ngOnInit() {
    fromEvent(document, 'keydown').subscribe((data) => {
      // tslint:disable-next-line:no-string-literal
      if (data['keyCode'] === 116) {
        data.preventDefault();
      //  tslint:disable-next-line:no-string-literal
        const refreahURL = (this.location['_platformStrategy']._platformLocation.location.hash).split('#').join('');
        this.router.navigateByUrl(refreahURL, { skipLocationChange: true }).then(() =>
          this.router.navigate([refreahURL]));
        this.router.routeReuseStrategy.shouldReuseRoute = () => {
          return false;
        };
      }
    });
  }
}
