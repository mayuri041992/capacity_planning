// tslint:disable-next-line:class-name
export class pageObject {
    'pageNo';
    'pageSize';
    'sortByField';
    'sortOrder';
    'siteName';
    'exchangeCode';
    'enableSorting';

    constructor(pageObj = {}) {
        // tslint:disable-next-line:no-string-literal
        this.sortByField = pageObj['sortByField'] ? pageObj['sortByField'] : 'siteName';
        // tslint:disable-next-line:no-string-literal
        this.pageNo = pageObj['pageNo'] ? pageObj['pageNo'] : 0,
        // tslint:disable-next-line:no-string-literal
            this.pageSize = pageObj['pageSize'] ? pageObj['pageSize'] : 0,
            // tslint:disable-next-line:no-string-literal
            this.sortOrder = pageObj['sortOrder'] ? pageObj['sortOrder'] : true,
            // tslint:disable-next-line:no-string-literal
            this.siteName = pageObj['siteName'] ? pageObj['siteName'] : '';
            // tslint:disable-next-line:no-string-literal
        this.exchangeCode = pageObj['exchangeCode'] ? pageObj['exchangeCode'] : '';
        // tslint:disable-next-line:no-string-literal
        this.enableSorting = pageObj['enableSorting'] ? pageObj['enableSorting'] : true;

    }
}
