// tslint:disable-next-line:class-name
export class filterObject {
    public exchangeInfoFilterRequest = {
        deviceModel: [],
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: '',
        portSpeed: [],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        nodeType: [],
        ein : 0
    };
}


