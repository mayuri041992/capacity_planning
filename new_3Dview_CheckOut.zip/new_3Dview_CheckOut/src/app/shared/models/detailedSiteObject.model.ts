export interface DetailedSiteObject {
    searchType: string;
    serachData: string;
    productType: string;
}
