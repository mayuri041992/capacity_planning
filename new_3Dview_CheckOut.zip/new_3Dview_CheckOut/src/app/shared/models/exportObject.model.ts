export class ExportData {
    'totalPorts': true;
    'usedPorts': true;
    'reserved': true;
    'freePorts': true;
    'freeSlots': true;
    'inFlightPorts': true;
    'broadBandRem': true;
    'broadBandColo': true;
    'ethernetNonTodPorts': true;
    'ethernetTodPorts': true;
    'forCastPorts': true;
    'potential10gBBETHPorts': true;
    'potential10gETHPorts': true;
    constructor() { }
}
