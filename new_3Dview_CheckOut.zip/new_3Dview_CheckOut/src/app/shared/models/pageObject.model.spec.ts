import { TestBed, inject, getTestBed } from '@angular/core/testing';
import { pageObject } from './pageObject.model';

describe('OnBoardSite modal', () => {
    let pageObt;

    beforeEach(() => {
        pageObt = new pageObject();
    });

    it('OnBoardSiteRslt should be defined', () => {
        expect(pageObject).toBeDefined();
    });

    it('constuctor', () => {
        const pageObtObj = {};
        const a = new pageObject(pageObtObj);
    });

    it('constuctor', () => {
        const pageObtObj = {
            pageNo: '1',
            pageSize: '100',
            sortByField: 'siteName',
            sortOrder: true,
            siteName: 'site',
            exchangeCode: 'L/FOR',
            enableSorting: true,
        };
        const a = new pageObject(pageObtObj);
    });
});
