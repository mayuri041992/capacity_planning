export interface Tab  {
    name: string;
    active: boolean;
}
