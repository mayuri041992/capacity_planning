import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-key-statstics-table',
  templateUrl: './key-statstics-table.component.html',
  styleUrls: ['./key-statstics-table.component.scss']
})
export class KeyStatsticsTableComponent implements OnInit {
  @Input() productType: string;
  @Input() color;
  @Input() totalPorts;
  @Input() freePorts;
  constructor() { }

  ngOnInit() {
  }

}
