import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyStatsticsTableComponent } from './key-statstics-table.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('KeyStatsticsTableComponent', () => {
  let component: KeyStatsticsTableComponent;
  let fixture: ComponentFixture<KeyStatsticsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KeyStatsticsTableComponent ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeyStatsticsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
