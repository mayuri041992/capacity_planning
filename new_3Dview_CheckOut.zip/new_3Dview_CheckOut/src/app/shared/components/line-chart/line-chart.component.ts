import { Component, OnInit, OnChanges, Input, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import * as html2canvas from 'html2canvas';
import { AppService } from '../../../core/services/app-service/app.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.scss']
})
export class LineChartComponent implements OnInit, OnChanges, OnDestroy {
  data: any;
  options: any;
  dataname;
  trend;
  searchDataJSON ;
  @Input() tbpsPorts;
  @Input() lineData;
  @Input() tabName;
  @ViewChild('abc') screen: ElementRef;
  @ViewChild('canvas') canvas: ElementRef;
  @ViewChild('downloadLink') downloadLink: ElementRef;

  unsubscribeJSON: Subscription;
  constructor(private services: AppService) {
    this.unsubscribeJSON = this.services.detailedSite$.subscribe((searchJSON) => {
        this.searchDataJSON = searchJSON;
    });
    this.options = {
      title: {
        display: true,
        text: 'TBPS',
        position: 'left'
      },
      legend: { display: false },
      plugins: {
        // Change options for ALL labels of THIS CHART
        datalabels: {
            color: '#36A2EB',
            font: {
              weight: 'bold',
              size: 0,
            }
        }
    },
      scales: {
      yAxes: [{
          ticks: {
              beginAtZero: true
          }
      }]
  }
    };

  }
  ngOnInit() {
  }
  ngOnChanges() {
    this.options.title.text = this.tbpsPorts;
    this.dataname = this.lineData.datasets;
    this.data = this.lineData;
    if (this.data.trendName) {
      this.trend = this.data.trendName.replace(/ /g, '_');
    }
  }
  download() {
    window.scrollTo(0, 0);
    setTimeout(() => {
   // const trendName = this.data.trendName.replace(/ /g, '_');
    html2canvas.default(document.querySelector('.' + this.trend).closest('.card-dashboard') as HTMLElement ).then((canvas) => {
     // const that = this;
      this.canvas.nativeElement.src = canvas.toDataURL();
    //  this.downloadLink.nativeElement.href = canvas.toDataURL('image/png');
      const hrefData = canvas.toDataURL('image/png').replace('data:image/png;base64,', '');
      const blobData = this.convertBase64ToBlobData(hrefData);
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blobData, 'line-chart' + this.trend + '.png');
      } else { // chrome
        const blob = new Blob([blobData], { type: 'image/png' });
        const url = window.URL.createObjectURL(blob);
        // window.open(url);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'line-chart' + this.trend;
        link.click();
      }

      // this.downloadLink.nativeElement.download = 'line-chart.png';
      // this.downloadLink.nativeElement.click();

    }); }, 500);
  }

  convertBase64ToBlobData(base64Data: string, contentType: string = 'image/png', sliceSize = 512) {
    const byteCharacters = atob(base64Data);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      const slice = byteCharacters.slice(offset, offset + sliceSize);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    const blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }
  downloadCSVLine() {
    // console.log(this.tabName);
    if (this.tabName === 'capacity-dashboard') {
      this.services.getDownloadCapacityDashboard();
    } else if (this.tabName === 'Ethernet') {
      // tslint:disable-next-line:max-line-length
      this.services.getDownloadDashboardEthernet();
    } else if (this.tabName === 'Broadband') {
      // tslint:disable-next-line:max-line-length
      this.services.getDownloadDashboardBroadband();
    } else if (this.tabName === 'Backhaul') {
      // tslint:disable-next-line:max-line-length
      this.services.getDownloadDashboardBackhaul();
    }  else if (this.tabName === 'Infrastructure') {
      // tslint:disable-next-line:max-line-length
      this.services.getDownloadDashboardInfraStructure();
    }  else if (this.tabName === 'P2PE') {
      // tslint:disable-next-line:max-line-length
      this.services.getDownloadDashboardP2PE();
    }   else {
      this.services.getDownloadDetailedSite({searchType: this.searchDataJSON.searchType, serachData: this.searchDataJSON.serachData });
    }
  }
  ngOnDestroy() {
    this.unsubscribeJSON.unsubscribe();
  }
}
