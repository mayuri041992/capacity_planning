import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LineChartComponent } from './line-chart.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { AppService } from '../../../core/services/app-service/app.service';
import { of } from 'rxjs';

describe('LineChartComponent', () => {
  let component: LineChartComponent;
  let fixture: ComponentFixture<LineChartComponent>;
  // tslint:disable-next-line:prefer-const
  let service: AppService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LineChartComponent],
      providers: [HttpClient, HttpHandler],
      schemas: [NO_ERRORS_SCHEMA , CUSTOM_ELEMENTS_SCHEMA
      ],
    })
      .compileComponents();
    service = TestBed.get(AppService);
    // spyOn(service, 'detailedSite').and.returnValue(of('L/FOR'));
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should define download', () => {
    // component.download();
    // expect(component.download).toBeTruthy();
    service.detailedSite.next('L/FOR');
   // expect(service.detailedSite).toHaveBeenCalled();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should define ngOnChanges', () => {
    component.lineData = {
        datasets : {
            datatype: 'Totalcapacity',
            data: [10, 100, 20, 30, 40, 60, 70, 80, 89, 94, 101, 111],
            color: '#6c6c6c'
          },
          trendName: 'Ethernet '
    };
    component.ngOnChanges();
    expect(component.ngOnChanges).not.toBeNull();
  });
  it('should define not ngOnChanges', () => {
    component.lineData = {
        datasets : {
            datatype: 'Totalcapacity',
            data: [10, 100, 20, 30, 40, 60, 70, 80, 89, 94, 101, 111],
            color: '#6c6c6c'
          },
          trendName: ''
    };
    component.ngOnChanges();
    expect(component.ngOnChanges).not.toBeNull();
  });

  it('should define ngOnDestroy', () => {
    expect(component.ngOnDestroy()).not.toBeNull();
  });
  it('should define downloadCSVLine', () => {
    component.tabName = 'capacity-dashboard';
    const a = component.searchDataJSON = {
      searchType : 'SITE_NAME' ,
      searchData : 'London',

    };
    expect(component.downloadCSVLine()).toBeUndefined();
    // expect(service.getDownloadDetailedSite(a)).toBeDefined();
  });
  it('should define downloadCSVLine', () => {
    component.tabName = 'Ethernet';
    const a = component.searchDataJSON = {
      searchType : 'SITE_NAME' ,
      searchData : 'London',

    };
    expect(component.downloadCSVLine()).toBeUndefined();
    // expect(service.getDownloadDetailedSite(a)).toBeDefined();
  });
  it('should define downloadCSVLine', () => {
    component.tabName = 'Broadband';
    const a = component.searchDataJSON = {
      searchType : 'SITE_NAME' ,
      searchData : 'London',

    };
    expect(component.downloadCSVLine()).toBeUndefined();
    // expect(service.getDownloadDetailedSite(a)).toBeDefined();
  });
  it('should define downloadCSVLine', () => {
    component.tabName = 'Backhaul';
    const a = component.searchDataJSON = {
      searchType : 'SITE_NAME' ,
      searchData : 'London',

    };
    expect(component.downloadCSVLine()).toBeUndefined();
    // expect(service.getDownloadDetailedSite(a)).toBeDefined();
  });
  it('should define downloadCSVLine', () => {
    component.tabName = 'Infrastructure';
    const a = component.searchDataJSON = {
      searchType : 'SITE_NAME' ,
      searchData : 'London',

    };
    expect(component.downloadCSVLine()).toBeUndefined();
    // expect(service.getDownloadDetailedSite(a)).toBeDefined();
  });
  it('should define downloadCSVLine', () => {
    component.tabName = 'P2PE';
    const a = component.searchDataJSON = {
      searchType : 'SITE_NAME' ,
      searchData : 'London',

    };
    expect(component.downloadCSVLine()).toBeUndefined();
    // expect(service.getDownloadDetailedSite(a)).toBeDefined();
  });

  it('should define downloadCSVLine', () => {
    component.tabName = '';
    const a = component.searchDataJSON = {
      searchType : 'SITE_NAME' ,
      searchData : 'London',

    };
    expect(component.downloadCSVLine()).toBeUndefined();
    // expect(service.getDownloadDetailedSite(a)).toBeDefined();
  });

});
