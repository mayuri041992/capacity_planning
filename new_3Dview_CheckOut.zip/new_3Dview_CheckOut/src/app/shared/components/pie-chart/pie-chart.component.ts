import { Component, OnInit, Input, OnChanges, ViewChild, ElementRef } from '@angular/core';
import * as html2canvas from 'html2canvas';
import { AppService } from '../../../core/services/app-service/app.service';
import { take } from 'rxjs/operators';


@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.scss']
})
export class PieChartComponent implements OnInit, OnChanges {
  @Input() pieData;
  @Input() label;
  @Input() totalPortsbroad;
  @ViewChild('abc') screen: ElementRef;
  @ViewChild('canvas') canvas: ElementRef;
  @ViewChild('downloadLink') downloadLink: ElementRef;
  type = 'PieChart';
  data;
  datanew;
  columnNames = ['Browser', 'Percentage'];
  options = {
    colors: [ '#0991ce', '#6400aa', '#e48323', '#f3b49f', '#f6c7b6'],
     // is3D : true,
     pieHole: 0.5,
     backgroundColor: 'transparent',
     width: 370,
     height: 600,
     legend : { position : 'bottom' },
  };
  option;

  constructor( private services: AppService) {
    this.option = {
      animation: false,
      legend: {display: false},
      // plugin: {
      //   datalabels: {
      //     color: '#ffffff',
      //   }
      // }
    };
   }

  ngOnInit() {
    this.option = {
      animation: false,
      legend: {display: false},
    };
  }
  ngOnChanges() {
    console.log('', this.label);
    if (this.label) {
      this.datanew = {
        labels: this.label,
        datasets: [
          {
            datalabels: {
              color: (context) => {
                const index = context.dataIndex;
                const value = context.dataset.data[index];
                return value === 0 ? 'transparent' :  // draw negative values in red
                 //   index % 2 ? 'transparent' :    // else, alternate values in blue and green
                    'white';
            },
              font: {
                weight: 'bold',
                size: 14,
              }
          },
            data: this.pieData,
            backgroundColor: ['#FC8C1D', '#6400aa', '#0991ce', '#8A8A8A', '#e60050'],
            hoverBackgroundColor: ['#FC8C1D', '#6400aa', '#0991ce', '#8A8A8A', '#e60050']
          }]
      };
    } else {
        // this.data = this.pieData;
    this.datanew = {
      labels: ['Used Port', 'Reserved Port', 'Free Port' ],
      datasets: [
        {
          datalabels: {
            color: (context) => {
              const index = context.dataIndex;
              const value = context.dataset.data[index];
              return value === 0 ? 'transparent' :  // draw negative values in red
               //   index % 2 ? 'transparent' :    // else, alternate values in blue and green
                  'white';
          },
            font: {
              weight: 'bold',
              size: 16,
            }
        },
          data: this.pieData,
          backgroundColor: [
            '#00A2D7',
            '#6D00A7',
            '#008A24'
          ],
          hoverBackgroundColor: [
            '#36A2EB',
            '#8b25c1',
            '#02af2f'
          ]
        }]
    };

    }
    //  {
    //   this.datanew.labels = this.label;
    //   this.datanew.backgroundColor = ['#FC8C1D', '#6400aa', '#0991ce', '#008A00', '#e60050'];
    // }
  }
  download1() {

    // html2canvas.default(document.querySelector('.pie')).then( ( canvas ) => {
    //   this.canvas.nativeElement.src = canvas.toDataURL();
    //   this.downloadLink.nativeElement.href = canvas.toDataURL('image/png');
    //   this.downloadLink.nativeElement.download = 'pie-chart.png';
    //   this.downloadLink.nativeElement.click();
    //  // canvas.preventDefault();
    //   // event.preventDefault();
    // });
  }

}
