import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PieChartComponent } from './pie-chart.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { AppService } from '../../../core/services/app-service/app.service';
import { of } from 'rxjs';

describe('PieChartComponent', () => {
  let component: PieChartComponent;
  let fixture: ComponentFixture<PieChartComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PieChartComponent ],
      providers: [HttpClient , HttpHandler , RouterTestingModule , AppService],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA , NO_ERRORS_SCHEMA
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should define download1', () => {
    expect(component.download1()).not.toBeNull();
  });

  it('should define ngOnChanges', () => {
    const context = {
      dataIndex: 1,
      dataset: {
        data: ['ab', 'cd']
      }
    };
    component.datanew = {
      datasets: [{
        datalabels: {
          color: (cont) => {},
      },
      }]
    };
    expect(component.ngOnChanges()).not.toBeNull();
    component.datanew.datasets[0].datalabels.color(context);
    expect(component.datanew.datasets[0].datalabels.color).toBeTruthy();
  });
  it('should define ngOnChanges', () => {
    const context = {
      dataIndex: 2,
      dataset: {
        data: ['ab', 'cd', 0]
      }
    };
    component.datanew = {
      datasets: [{
        datalabels: {
          color: (cont) => {},
      },
      }]
    };
    expect(component.ngOnChanges()).not.toBeNull();
    component.datanew.datasets[0].datalabels.color(context);
    expect(component.datanew.datasets[0].datalabels.color).toBeTruthy();
  });
});
