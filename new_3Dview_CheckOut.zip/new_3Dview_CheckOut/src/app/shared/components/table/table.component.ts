// tslint:disable-next-line:max-line-length
import { Component, Input, OnChanges, ViewEncapsulation, Output, EventEmitter, OnInit, AfterViewChecked, ViewChild, ElementRef } from '@angular/core';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnChanges, AfterViewChecked {
  // @Input() actionUpdate: string = '';
  @Input() rows: object[] = [];
  @Input() Column: Array<any> = [];
  @Input() frozencol: Array<any> = [];
  @Input() nameComponent;
  @Input() search: string;
  public listRow = [100, 200, 500];
  public totalCount = 0;
  public pageCount: number;
  public rowsDATA = [];
  public totalRecord = 0;
  @Output() deleteEvent: EventEmitter<object> = new EventEmitter();
  @Output() editEvent: EventEmitter<object> = new EventEmitter();
  public columnShow;
  public headcount;
  public numberPage = 1;
  scrollableCols;
  frozenCols;
  width;
  heightnumber;
  public innerWidth;
  public heightinner = (window.innerHeight - 220) + 'px';
  @ViewChild ('headerWidth') headerWidth: ElementRef;

  constructor(private forecastLineService: ForecastLineService) {
  }
  ngOnChanges() {
    this.columnShow = this.Column;
    this.scrollableCols = this.Column;
    this.frozenCols = this.frozencol;
    this.headcount = this.columnShow.length;
    this.rowsDATA = JSON.parse(JSON.stringify(this.rows));
    // console.log(JSON.stringify(this.rows));
    const styleValue = document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-header');
    const styleValueBody = document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body');
    if (this.rows.length !== 0) {
      this.totalCount = this.totalCount !== 0 ? this.totalCount : 100;
      if (this.nameComponent === 'manage_forecast') {
        // tslint:disable-next-line:no-string-literal
        styleValue['style'].cssText = 'overflow-x: hidden';
        // tslint:disable-next-line:no-string-literal
        // tslint:disable-next-line:max-line-length

        // tslint:disable-next-line:no-string-literal
        styleValueBody['style'].cssText = 'overflow: auto';

      }
      // tslint:disable-next-line:no-string-literal
    } else if (this.rows.length === 0 && (styleValueBody || styleValue)) {
      // tslint:disable-next-line:no-string-literal
      styleValue['style'].cssText = 'overflow-x: scroll';
      // tslint:disable-next-line:no-string-literal
      styleValueBody['style'].cssText = 'overflow: hidden';
      // tslint:disable-next-line:max-line-length
    }
    this.totalRecord = this.rows.length;
    this.pageCount = this.totalRecord >= this.totalCount ? this.totalCount : this.totalRecord;
    this.rows = [...this.rowsDATA.slice(0, this.totalCount)];
  }
  ngAfterViewChecked() {
    const styleValue = document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-header');
    const styleValueBody = document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body');
    if (this.rows.length !== 0 && this.nameComponent === 'forecast-tabs') {
      // tslint:disable-next-line:no-string-literal
      styleValue['style'].cssText = 'overflow-x: hidden';
    } else if (this.nameComponent !== 'forecast-tabs' && this.nameComponent !== 'manage_forecast') {
      setTimeout( () => {
      const thwidth = this.headerWidth.nativeElement.offsetWidth / 4;
      const classTh  =  Array.from(document.querySelectorAll('th'));
      classTh.map((th) => th.style.width = thwidth + 'px');
      // tslint:disable-next-line:no-string-literal
      if (document.querySelector('.ui-table-tbody')['offsetHeight'] > 620) {
        // tslint:disable-next-line:no-string-literal
        document.querySelector('.ui-table-thead')['style'].width = '99.2%';
      }
    }, 100);
    }
  }
  editRow(rowDetails, index) {
    this.editEvent.emit({ clonedRows: this.rows, rowDetails, index });
  }
  onDelete(rowDetails, index) {
    this.deleteEvent.emit({ clonedRows: this.rows, rowDetails, index });
    document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-header .ui-table-scrollable-header-box')
    // tslint:disable-next-line:no-string-literal
    ['style'].cssText = 'margin-left: 0px';
  }
  public paginate(event: any) {
    this.pageCount = this.totalCount * (event.page + 1);
    this.pageCount = this.pageCount >= (this.totalRecord) ? this.totalRecord : this.pageCount;
    this.rows = [...this.rowsDATA.slice(event.first, +event.rows + event.first)];
  }
  selectChange() {
    this.pageCount = this.totalRecord >= this.totalCount ? this.totalCount : this.totalRecord;
    this.rows = [...this.rowsDATA.slice(0, this.totalCount)];
  }
  customSort(event: any) {
    if (event.order === 1) {
      event.data = event.data.sort((a, b) => a[event.field] - b[event.field]);
    } else if (event.order === -1) {
      event.data = event.data.sort((a, b) => b[event.field] - a[event.field]);
    }
  }
  onEdited() {
    this.forecastLineService.showHide.next(true);
  }
  keyPress(event: any) {
    const pattern = /[0-9]/;
    const inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }
}
