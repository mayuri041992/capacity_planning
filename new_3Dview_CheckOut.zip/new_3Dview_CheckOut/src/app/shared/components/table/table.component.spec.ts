import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TableComponent } from './table.component';
import { CUSTOM_ELEMENTS_SCHEMA, Component, Input, OnChanges, ViewEncapsulation, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { of } from 'rxjs';

describe('TableComponent', () => {
  let component: TableComponent;
  let fixture: ComponentFixture<TableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, TableModule, PaginatorModule],
      declarations: [TableComponent],
      providers : [ForecastLineService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    const forecastLineService = fixture.debugElement.injector.get(ForecastLineService);
    spyOn(forecastLineService, 'tableAccountData$').and.returnValue(of('some data'));
    expect(component).toBeTruthy();
  });

  it('should check editRow', () => {
    const rowDetails = [ {1141 : 'BSE/K'},
    {BB10Gforecast: '13866'},
    {FastEforecast: '1256'},
    {GigEforecast: '14155'},
    {HE10Gforecast: '15966'},
    {Site : 'BRYNMAWR'},
    {id: 10273} ];
    const index = 2;
    component.editRow(rowDetails, index);
    expect(component.editRow).toBeDefined();
  });

  it('should check onDelete', () => {
    const rowDetails = [ {1141 : 'BSE/K'},
    {BB10Gforecast: '13866'},
    {FastEforecast: '1256'},
    {GigEforecast: '14155'},
    {HE10Gforecast: '15966'},
    {Site : 'BRYNMAWR'},
    {id: 10273} ];
    const index = 2;
    component.onDelete(rowDetails, index);
    expect(component.onDelete).toBeDefined();
  });

  it('should check ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeDefined();
  });

  it('should check ngOnChanges', () => {
    component.totalCount = 100;
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeDefined();
  });
  it('should check selectChange', () => {
    component.totalRecord = 20;
    component.selectChange();
    expect(component.selectChange).toBeDefined();
  });
  it('should check selectChange', () => {
    component.totalRecord = 20;
    component.totalCount = 100;
    component.selectChange();
    expect(component.selectChange).toBeDefined();
  });
  it('should check paginate', () => {
    const event = {
      rows: 3,
      first: 'sdf'
    };
    component.paginate(event);
    expect(component.paginate).toBeDefined();
  });
  it('should check paginate', () => {

    const event = {
      rows: 3,
      first: 'sdf',
      page: 20,
    };
    component.totalRecord = 200;
    component.totalCount = 10;
    component.paginate(event);
    expect(component.paginate).toBeDefined();
  });
  it('should check ngOnChanges', () => {
    // tslint:disable-next-line:max-line-length
    component.rows = [{id: '1', forecastCode: '321', siteName: 'shngalore', fastEforecast: '100', gigEforecast: '21', hE10Gforecast: '30', bB10Gforecast: '14'},
    // tslint:disable-next-line:max-line-length
    {id: '2', forecastCode: 'sahoo', siteName: 'sarnataka', fastEforecast: '50', gigEforecast: '12', hE10Gforecast: '39', bB10Gforecast: '22'},
    // tslint:disable-next-line:max-line-length
    {id: '4', forecastCode: '765', siteName: 'shngalore', fastEforecast: '122', gigEforecast: '29', hE10Gforecast: '13', bB10Gforecast: '43'},
     // tslint:disable-next-line:max-line-length
     {id: '3', forecastCode: '987', siteName: 'sarnataka', fastEforecast: '1', gigEforecast: '32', hE10Gforecast: '43', bB10Gforecast: '44'}],

    component.totalRecord = 20;
    component.totalCount = 2;
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeDefined();
  });
  it('should check sorting function', () => {
      const event = {
        order: 1,
        // tslint:disable-next-line:max-line-length
        data: [{id: '1', forecastCode: '321', siteName: 'shngalore', fastEforecast: '100', gigEforecast: '21', hE10Gforecast: '30', bB10Gforecast: '14'},
        // tslint:disable-next-line:max-line-length
        {id: '2', forecastCode: 'sahoo', siteName: 'sarnataka', fastEforecast: '50', gigEforecast: '12', hE10Gforecast: '39', bB10Gforecast: '22'},
        // tslint:disable-next-line:max-line-length
        {id: '4', forecastCode: '765', siteName: 'shngalore', fastEforecast: '122', gigEforecast: '29', hE10Gforecast: '13', bB10Gforecast: '43'},
         // tslint:disable-next-line:max-line-length
         {id: '3', forecastCode: '987', siteName: 'sarnataka', fastEforecast: '1', gigEforecast: '32', hE10Gforecast: '43', bB10Gforecast: '44'}],
        field: 'fastEforecast'
      };
      component.customSort(event);
      expect(component.customSort).toBeDefined();
  });
  it('should check sorting function', () => {
    const event = {
      order: -1,
     // tslint:disable-next-line:max-line-length
     data: [{id: '1', forecastCode: '321', siteName: 'shngalore', fastEforecast: '100', gigEforecast: '21', hE10Gforecast: '30', bB10Gforecast: '14'},
     // tslint:disable-next-line:max-line-length
     {id: '2', forecastCode: 'sahoo', siteName: 'sarnataka', fastEforecast: '50', gigEforecast: '12', hE10Gforecast: '39', bB10Gforecast: '22'},
     // tslint:disable-next-line:max-line-length
     {id: '4', forecastCode: '765', siteName: 'shngalore', fastEforecast: '122', gigEforecast: '29', hE10Gforecast: '13', bB10Gforecast: '43'},
      // tslint:disable-next-line:max-line-length
      {id: '3', forecastCode: '987', siteName: 'sarnataka', fastEforecast: '1', gigEforecast: '32', hE10Gforecast: '43', bB10Gforecast: '44'}],
     field: 'fastEforecast'
    };
    component.customSort(event);
    expect(component.customSort).toBeDefined();
});
  it('should check number', () => {
  const event = {
    charCode: 66,
    preventDefault() { }
  };
  const pattern = /[0-9]/;
  component.keyPress(event);
  expect(component.keyPress).toBeDefined();
});

  it('should check the onSubmit()', () => {
    component.onEdited();
    expect(component.onEdited).toBeDefined();
  });

});
