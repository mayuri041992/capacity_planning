// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { BarChartComponent } from './bar-chart.component';
// import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
// import { of } from 'rxjs';



// describe('BarChartComponent', () => {
//   let component: BarChartComponent;
//   let fixture: ComponentFixture<BarChartComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ BarChartComponent ],
//       schemas: [
//         CUSTOM_ELEMENTS_SCHEMA , NO_ERRORS_SCHEMA
//       ],
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(BarChartComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     component.options.animation.onComplete();
//     spyOn(component.options.animation, 'onComplete').and.returnValue(of());
//    // expect(component.options.animation.onComplete).toHaveBeenCalled();
//     expect(component).toBeTruthy();
//   });

//   it('should define download', () => {
//     component.download();
//     expect(component.download).toBeTruthy();
//   });

//   it('should define ngOnChanges', () => {
//     component.ngOnChanges();
//     expect(component.ngOnChanges).not.toBeNull();
//   });


// });
