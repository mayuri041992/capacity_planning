import { Component, OnInit, OnChanges, Input, ViewChild, ElementRef } from '@angular/core';
import * as html2canvas from 'html2canvas';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit, OnChanges {
  data: any;
  options;
  @Input() bardata;
  @ViewChild('abc') screen: ElementRef;
  @ViewChild('canvas') canvas: ElementRef;
  @ViewChild('downloadLink') downloadLink: ElementRef;
  constructor() {
    this.options = {

      legend: { display: false },
      plugins: {
        // Change options for ALL labels of THIS CHART
        datalabels: {
            color: '#36A2EB',
            font: {
              weight: 'bold',
              size: 0,
            }
        }
    },
      tooltips: {
        enabled: true
      },
      hover: {
        animationDuration: 1
      },
      scales: {
        yAxes: [{
          ticks: {
            // stepSize: 4,
            beginAtZero: true
          }
        }]
      },
      title: {
        display: true,
        text: 'No of Ports',
        position: 'left'
      },
      layout: {
        padding: {
            left: 0,
            right: 10,
            top: 20,
            bottom: 0
        }
    },
    animation: {
      duration: 1,
      // tslint:disable-next-line:object-literal-shorthand
      onComplete: function() {
        const chartInstance = this.chart;
        if (chartInstance) {
          const ctx = chartInstance.ctx;
          ctx.textAlign = 'center';
          ctx.fillStyle = 'rgba(0, 0, 0, 1)';
          ctx.textBaseline = 'bottom';
          const values = [];
          const lablesCount = this.data.labels.length;
          const stackCount = 3;
          const dataSetClone = [...this.data.datasets];
          for (let l = 0; l < lablesCount; l++) {
            const labelWiseData = [];
            for (let s = 0; s < stackCount; s++) {
              const stackItems = dataSetClone.filter((data) => data.stack === s + 1);
              const overallStackData = stackItems.reduce((acc, cur) => {
                acc = acc + cur.data[l];
                return acc;
              }, 0);
              labelWiseData.push(overallStackData);
            }
            values.push(labelWiseData);
          }
          this.data.datasets.forEach((dataset, i) => {
            const meta = chartInstance.controller.getDatasetMeta(i);
            meta.data.forEach((bar, index) => {
              if ((i + 1) % 3 === 0 ) {
                // console.log(values[index][0]);
                ctx.fillText(values[index][0], bar._model.x, bar._model.y - 0);
                values[index].splice(0, 1);
              }
            });
          });
        }
      }
    }
    };
  }
  ngOnInit() { }
  ngOnChanges() {
    this.data = this.bardata;
  }
  download() {
    window.scrollTo(0, 0);
    setTimeout(() => {
    html2canvas.default(document.querySelector('.barcharts').closest('.card-dashboard') as HTMLElement).then( ( canvas ) => {
      this.canvas.nativeElement.src = canvas.toDataURL();
       // const that = this;
      this.canvas.nativeElement.src = canvas.toDataURL();
      //  this.downloadLink.nativeElement.href = canvas.toDataURL('image/png');
      const hrefData = canvas.toDataURL('image/png').replace('data:image/png;base64,', '');
      const blobData = this.convertBase64ToBlobData(hrefData);
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blobData, 'bar-chart.png');
      } else { // chrome
        const blob = new Blob([blobData], { type: 'image/png' });
        const url = window.URL.createObjectURL(blob);
        // window.open(url);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'bar-chart';
        link.click();
      }

    }); }, 500);
  }
  convertBase64ToBlobData(base64Data: string, contentType: string = 'image/png', sliceSize = 512) {
    const byteCharacters = atob(base64Data);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      const slice = byteCharacters.slice(offset, offset + sliceSize);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    const blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }

}
