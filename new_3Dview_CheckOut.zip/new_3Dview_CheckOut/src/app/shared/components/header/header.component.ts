import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { LoginService } from '../../../core/services/login-service/login.service';
import { ChassisViewComponent } from '../../../components/chassis-view/chassis-view.component';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [Location, {provide: LocationStrategy, useClass: PathLocationStrategy}],
})
export class HeaderComponent implements OnInit {
  userProfile = [];
  headerUser = '';
  redirectTo;
  dropDownOnHeader = true;
  userRoleProfile: Array<any> = [];
  location: Location;
  loggedIN = true;
  modalRadio: any = [{ id: 'VIEWER', title: 'Capacity Planning User', value: false },
  { id: 'ADMIN', title: 'Capacity Planning Admin', value: false },
  { id: 'DESIGNER', title: 'Capacity Planning Accounting User', value: true }];

  constructor(private modalService: NgbModal,
              private modalCloseService: NgbActiveModal,
              private router: Router, private loginService: LoginService,
              location: Location) {
    this.location = location;
    environment.ein = this.loginService.EIN;
    environment.userRole = this.loginService.GroupName;
    const userRole = environment.userRole;
    if (userRole) {
      const usersplit = userRole.split('^');
      usersplit.forEach(role => {
        const user = role.split('_').pop();
        this.userProfile.push(user);
      });
      this.userProfile.forEach((role) => {
        this.modalRadio.forEach((data) => {
          if (data.id === role) {
            this.userRoleProfile.push(data);
          }
        });
      });
      if (this.userProfile.indexOf('DESIGNER') !== -1) {
        this.headerUser = 'Capacity Planning Accounting User';
        this.router.navigate(['/forecast']);
        this.dropDownOnHeader = true;
        // this.modalService.dismissAll();
      } else if (this.userProfile.indexOf('ADMIN') !== -1) {
        this.headerUser = 'Capacity Planning Admin';
        this.router.navigate(['/dashboard']);
        this.userRoleProfile.forEach((data) => {
          if (data.id === 'ADMIN') {
            this.dropDownOnHeader = false;
            data.value = true;
          }
        });
      } else {
        this.headerUser = 'Capacity Planning User';
        this.router.navigate(['/dashboard']);
        this.userRoleProfile.forEach((data) => {
          if (data.id === 'VIEWER') {
            this.dropDownOnHeader = false;
            data.value = true;
          }
        });
      }
    }
  }
  ngOnInit() {
    this.loginService.userProfileRole = this.userProfile;
  }
  toggle(titleId) {
    this.redirectTo = titleId;
  }
  openVerticallyCentered(content) {
    this.modalService.open(content, { centered: true, windowClass: 'head-switch-modal' });
  }
  getRadioSelected() {
    this.userRoleProfile.forEach((data) => {
      // added if condition to check redirectTo is undefined or not
      if (this.redirectTo) {
        if (data.id === this.redirectTo) {
          if (this.redirectTo === 'DESIGNER') {
            this.dropDownOnHeader = true;
            this.router.navigate(['/forecast']);
          }
          if (this.redirectTo === 'VIEWER') {
            this.dropDownOnHeader = false;
            this.router.navigate(['/dashboard']);
          }
          if (this.redirectTo === 'ADMIN') {
            this.dropDownOnHeader = false;
            this.router.navigate(['/dashboard']);
          }
          this.headerUser = data.title;
          data.value = true;
        } else {
          data.value = false;
        }
      }
    });
    this.modalService.dismissAll();
  }
  refreshPage() {
    // tslint:disable-next-line:no-string-literal
    const refreahURL = (this.location['_platformStrategy']._platformLocation.location.hash).split('#').join('');
    this.router.navigateByUrl(refreahURL, {skipLocationChange: true}).then(() =>
    this.router.navigate([refreahURL]));
    this.router.routeReuseStrategy.shouldReuseRoute = () => {
       return false;
      };
    }
  logoutfinal() {
  //  this.services.getLogout().subscribe((data) => {
      this.loggedIN = false;
      document.execCommand('ClearAuthenticationCache');
      this.router.navigate(['/logout']);
      this.dropDownOnHeader = true;
  }
  navigateToUrl(navigateUrl) {
    this.router.navigate(['/' + navigateUrl]);
    this.ngOnInit();
    if (navigateUrl === 'dashboard') {
      if (this.userProfile.indexOf('ADMIN') !== -1) {
        this.headerUser = 'Capacity Planning Admin';
        // this.router.navigate(['/dashboard']);
        this.userRoleProfile.forEach((data) => {
          if (data.id === 'ADMIN') {
            data.value = true;
          } else {
            data.value = false;
          }
        });
      } else {
        this.headerUser = 'Capacity Planning User';
       // this.router.navigate(['/dashboard']);
        this.userRoleProfile.forEach((data) => {
          if (data.id === 'VIEWER') {
            data.value = true;
          } else {
            data.value = false;
          }
        });
      }
    }
  }
}

