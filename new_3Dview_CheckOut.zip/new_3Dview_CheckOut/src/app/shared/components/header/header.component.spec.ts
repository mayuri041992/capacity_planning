import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from './header.component';
import { LoginService } from '../../../core/services/login-service/login.service';
import { SvgComponent } from '../svg/svg.component';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NgbModal, NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { environment } from '../../../../environments/environment';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  class MockRouter {
    navigate = jasmine.createSpy('navigate');
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgbModule],
      declarations: [HeaderComponent, SvgComponent],
      providers: [LoginService, NgbActiveModal, { provide: Router, useClass: MockRouter }],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    // window.localStorage.setItem('EIN', '612532739');
    // window.localStorage.setItem('GroupName', 'PRE_PROD_CE_ADMIN^PRE_PROD_CE_DESIGNER');

  });

  it('should create Header', () => {
    expect(component).toBeTruthy();
  });

  it('should create Header else', () => {
    const loginService = fixture.debugElement.injector.get(LoginService);
    environment.ein = loginService.EIN;
    environment.userRole = loginService.GroupName;
    component.userProfile = [ { id: 'VIEWER', title: 'C  apacity Planning User', value: false },
     { id: 'DESIGNER', title: 'Capacity Planning Accounting User', value: true },
     {id: 'ADMIN', title: 'Capacity Planning Admin', value: false }];

    expect(component).toBeTruthy();
  });

  it('should create Header else', () => {
    const loginService = fixture.debugElement.injector.get(LoginService);
    environment.ein = loginService.EIN;
    loginService.GroupName =  'PRE_PROD_CE_VIEWER';
    component.userProfile = [ { id: 'VIEWER', title: 'C  apacity Planning User', value: true },
     {id: 'ADMIN', title: 'Capacity Planning Admin', value: false }];
    expect(component).toBeTruthy();
  });
  it('should create Header else', () => {
    const loginService = fixture.debugElement.injector.get(LoginService);
    environment.ein = loginService.EIN;
    loginService.GroupName =  'PRE_PROD_CE_ADMIN';
    component.userProfile = [ { id: 'VIEWER', title: 'C  apacity Planning User', value: false },
     {id: 'ADMIN', title: 'Capacity Planning Admin', value: true }];

    expect(component).toBeTruthy();
  });

  it('should render title Capacity Planning', () => {
    // tslint:disable-next-line:no-shadowed-variable
    const fixture = TestBed.createComponent(HeaderComponent);
    const title = 'Capacity Planning';
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(title).toContain('Capacity Planning');
  });

  // it('should check refreshPage', () => {
  //   component.refreshPage();
  //   expect(component.refreshPage).toBeDefined();
  // });
  it('should check logoutfinal', () => {
    component.logoutfinal();
    expect(component.logoutfinal).toBeDefined();
  });

  it('should check toggle', () => {
    const titleId = true;
    component.toggle(titleId);
    expect(component.toggle).toBeDefined();
  });

  it('should check openVerticallyCentered', () => {
    const content = 'true';
    component.openVerticallyCentered(content);
    expect(component.openVerticallyCentered).toBeDefined();
  });

  it('should check constructor', () => {
    const EIN = '612532739';
    expect(component.constructor).toBeDefined();
  });

  it('should check getRadioSelected', () => {
    component.userRoleProfile = [{ id: 'DESIGNER', title: 'Capacity Planning Accounting User', value: true }];
    //  expect(location.path(true)).toBe('');
    component.getRadioSelected();
    expect(component.getRadioSelected).toBeDefined();
  });

  it('should check getRadioSelected', () => {
    component.redirectTo = 'DESIGNER';
    component.userRoleProfile = [{ id: 'DESIGNER', title: 'Capacity Planning Accounting User', value: true }];
    // expect(location.path(true)).toBe('');
    component.getRadioSelected();
    expect(component.getRadioSelected).toBeDefined();
  });
  it('should check getRadioSelected', () => {
    component.redirectTo = 'ADMIN';
    component.userRoleProfile = [{ id: 'ADMIN', title: 'Capacity Planning Admin', value: false }];
    // expect(location.path(true)).toBe('');
    component.getRadioSelected();
    expect(component.getRadioSelected).toBeDefined();
  });
  it('should check getRadioSelected', () => {
    component.redirectTo = 'VIEWER';
    component.userRoleProfile = [{ id: 'VIEWER', title: 'Capacity Planning User', value: false }];
    // expect(location.path(true)).toBe('');
    component.getRadioSelected();
    expect(component.getRadioSelected).toBeDefined();
  });

  it('should check navigateToUrl', () => {
    const navigateUrl = 'dashboard';
    component.navigateToUrl(navigateUrl);
    expect(component.navigateToUrl).toBeDefined();
  });

  it('should check navigateToUrl else case', () => {
    const navigateUrl = 'dashboard';
    component.userProfile = [{ id: 'ADMIN', title: 'Capacity Planning Admin', value: false },
    { id: 'VIEWER', title: 'Capacity Planning User', value: false },
    { id: 'DESIGNER', title: 'Capacity Planning Accounting User', value: true }];
    component.navigateToUrl(navigateUrl);
    expect(component.navigateToUrl).toBeDefined();
  });
});
