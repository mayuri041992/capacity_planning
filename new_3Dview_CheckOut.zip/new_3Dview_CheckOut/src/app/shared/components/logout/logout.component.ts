import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppService } from 'src/app/core/services/app-service/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit, OnDestroy {
  constructor(private services: AppService, private router: Router) {
    // const ClearHeader = document.getElementsByClassName('width-custom');
    // ClearHeader[0].innerHTML = '';
   }
  ngOnInit() {
  }

  onNavigation() {
   window.location.href = this.services.logInPage();
    }
    ngOnDestroy() {
      window.location.href = this.services.logInPage();
    }
}
