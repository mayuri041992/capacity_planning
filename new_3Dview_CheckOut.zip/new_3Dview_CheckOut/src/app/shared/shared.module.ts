import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SvgComponent } from './components/svg/svg.component';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TabComponentDirective } from './directive/tab-component.directive';
import { HeaderComponent } from './components/header/header.component';
import { TableComponent } from './components/table/table.component';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import {KeyFilterModule} from 'primeng/keyfilter';
import { LogoutComponent } from './components/logout/logout.component';
import { KeyStatsticsTableComponent } from './components/key-statstics-table/key-statstics-table.component';
import { PieChartComponent } from './components/pie-chart/pie-chart.component';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { BarChartComponent } from './components/bar-chart/bar-chart.component';
import { GoogleChartsModule } from 'angular-google-charts';
import {ChartModule} from 'primeng/chart';
import { InfoComponent } from './components/info/info.component';


@NgModule({
  declarations: [SvgComponent, TabComponentDirective, HeaderComponent, TableComponent, LogoutComponent,
                  KeyStatsticsTableComponent, PieChartComponent, LineChartComponent, BarChartComponent, InfoComponent],
  imports: [
    CommonModule,
    RouterModule,
    NgbModule,
    PaginatorModule,
    TableModule,
    KeyFilterModule,
    GoogleChartsModule,
    ChartModule
  ],
  exports: [
    CommonModule,
    SvgComponent,
    TabComponentDirective,
    HeaderComponent,
    TableComponent,
    LineChartComponent,
    PieChartComponent,
    KeyStatsticsTableComponent,
    BarChartComponent,
    InfoComponent,
  ]
})
export class SharedModule { }
