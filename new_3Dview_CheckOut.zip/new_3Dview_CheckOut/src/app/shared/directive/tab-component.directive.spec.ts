import { TabComponentDirective } from './tab-component.directive';

describe('TabComponentDirective', () => {
  /*   it('should create an instance', () => {
      const directive = new TabComponentDirective();
      expect(directive).toBeTruthy();
    }); */
});
