import { Directive, ComponentFactoryResolver, ViewContainerRef, Input, OnInit, OnChanges } from '@angular/core';
import { Tab } from '../models/forecast.model';
import { UploadForecastComponent } from '../../features/accounting/upload-forecast/upload-forecast.component';
import { ManageForecastComponent } from '../../features/accounting/manage-forecast/manage-forecast.component';

export const TabComponentMapper = {
  upload_forecast: UploadForecastComponent,
  manage_forecast: ManageForecastComponent
};

@Directive({
  selector: '[appTabComponent]'
})
export class TabComponentDirective implements OnInit, OnChanges {
  tabs: Tab;
  @Input('tab') set setTab(tabs: Tab[]) {
    this.tabs = tabs && tabs.length > 0 ? tabs[0] : {} as Tab;
  }
  componentRef: any;
  constructor(private resolver: ComponentFactoryResolver, private container: ViewContainerRef) {
  }
  ngOnInit() {
  }
  ngOnChanges() {
    this.container.clear();
    const component = this.tabs.name ? TabComponentMapper[this.tabs.name] : null;
    if (component) {
      const factory = this.resolver.resolveComponentFactory(component);
      this.componentRef = this.container.createComponent(factory);
    }
  }

}
