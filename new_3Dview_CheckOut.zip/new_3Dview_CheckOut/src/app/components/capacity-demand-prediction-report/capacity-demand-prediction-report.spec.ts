import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CapacityDemandPredictionComponent } from './capacity-demand-prediction-report';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppService } from '../../core/services/app-service/app.service';
import { NgxLoadingModule } from 'ngx-loading';
import { SvgComponent } from '../../shared/components/svg/svg.component';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
import { tap } from 'rxjs/operators';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { MessageService } from 'primeng/api';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Component, Renderer, ElementRef } from '@angular/core';
import { LoginService } from '../../core/services/login-service/login.service';
import { pageObject } from '../../shared/models/pageObject.model';
import { of } from 'rxjs';
import { filterObject } from '../../shared/models/filterObject.model';
import { Routes, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

describe('CapacityDemandPredictionComponent', () => {
  let component: CapacityDemandPredictionComponent;
  let fixture: ComponentFixture<CapacityDemandPredictionComponent>;
  let service: AppService;
  let httpTestingController: HttpTestingController;
  const columns: any = [];
  let newTabInstance;
  let pageData = new pageObject();
  // tslint:disable-next-line:prefer-const
  let initFilterObject$;

  const scrollable: Array<any> = [
    { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '7%' },
    { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '5%' },
    { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
    { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '6%' },
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
    { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
    { header: 'Product Line forecast', field: 'forCastPorts', pfCheck: true, width: '12%' },
  ];
  const menuToggleSpy = jasmine.createSpy('event');
  const col = [

    { header: 'Site', field: 'siteName', pfCheck: true, width: '14%' },
    { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
    { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
    { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
    { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
    { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '10%' },
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' }
  ];

  beforeEach(async(() => {

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxLoadingModule, TableModule, PaginatorModule, NgbModule, RouterModule, RouterTestingModule],
      declarations: [CapacityDemandPredictionComponent, SvgComponent],
      providers: [AppService, LoginService, MessageService]
    })
      .compileComponents();
    service = TestBed.get(AppService);
    httpTestingController = TestBed.get(HttpTestingController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CapacityDemandPredictionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

  });
  it('should check component', () => {
    component.pageData = {
      pageNo: '1',
      pageSize: '10',
      sortByField: false,
      sortOrder: false,
      siteName: ' ',
      exchangeCode: ' ',
      enableSorting: true
    };
    component.searchInput = 'yigfyis';
    const appService = fixture.debugElement.injector.get(AppService);
    appService.showdata.next(true);
    spyOn(appService, 'showdata').and.returnValue(of('some data'));
    expect(component).toBeTruthy();
  });


  it('should check function selectChange', () => {
    spyOn(component, 'selectChange').and.callThrough();

    service.initPageObject.subscribe((data) => {
    });
    pageData = {
    pageNo: 0,
    pageSize: 200,
    sortByField: '',
    sortOrder: '',
    siteName: '',
    exchangeCode: '',
    enableSorting: ''
    };
    service.initFilterObject.subscribe((data) => {
    });
    pageData = {
    pageNo: 0,
    pageSize: 200,
    sortByField: '',
    sortOrder: '',
    siteName: '',
    exchangeCode: '',
    enableSorting: ''
    };
    component.totalCount = 100;
    component.selectChange();
    expect(component.selectChange).toBeDefined();
  });

  it('should check function paginate', () => {
    // tslint:disable-next-line:prefer-const
    let event = {
      page: [1, 2, 3, 4],
    };
    spyOn(component, 'paginate').and.callThrough();
    const clickButton = fixture.nativeElement.querySelector('p-paginator');
    service.initPageObject.subscribe((data) => {
    });
    component.paginate(event);
    expect(component.paginate).toBeDefined();
  });

  it('should check function paginate else', () => {
    // tslint:disable-next-line:prefer-const
    let event = {
      page: [1, 2, 3, 4],
    };
    component.totalCount = 100;
    component.totalRecord = 0;
    spyOn(component, 'paginate').and.callThrough();
    const clickButton = fixture.nativeElement.querySelector('p-paginator');
    service.initPageObject.subscribe((data) => {
    });
    component.paginate(event);
    expect(component.paginate).toBeDefined();
  });

  it('should check function onClear', () => {
    // tslint:disable-next-line:prefer-const
    let event = {
      target: {
        value: 'some'
      }
    };
    // tslint:disable-next-line:prefer-const
    let filterData = 'some';
    spyOn(component, 'onClear').and.callThrough();
    spyOn(service, 'initPageObject').and.callThrough();

    service.initPageObject.subscribe((data) => {
    });
    component.onClear(event);
    expect(component.onClear).toBeDefined();
  });

  it('should check function onClear if condition' , () => {
    // tslint:disable-next-line:prefer-const
    let event = {
      target: {
        value: ''
      }
    };
    component.pageData = {
      pageNo: '1',
      pageSize: '10',
      sortByField: false,
      sortOrder: false,
      siteName: 'yigfyis',
      exchangeCode: 'yigfyis',
      enableSorting: true
    };
    // let filterData = '';
    spyOn(component, 'onClear').and.callThrough();
    spyOn(service, 'initPageObject').and.callThrough();

    service.initPageObject.subscribe((data) => {
    });
    component.onClear(event);
    expect(component.onClear).toBeDefined();
  });





  it('should check function toggle', () => {
    // tslint:disable-next-line:no-shadowed-variable
    const col = {
      pfCheck: true
    };
    component.toggle(col);
    expect(component.toggle).toBeDefined();
  });

  it('should check function isChecked', () => {
     // tslint:disable-next-line:no-shadowed-variable
    const col = {
      header: 'true'
    };
    component.isChecked(col);
    expect(component.isChecked).toBeTruthy();
  });

  it('should check function open', () => {
    // tslint:disable-next-line:prefer-const
    let content = 'some';
    component.open(content);
    expect(component.open).toBeDefined();
  });

  it('should check function convert', () => {
    // tslint:disable-next-line:prefer-const
    let param = 'csv';
    component.convert(param);
    expect(component.convert).toBeDefined();
  });

  it('should check function convert Else', () => {
     // tslint:disable-next-line:prefer-const
    let param = 'pdf';
    component.convert(param);
    expect(component.convert).toBeDefined();
  });

  it('should check function getSavedPreferenceData', () => {
     // tslint:disable-next-line:prefer-const
    let filter = [
      { id: 79, filterName: 'Card Model', filterValue: 'IMM 1 x 100G', selected: true },
      { id: 44, filterName: 'Card Type', filterValue: '1 x 10GB MDA', selected: true },
      { id: 56, filterName: 'Card Version', filterValue: '(12Pt Lic)', selected: true },
      { id: 16, filterName: 'Chassis Speed', filterValue: '1 TB', selected: true },
      { id: 1, filterName: 'Device Model', filterValue: '7750 SR-12', selected: true },
      { id: 6, filterName: 'Device Type', filterValue: 'Edge Rt', selected: true },
      { id: 3, filterName: 'Device Usage', filterValue: 'EEA', selected: true },
      { id: 7, filterName: 'Device Version', filterValue: '(N/A)', selected: true },
      { id: 18, filterName: 'Market Type', filterValue: 'Market A', selected: true },
      { id: 69, filterName: 'Node Type', filterValue: 'CMSAN', selected: true },
      { id: 14, filterName: 'Port Speed', filterValue: '100GE', selected: true },
      { id: 10, filterName: 'Product Type', filterValue: 'Backhaul', selected: true }
    ];
    const appService = fixture.debugElement.injector.get(AppService);
    appService.addSavePreferenceSubject.next('filter2');
    spyOn(appService, 'addSavePreferenceSubject').and.returnValue(of('some data'));
    component.getSavedPreferenceData();
    expect(component.getSavedPreferenceData).toBeDefined();
  });

  it('should check function selected', () => {
     // tslint:disable-next-line:prefer-const
    let item = 'true';
    component.selected(item);
    expect(component.selected).toBeDefined();
  });

  it('should check function gridDataService', () => {
     // tslint:disable-next-line:prefer-const
    let exchangeInfoFilterRequest = {
      deviceModel: [],
      deviceUsages: [],
      deviceType: [],
      deviceVersion: [],
      productType: '',
      portSpeed: [],
      chassisSpeed: [],
      cardModel: [],
      cardType: [],
      cardVersion: [],
      marketType: [],
      nodeType: [],
      ein: 6125327639
    };
     // tslint:disable-next-line:prefer-const
    let productType = 'Broadband';
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
    const appService = fixture.debugElement.injector.get(AppService);
    appService.selectedFilter.next(true);
    spyOn(appService, 'selectedFilter').and.returnValue(of('some data'));
    appService.loading.next(true);
    spyOn(appService, 'loading').and.returnValue(of('some data'));
    appService.gridData.next([]);
    // spyOn(appService, 'gridData$').and.returnValue(of('some data'));
    appService.initFilterObject.next(new filterObject());
    spyOn(appService, 'initFilterObject$').and.returnValue(of('some data'));
    appService.Rowdata.next([]);
    // spyOn(component, 'gridDataService').and.callThrough();
    // spyOn(service, 'initPageObject').and.callThrough();
    service.initPageObject.subscribe((data) => {
    });
  });
  it('should check function gridDataService', () => {
     // tslint:disable-next-line:prefer-const
    let exchangeInfoFilterRequest = {
      deviceModel: [],
      deviceUsages: [],
      deviceType: [],
      deviceVersion: [],
      productType: '',
      portSpeed: [],
      chassisSpeed: [],
      cardModel: [],
      cardType: [],
      cardVersion: [],
      marketType: [],
      nodeType: [],
      ein: 6125327639
    };
     // tslint:disable-next-line:prefer-const
    let productType = 'Backhaul';
    spyOn(component, 'gridDataService').and.callThrough();
    spyOn(service, 'initPageObject').and.callThrough();
    service.initPageObject.subscribe((data) => {
    });
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataService', () => {
    const exchangeInfoFilterRequest = {
      deviceModel: [],
      deviceUsages: [],
      deviceType: [],
      deviceVersion: [],
      productType: '',
      portSpeed: [],
      chassisSpeed: [],
      cardModel: [],
      cardType: [],
      cardVersion: [],
      marketType: [],
      nodeType: [],
      ein: 6125327639
    };
    const productType = 'Ethernet';
    spyOn(component, 'gridDataService').and.callThrough();
    spyOn(service, 'initPageObject').and.callThrough();
    service.initPageObject.subscribe((data) => {
    });
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });

  it('should check function ngOnInit', () => {
    const fileDataInput = {
      id: 54353, isRefreshRequired: true, title: 'demo',
      type: 'CE_CatelogueEditor', templateType: 'Bearer Type',
      data: { fileCategoryID: 24, categoryName: 'Resource Specification' }, close: true
    };
    service.showdata.subscribe(message => {
      newTabInstance = message;
    });
    spyOn(service, 'showdata').and.returnValue(of(fileDataInput));
    fixture.whenStable().then(() => {
      expect(newTabInstance).toEqual(undefined);
    });
  });

  it('should check function gridDataService', () => {
    const savedPre = {
       exchangeInfoResponse: {
       totalPorts: true,
       usedPorts: true,
       reserved: true,
       freePorts: true,
       freeSlots: true,
       broadBandRem: true,
       broadBandColo: true,
       ethernetNonTodPorts: true,
       ethernetTodPorts: true,
      },
    };
    spyOn(service, 'Rowdata').and.returnValue(of(savedPre));
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });

  it('should check function gridDataService', () => {
    const data = {
        exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Broadband',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '10%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
      { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '10%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '10%' },
      { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
      { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
       { header: 'Delta', field: 'delta', pfCheck: true, width: '10%' },
    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridData for Ethernet', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceMode: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Ethernet',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });

  it('should check function gridDataEthernet', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Ethernet',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '10%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '6%' },
      { header: 'Potential BB/Eth Ports', field: 'potential10gBBETHPorts', pfCheck: true, width: '7%' },
      { header: 'Potential Eth Ports', field: 'potential10gETHPorts', pfCheck: true, width: '7%' },
      { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '7%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '7%' },
      { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '7%' },
      { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '7%' },
      { header: 'Delta', field: 'delta', pfCheck: true, width: '4%' },
    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataBroadband', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Broadband',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '10%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '5%' },
      { header: 'Potential BB Ports', field: 'potential10gBBETHPorts', pfCheck: true, width: '5%' },
      { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '6%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '6%' },
      { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '5%' },
      { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '7%' },
      { header: 'Delta', field: 'delta', pfCheck: true, width: '4%' },
    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });

  it('should check function gridDataBackhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Backhaul',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '12%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },

    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataP2PE', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'P2PE',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '12%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },

    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataPRTC', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'PRTC',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '12%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },

    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataDCN', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'DCN',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '12%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },

    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataInfrastructure', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Infrastructure',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '12%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },

    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataBlocked', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Blocked',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '12%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },

    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function gridDataVoice', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Voice',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.columnShow = [
      { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
      { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
      { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
      { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
      { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
      { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
      { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '12%' },
      { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
      { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '12%' },
      { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },

    ];
    component.gridDataService();
    expect(component.gridDataService).toBeDefined();
  });
  it('should check function saveData', () => {
    const savedPre = {
      exchangeInfoResponse: {
        totalPorts: true,
        usedPorts: true,
        reserved: true,
        freePorts: true,
        freeSlots: true,
        broadBandRem: true,
        broadBandColo: true,
        ethernetNonTodPorts: true,
        ethernetTodPorts: true,
        exchangeInfo: true
      },

    };

    component.totalCount  = 100;
    component.totalRecord = 100;
    component.numberPage = 2;

    component.saveData(savedPre);
    expect(component.saveData).toBeDefined();
  });
  it('should check function saveData', () => {
    const savedPre = {
      exchangeInfoResponse: null
    };

    component.saveData(savedPre);
    expect(component.saveData).toBeDefined();
  });

  it('should check function saveData totalCount ', () => {
    const savedPre = {
      exchangeInfoResponse: {
        totalPorts: true,
        usedPorts: true,
        reserved: true,
        freePorts: true,
        freeSlots: true,
        broadBandRem: true,
        broadBandColo: true,
        ethernetNonTodPorts: true,
        ethernetTodPorts: true,
        exchangeInfo: true
      },
    };
    component.totalRecord = 200;
    component.totalCount = 100;
    component.saveData(savedPre);
    expect(component.saveData).toBeDefined();
  });

  it('should check function saveData totalCount elsee ', () => {
    const savedPre = {
      exchangeInfoResponse: {
        totalPorts: true,
        usedPorts: true,
        reserved: true,
        freePorts: true,
        freeSlots: true,
        broadBandRem: true,
        broadBandColo: true,
        ethernetNonTodPorts: true,
        ethernetTodPorts: true,
        exchangeInfo: true
      },
    };
    component.totalCount = 0;
    component.saveData(savedPre);
    expect(component.saveData).toBeDefined();
  });

  it('should check function saveDatatotalCount ', () => {
    const savedPre = {
      exchangeInfoResponse: {
        totalRecords: 1185,
        usedPorts: true,
        reserved: true,
        freePorts: true,
        freeSlots: true,
        broadBandRem: true,
        broadBandColo: true,
        ethernetNonTodPorts: true,
        ethernetTodPorts: true,
        exchangeInfo: false
      },
    };
  //  component.totalRecord = 100;
    component.totalCount = 200;
    component.numberPage = 7;
    component.saveData(savedPre);
    expect(component.saveData).toBeDefined();
  });
  it('should check function saveDatatotalCount ', () => {
    const savedPre = {
      exchangeInfoResponse: {
        totalRecords: 14,
        usedPorts: true,
        reserved: true,
        freePorts: true,
        freeSlots: true,
        broadBandRem: true,
        broadBandColo: true,
        ethernetNonTodPorts: true,
        ethernetTodPorts: true,
        exchangeInfo: false
      },
    };
  //  component.totalRecord = 100;
    component.totalCount = 200;
    component.numberPage = 7;
    component.saveData(savedPre);
    expect(component.saveData).toBeDefined();
  });




  it('should check function saveDataNull', () => {
    const savedPre = {
      exchangeInfoResponse: {},
    };
    component.saveData(savedPre);
    expect(component.saveData).toBeDefined();
  });

  it('should check function dataResponseNull', () => {
    const res = {
      exchangeInfo: {},
    };
    component.dataResponse(res);
    expect(component.dataResponse).toBeDefined();
  });
  it('should check function dataResponse If condition', () => {
    component.siteExCode = 'AEL';
    const res = {
      exchangeInfo: [{
        id: 1,
        ein: 607981825,
        siteName: 'APPLEBY TE',
        exchangeCode: 'AEL',
        sauId: 'LCAPP',
        inFlightPorts: 0,
        totalPorts: 2,
        usedPorts: 2,
        reserved: 0,
        freePorts: 0,
        freeSlots: 10,
        broadBandRem: 0,
        broadBandColo: 0,
        ethernetNonTodPorts: 0,
        ethernetTodPorts: 0,
        forCastPorts: 0,
        plannedPorts: 0,
        buildPorts: 0,
        consumedPorts: 0,
        fasteForeCast: 0,
        gigeForeCast: 0,
        heForeCast: 0,
        bbForecast: 0,
        potential_10G_eth_ports: 0,
        potential_10G_BB_Eth_ports: 10,
      },
      {
        id: 4,
        ein: 607981825,
        siteName: 'BELFAST KNOCK',
        exchangeCode: 'KNU',
        sauId: 'NIKNK',
        inFlightPorts: 0,
        totalPorts: 2,
        usedPorts: 2,
        reserved: 0,
        freePorts: 0,
        freeSlots: 10,
        broadBandRem: 0,
        broadBandColo: 0,
        ethernetNonTodPorts: 0,
        ethernetTodPorts: 0,
        forCastPorts: 0,
        plannedPorts: 0,
        buildPorts: 0,
        consumedPorts: 0,
        fasteForeCast: 0,
        gigeForeCast: 0,
        heForeCast: 0,
        bbForecast: 0,
      },
      {
        id: 6,
        ein: 607981825,
        siteName: 'BIRMINGHAM CHELMSLEY',
        exchangeCode: 'BM/CHE',
        sauId: 'CMCHEL',
        inFlightPorts: 0,
        totalPorts: 2,
        usedPorts: 2,
        reserved: 0,
        freePorts: 0,
        freeSlots: 10,
        broadBandRem: 0,
        broadBandColo: 0,
        ethernetNonTodPorts: 0,
        ethernetTodPorts: 0,
        forCastPorts: 0,
        plannedPorts: 0,
        buildPorts: 0,
        consumedPorts: 0,
        fasteForeCast: 0,
        gigeForeCast: 0,
        heForeCast: 0,
        bbForecast: 0,
      }]
    };
    component.dataResponse(res);
    expect(component.dataResponse).toBeDefined();
  });

  it('should check function dataResponseNulltotalCount', () => {
    const res = {
      exchangeInfo: {},
    };
    component.totalCount = 100;
    component.dataResponse(res);
    expect(component.dataResponse).toBeDefined();
  });

  it('should check function toggle', () => {
    // tslint:disable-next-line:no-shadowed-variable
    const col = {
      field: 'sauId',
      pfCheck: true
    };
    const expt = { a: 'sauId' };
    component.toggle(col);
    expect(component.toggle).toBeDefined();
  });
  it('should check function togglefalse', () => {
    // tslint:disable-next-line:no-shadowed-variable
    const col = {
      field: 'sauId',
      pfCheck: false
    };
    const expt = { a: 'sauId' };
    component.toggle(col);
    expect(component.toggle).toBeDefined();
  });

  it('should check function toggleNull', () => {
    // tslint:disable-next-line:no-shadowed-variable
    const col = {
      field: '',
      pfCheck: false
    };
    const expt = { ANB: 'sauId' };
    component.toggle(col);
    expect(component.toggle).toBeDefined();
  });

  it('should check function toggleNull', () => {
    // tslint:disable-next-line:no-shadowed-variable
    const col = {
      field: '',
      pfCheck: true
    };
    const expt = { a: 'sauId' };
    component.toggle(col);
    expect(component.toggle).toBeDefined();
  });

  it('should check function toggleNullIndex', () => {
    // tslint:disable-next-line:no-shadowed-variable
    const col = {
      field: '',
      pfCheck: true
    };
    const expt = { a: 'sauId' };
    component.toggle(col);
    expect(component.toggle).toBeDefined();
  });



  it('should check function onSearchData', () => {
    component.pageData = {
      pageNo: '1',
      pageSize: '10',
      sortByField: false,
      sortOrder: false,
      siteName: 'test',
      exchangeCode: 'yigfyis',
      enableSorting: true
    };
    component.searchInput = '';
    component.onSearchData();
    expect(component.onSearchData).toBeDefined();
  });

  it('should check function onSearchData other if', () => {
    component.pageData = {
      pageNo: '1',
      pageSize: '10',
      sortByField: false,
      sortOrder: false,
      siteName: 'yigfyis',
      exchangeCode: 'yigfyis',
      enableSorting: true
    };
    component.searchInput = 'yigfyis';
    component.onSearchData();
    expect(component.onSearchData).toBeDefined();
  });

  it('should check function customSort', () => {
    const event = {
      order: 1
    };
    component.customSort(event);
    expect(component.customSort).toBeDefined();
  });

  it('should check function customSortElse', () => {
    const event = {
      order: -1,
    };
    component.pageData = {
      pageNo: '1',
      pageSize: '10',
      sortByField: false,
      sortOrder: false,
      siteName: 'test',
      exchangeCode: 'yigfyis',
      enableSorting: true
    };
    component.customSort(event);
    expect(component.customSort).toBeDefined();
  });

  it('should check function SwipeScrollColumn', () => {

    component.SwipeScrollColumn();
    expect(component.SwipeScrollColumn).toBeDefined();
  });

  it('should check function onClickNavigate', () => {
    const data = 'test';
    component.onClickNavigate(col);
    expect(component.onClickNavigate).toBeDefined();
  });

  it('should check function gridData for Broadband', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Broadband',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      },

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });

  it('should check function gridData for Backhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Backhaul',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      }

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });
  it('should check function gridData for Backhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'P2PE',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      }

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });
  it('should check function gridData for Backhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'PRTC',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      }

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });
  it('should check function gridData for Backhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'DCN',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      }

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });
  it('should check function gridData for Backhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Infrastructure',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      }

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });
  it('should check function gridData for Backhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Blocked',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      }

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });
  it('should check function gridData for Backhaul', () => {
    const data = {
      exchangeInfoFilterRequest: {
        deviceModel: '7750 SR 12',
        deviceUsages: [],
        deviceType: [],
        deviceVersion: [],
        productType: 'Voice',
        portSpeed: [
          'FE'
        ],
        chassisSpeed: [],
        cardModel: [],
        cardType: [],
        cardVersion: [],
        marketType: [],
        sortByField: 'siteName',
        pageNo: 0,
        pageSize: 0,
        sortOrder: true,
        siteName: '',
        Ex1141Code: '',
        enableSorting: false
      }

    };
    component.gridData(data);
    expect(component.gridData).toBeTruthy();
  });
});
