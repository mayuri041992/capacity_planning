import { Component, OnInit, Input } from '@angular/core';
import { ngxCsv } from 'ngx-csv/ngx-csv';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
import { element } from 'protractor';
import { ExportData } from '../../shared/models/exportObject.model';
import { pageObject } from '../../shared/models/pageObject.model';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { style } from '@angular/animations';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap, timeout, take } from 'rxjs/operators';
import { MessageService } from 'primeng/components/common/api';
import * as XLSX from 'ts-xlsx';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from '../../core/services/app-service/app.service';
declare let jsPDF;


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'capacity-demand-prediction',
  templateUrl: './capacity-demand-prediction-report.html',
  styleUrls: ['./capacity-demand-prediction-report.scss'],
  providers: [NgbDropdownConfig]
})

export class CapacityDemandPredictionComponent implements OnInit {
  public searchInput;
  public FrozenCount;
  public rows: Array<any> = [];
  public infoData;
  public allColumns: any = [];
  width;
  heightnumber;
  public innerWidth;
  public heightinner = (window.innerHeight - 220) + 'px';
  public ViewAndServerDataMapper =
    {
      deviceModel: { name: 'Device Model', value: null },
      deviceUsages: { name: 'Device Usage', value: null },
      deviceType: { name: 'Device Type', value: null },
      deviceVersion: { name: 'Device Version', value: null },
      productType: { name: 'Product Type', value: null },
      portSpeed: { name: 'Port Speed', value: null },
      chassisSpeed: { name: 'Chassis Speed', value: null },
      cardModel: { name: 'Card Model', value: null },
      cardType: { name: 'Card Type', value: null },
      cardVersion: { name: 'Card Version', value: null },
      marketType: { name: 'Market Type', value: null },
      nodeType: { name: 'Node Type', value: null }
    };
  public exportData = new ExportData();
  public siteExCode = '';
  public columns: any = [];
  public loading = false;
  public objectKeys = Object.keys;
  public selectedFilter = false;
  public totalRecord = 0;
  public numberPage = 1;
  public pageCount;
  public shownodata = true;
  public totalCount = 0;
  public listRow = [100, 200, 500];
  public regex1 = RegExp('/');
  public pageData = new pageObject();
  closeResult: string;
  public chassisView3D;
  public columnShow: Array<any> = [
    { header: 'Site', field: 'siteName', pfCheck: true, width: '16%' },
    { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '10% ' },
    { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '13%' },
    { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
    { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
    { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
    { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '10%' },
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
    { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
    { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '10%' },
    // { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '10%' },
    // { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    // { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
    //  { header: 'Delta', field: 'delta', pfCheck: true, width: '10%' },
  ];
  public OrgScrollable: Array<any> = [
    { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '7%' },
    { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
    { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
    { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '10%' },
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
    { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
    { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '10%' },
    { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '10%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
     { header: 'Delta', field: 'delta', pfCheck: true, width: '10%' },
  ];

  public scrollable: Array<any> = [
    { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '7%' },
    { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '5%' },
    { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
    { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '6%' },
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
    { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
    { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '10%' },
    // { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '8%' },
    // { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '8%' },
    // { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
    // { header: 'Delta', field: 'delta', pfCheck: true, width: '10%' },
  ];

  public frozenCols: Array<any> = [
    { header: 'Site', field: 'siteName', pfCheck: true, width: '32%' },
    { header: '1141 Code', field: 'exchangeCode', pfCheck: true, width: '12%' },
    { header: 'SAU ID', field: 'sauId', pfCheck: true, width: '12%' },
  ];

  public Broadband: Array<any> = [
    { header: 'Broadband REM', field: 'broadBandRem', pfCheck: true, width: '10%' },
    { header: 'Broadband Colo', field: 'broadBandColo', pfCheck: true, width: '10%' },
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
    { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
    { header: 'Potential BB Ports', field: 'potential10gBBETHPorts', pfCheck: true, width: '10%' },
    { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '10%' },
    { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '10%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
     { header: 'Delta', field: 'delta', pfCheck: true, width: '10%' },
  ];
  public Ethernet: Array<any> = [
    { header: 'Free Ethernet Non-TOD Ports', field: 'ethernetNonTodPorts', pfCheck: true, width: '10%' },
    { header: 'Free Ethernet TOD Ports', field: 'ethernetTodPorts', pfCheck: true, width: '10%' },
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
    { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
    { header: 'Potential BB/Eth Ports', field: 'potential10gBBETHPorts', pfCheck: true, width: '10%' },
    { header: 'Potential Eth Ports', field: 'potential10gETHPorts', pfCheck: true, width: '10%' },
    { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '10%' },
    { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '10%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
     { header: 'Delta', field: 'delta', pfCheck: true, width: '10%' },
  ];
  public Backhaul: Array<any> = [
    { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
    { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
    { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '15%' },
    { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
    { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
  ];

  public headcount = this.scrollable.length;
  public savedFilterPreferences: Array<any> = [];
  public savedPreference;

  constructor(private services: AppService, config: NgbDropdownConfig, private router: Router,
              private modalService: NgbModal, private messageService: MessageService,
              private route: ActivatedRoute) {
    config.autoClose = 'outside';
    this.gridDataService();
    this.services.showdata.subscribe((show) => {
      if (show) {
        this.searchInput = '';
        this.pageData.exchangeCode = this.searchInput;
        this.pageData.siteName = this.searchInput;
        this.services.initPageObject.next(this.pageData);
      }
    });
  }
  ngOnInit() {
    this.services.initPageObject.next(this.pageData);
    this.getSavedPreferenceData();
    this.innerWidth = window.innerWidth;
    this.width = ((this.innerWidth / 100) * 40) + 'px';
    this.heightnumber = (window.innerHeight - 230) + 'px';
    setTimeout(() => {
      document.querySelector('.ui-table-unfrozen-view').classList.add('scroll-element');
      if (document.getElementsByTagName('th').length > 3) {
        // tslint:disable-next-line:no-string-literal
        document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body')['style'].cssText = 'overflow: hidden';
      }
    }, 100);

  }

  getSavedPreferenceData() {
    this.savedFilterPreferences = ['Filter1', 'Filter2'];
    this.services.addSavePreferenceSubject.subscribe(filter => {
      this.savedFilterPreferences.push(filter);
    });
  }

  selected(item) {
    this.searchInput = item.item;
    this.siteExCode = item.item;
    this.onSearchData();
  }

  search = (text$: Observable<string>) =>
    text$.pipe(
      distinctUntilChanged(),
      debounceTime(300),
      switchMap(term =>
        this.services.search(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    )

  gridDataService() {
    this.services.initFilterObject$.subscribe((data) => {
      this.gridData(data);
    });
    this.services.Rowdata.subscribe((savedPre) => {
      this.saveData(savedPre);
    }, () => {
      this.loading = false;
    });
    this.services.gridData$.subscribe((res) => {
      this.dataResponse(res);
    }, () => {
      this.loading = false;
    });
    this.services.loading.subscribe((load) => {
      this.loading = load;
    });
    this.services.selectedFilter.subscribe((select) => {
      this.numberPage = 1;
      this.selectedFilter = select;
    });
  }
  gridData(data) {
    const filterKey = Object.keys(this.ViewAndServerDataMapper);
    // tslint:disable-next-line:prefer-for-of
    for (let a = 0; a < filterKey.length; a++) {
      const objToDisplay = this.ViewAndServerDataMapper[filterKey[a]];
      objToDisplay.value = null;
    }
    const filterKeys = Object.keys(data.exchangeInfoFilterRequest);
    // tslint:disable-next-line:prefer-for-of
    for (let a = 0; a < filterKeys.length; a++) {

      const objToDisplay = this.ViewAndServerDataMapper[filterKeys[a]];
      const dataSource = data.exchangeInfoFilterRequest[filterKeys[a]];
      if (objToDisplay && dataSource && typeof dataSource === 'string') {
        objToDisplay.value = dataSource;
      } else if (objToDisplay && dataSource && typeof dataSource === 'object' && dataSource.length > 0) {
        objToDisplay.value = dataSource.join(',');
      }
    }
    if (data.exchangeInfoFilterRequest.productType === 'Broadband') {
      this.columnShow.splice(7, this.columnShow.length);
      this.columnShow = [...this.columnShow];
      this.columnShow.splice(7, 0, ...this.Broadband);
      this.columnShow = [...this.columnShow];
      this.SwipeScrollColumn();
      this.scrollable = [
        { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '4%' },
        { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '4%' },
        { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '5%' },
        { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '5%' },
        { header: 'Broadband REM', field: 'broadBandRem', pfCheck: true, width: '5%' },
        { header: 'Broadband Colo', field: 'broadBandColo', pfCheck: true, width: '5%' },
        { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '5%' },
        { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '5%' },
        { header: 'Potential BB Ports', field: 'potential10gBBETHPorts', pfCheck: true, width: '5%' },
        { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '6%' },
        { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '6%' },
        { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '5%' },
        { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '7%' },
        { header: 'Delta', field: 'delta', pfCheck: true, width: '4%' },
      ];
      this.showHideScrollColumn();
      this.OrgScrollable = JSON.parse(JSON.stringify(this.scrollable));

    } else if (data.exchangeInfoFilterRequest.productType === 'Ethernet') {
      this.columnShow.splice(7, this.columnShow.length);
      this.columnShow = [...this.columnShow];
      this.columnShow.splice(7, 0, ...this.Ethernet);
      this.columnShow = [...this.columnShow];
      this.SwipeScrollColumn();
      this.scrollable = [
        { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '4%' },
        { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '4%' },
        { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '6%' },
        { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '4%' },
        { header: 'Free Ethernet Non-TOD Ports', field: 'ethernetNonTodPorts', pfCheck: true, width: '7%' },
        { header: 'Free Ethernet TOD Ports', field: 'ethernetTodPorts', pfCheck: true, width: '7%' },
        { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '4%' },
        { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '6%' },
        { header: 'Potential BB/Eth Ports', field: 'potential10gBBETHPorts', pfCheck: true, width: '7%' },
        { header: 'Potential Eth Ports', field: 'potential10gETHPorts', pfCheck: true, width: '7%' },
        { header: 'Product Line Forecast', field: 'forCastPorts', pfCheck: true, width: '7%' },
        { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '7%' },
        { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '7%' },
        { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '7%' },
        { header: 'Delta', field: 'delta', pfCheck: true, width: '4%' },
      ];
      this.showHideScrollColumn();
      this.OrgScrollable = JSON.parse(JSON.stringify(this.scrollable));
    } else if ((data.exchangeInfoFilterRequest.productType === 'Backhaul') ||
      (data.exchangeInfoFilterRequest.productType === 'P2PE') ||
      (data.exchangeInfoFilterRequest.productType === 'PRTC') ||
      (data.exchangeInfoFilterRequest.productType === 'DCN') ||
      (data.exchangeInfoFilterRequest.productType === 'Infrastructure') ||
      (data.exchangeInfoFilterRequest.productType === 'Blocked') ||
      (data.exchangeInfoFilterRequest.productType === 'Voice')) {
      // console.log(data.exchangeInfoFilterRequest.productType);
      this.columnShow.splice(7, this.columnShow.length);
      this.columnShow.splice(7, 0, ...this.Backhaul);
      this.columnShow = [...this.columnShow];
      this.SwipeScrollColumn();
      this.scrollable = [
        { header: 'Total Ports', field: 'totalPorts', pfCheck: true, width: '10%' },
        { header: 'Used Ports', field: 'usedPorts', pfCheck: true, width: '10%' },
        { header: 'Reserved Ports', field: 'reserved', pfCheck: true, width: '10%' },
        { header: 'Free Ports', field: 'freePorts', pfCheck: true, width: '10%' },
        { header: 'Free Slots', field: 'freeSlots', pfCheck: true, width: '10%' },
        { header: 'New Ports Inflight', field: 'inFlightPorts', pfCheck: true, width: '10%' },
        { header: 'Port Planned so far', field: 'plannedPorts', pfCheck: true, width: '10%' },
        { header: 'Port Build so far', field: 'buildPorts', pfCheck: true, width: '10%' },
        { header: 'Consumed Port', field: 'consumedPorts', pfCheck: true, width: '10%' },
      ];
      this.showHideScrollColumn();
      this.OrgScrollable = JSON.parse(JSON.stringify(this.scrollable));
    }

    setTimeout(() => {
      this.headcount = document.getElementsByTagName('th').length;
    }, 100);
  }
  saveData(savedPre) {
    // tslint:disable-next-line:no-string-literal
    if (savedPre['exchangeInfoResponse']) {
      // tslint:disable-next-line:no-string-literal
      const respone = savedPre['exchangeInfoResponse'];
      // tslint:disable-next-line:no-string-literal
      this.rows = respone['exchangeInfo'];
      if (this.rows) {
        // tslint:disable-next-line:no-string-literal
        document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-header-box')['style'].cssText = 'overflow: hidden';
        setTimeout(() => {
          // tslint:disable-next-line:no-string-literal
          document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body')['style'].cssText = 'overflow: auto';
          // tslint:disable-next-line:no-string-literal
          document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body')['style'].cssText = 'max-height:' + this.heightinner;
        }, 100);

        // setTimeout(function()
        // { document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body')['style'].cssText = 'overflow: auto';}, 3000);

        this.totalCount = this.totalCount !== 0 ? this.totalCount : 100;
      } else {
        // tslint:disable-next-line:no-string-literal
        document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-header-box')['style'].cssText = 'overflow-x: scroll';
        // tslint:disable-next-line:no-string-literal
        document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body')['style'].cssText = 'overflow: hidden';
      }
      // tslint:disable-next-line:no-string-literal
      this.totalRecord = respone['totalRecords'];
      this.pageCount = this.totalRecord >= +this.totalCount ? ((+this.totalCount + this.numberPage) - 1) : this.totalRecord;
      this.pageCount = this.pageCount >= (this.totalRecord) ? this.totalRecord : this.pageCount;
      this.loading = false;
    } else {
      this.totalRecord = 0;
    }
  }
  dataResponse(res) {
    if (this.siteExCode) {
      // tslint:disable-next-line:no-string-literal
      const rowValue = res['exchangeInfo'];
      this.rows = rowValue.filter((row) => {
        if (row.siteName === this.siteExCode || row.exchangeCode === this.siteExCode) {
          return row;
        }
      });
      this.totalRecord = this.rows.length;
      this.siteExCode = '';
    } else {
      // tslint:disable-next-line:no-string-literal
      this.rows = res['exchangeInfo'];
      // tslint:disable-next-line:no-string-literal
      this.totalRecord = res['totalRecords'];
    }

    // tslint:disable-next-line:no-string-literal
    //  this.rows = res['exchangeInfo'];

    if (this.rows.length !== 0) {
      this.selectedFilter = true;
      const scrollAjust = document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body');
      scrollAjust.scrollLeft = - 100;
      // tslint:disable-next-line:no-string-literal
      document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-header-box')['style'].cssText = 'overflow: hidden';

      setTimeout(() => {
        // tslint:disable-next-line:no-string-literal
        const abc = document.querySelector('.ui-table-scrollable-body-table')['offsetHeight'];
        if (window.innerHeight - 220 > abc) {
          this.heightinner = (abc + 20) + 'px';
        } else {
          this.heightinner = (window.innerHeight - 220) + 'px';
        }
        // tslint:disable-next-line:no-string-literal
        document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body')['style'].cssText = 'overflow: auto';
        // tslint:disable-next-line:no-string-literal
        document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-body')['style'].cssText = 'height:' + this.heightinner;
      }, 100);

      this.totalCount = this.totalCount !== 0 ? this.totalCount : 100;
    } else {
      // tslint:disable-next-line:no-string-literal
      document.querySelector('.ui-table-unfrozen-view .ui-table-scrollable-header-box')['style'].cssText = 'overflow-x: scroll';
    }
    this.pageCount = this.totalRecord >= +this.totalCount ? ((+this.totalCount + this.numberPage) - 1) : this.totalRecord;

    this.pageCount = this.pageCount >= (this.totalRecord) ? this.totalRecord : this.pageCount;
    this.loading = false;
  }
  customSort(event: any) {
    if (event.order === 1) {
      if (this.pageData.sortOrder !== true || this.pageData.sortByField !== event.field) {
        this.pageData.sortOrder = true;
        this.pageData.sortByField = event.field;
        this.services.callExchangeInfo.next(true);
        this.services.initPageObject.next(this.pageData);
      }
    } else if ((event.order === -1)) {
      if (this.pageData.sortOrder !== false || this.pageData.sortByField !== event.field) {
        this.pageData.sortOrder = false;
        this.pageData.sortByField = event.field;
        this.services.callExchangeInfo.next(true);
        this.services.initPageObject.next(this.pageData);
      }
    }
  }

  public selectChange() {
    if (this.pageData.pageSize !== this.totalCount) {
      this.pageData.pageSize = this.totalCount;
      this.pageData.pageNo = 0;
      this.numberPage = 1;
      this.services.callExchangeInfo.next(true);
      this.services.initPageObject.next(this.pageData);
    }
  }
  showHideScrollColumn() {
    this.columnShow.forEach((col) => {
      this.scrollable.forEach((scrol) => {
        if (col.field === scrol.field) {
          scrol.pfCheck = col.pfCheck;
        }
      });
    });
    this.scrollable = [... this.scrollable];
  }
  SwipeScrollColumn() {
    this.scrollable.forEach((col) => {
      this.columnShow.forEach((scrol) => {
        if (col.field === scrol.field) {
          scrol.pfCheck = col.pfCheck;
        }
      });
    });
    this.columnShow = [... this.columnShow];
  }
  paginate(event) {
    if (this.pageData.pageNo !== event.page) {
      this.pageData.pageNo = event.page;
      this.numberPage = (this.totalCount * event.page) + 1;
      this.pageCount = this.totalRecord >= +this.totalCount ? ((+this.totalCount + this.numberPage) - 1) : this.totalRecord;
      this.pageCount = this.pageCount >= (this.totalRecord) ? this.totalRecord : this.pageCount;
      this.services.callExchangeInfo.next(true);
      this.services.initPageObject.next(this.pageData);
    }
  }

  public onSearchData() {
    this.pageData.pageNo = 0;
    this.numberPage = 1;
    const filterData = this.searchInput;
    if (this.pageData.exchangeCode !== filterData && this.pageData.siteName !== filterData) {
      this.pageData.exchangeCode = filterData;
      this.pageData.siteName = filterData;
      this.services.callExchangeInfo.next(true);
      this.services.initPageObject.next(this.pageData);
    }
    if (filterData === '') {
      this.pageData.exchangeCode = filterData;
      this.pageData.siteName = filterData;
      this.services.callExchangeInfo.next(true);
      this.services.initPageObject.next(this.pageData);
    }
  }

  public onClear(event: any) {
    // tslint:disable-next-line:no-angle-bracket-type-assertion
    const filterData = (<HTMLInputElement> event.target).value;
    if (filterData === '') {
      this.pageData.exchangeCode = filterData;
      this.pageData.siteName = filterData;
      this.services.callExchangeInfo.next(true);
      this.services.initPageObject.next(this.pageData);
    }
  }
  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  toggle(col) {
    this.headcount = document.getElementsByTagName('th').length;
    this.FrozenCount = document.querySelector('.ui-table-unfrozen-view').querySelectorAll('th').length;
    if (this.FrozenCount < 9) {
      document.querySelector('.ui-table-unfrozen-view').classList.remove('scroll-element');
    } else {
      document.querySelector('.ui-table-unfrozen-view').classList.add('scroll-element');
    }
    const expt = Object.keys(this.exportData);
    const expt1 = Object(this.exportData);
    // tslint:disable-next-line:prefer-for-of
    for (let a = 0; a < expt.length; a++) {
      if (expt[a] === col.field) {
        this.exportData[expt[a]] = col.pfCheck;
      }
    }
    if (col.field === 'sauId') {
      if (!col.pfCheck) {
        this.frozenCols.splice(this.frozenCols.findIndex(x => x.field === col.field), 1);
      } else if (col.pfCheck) {
        this.frozenCols.splice((this.frozenCols.length), 0, col);

      }
    } else {
      this.showHideScrollColumn();
    }
  }

  isChecked(col) {
    return this.columns.find(c => {
      return c.header === col.header;
    });
  }

  convert(param) {
    this.services.getGridDataToExport().pipe(take(1)).subscribe((dataToExport) => {
      const dataToShow = dataToExport.exchangeInfo as object[];
      const columnsExport = this.columnShow.filter((headerObj) => {
        if (headerObj.pfCheck) {
          return headerObj.header;
        }
      });
      const colsToFile = columnsExport.map((headerObj) => {
        if (headerObj.pfCheck) {
          return headerObj.header;
        }
      });
      const rowsToFile = dataToShow.map((exObj) => {
        const obj = {};
        columnsExport.map((colInfo) => {
          if (colInfo.pfCheck) {
            Object.prototype.hasOwnProperty.bind(exObj)
              (colInfo.field) ? obj[colInfo.field] = exObj[colInfo.field] : obj[colInfo.field] = '';
            return obj;
          }
        });
        return obj;
      });
      let header = 'Selected Filter - ';
      for (const key in this.ViewAndServerDataMapper) {
        if (Object.prototype.hasOwnProperty.bind(this.ViewAndServerDataMapper)(key)) {
          const dataSource = this.ViewAndServerDataMapper[key];
          if (dataSource && typeof dataSource.value === 'string') {
            header += dataSource.name + ': (' + dataSource.value.split(',').join('`') + ') ;';
          } else if (dataSource && dataSource.value && typeof dataSource.value === 'object' && dataSource.value.length > 0) {
            header += dataSource.name + ': (' + dataSource.value.join('~') + ') ;';
          }
        }
      }
      if (param === 'csv') {
        const options = {
          showLabels: true,
          showTitle: true,
          title: 'Capacity Demand Prediction Report \n' + header.substring(0, header.length - 1),
          headers: colsToFile
        };
        param = null;
        // tslint:disable-next-line:no-unused-expression
        new ngxCsv(rowsToFile, 'CapacityDemandPredictionReport', options);
      } else if (param === 'pdf') {
        let addTop = 5;
        const doc = new jsPDF('p', 'mm', 'a2');
        doc.text(15, 15, 'Capacity Demand Prediction Report');
        let headers = '';
        for (const key in this.ViewAndServerDataMapper) {
          if (Object.prototype.hasOwnProperty.bind(this.ViewAndServerDataMapper)(key)) {
            const dataSource = this.ViewAndServerDataMapper[key];
            if (dataSource && typeof dataSource.value === 'string') {
              headers += dataSource.name + ': (' + dataSource.value + ') ,';
            } else if (dataSource && typeof dataSource === 'object' && dataSource.length > 0) {
              headers += dataSource.name + ': (' + dataSource.value.join(',') + ') ,';
            }
          }
        }
        header = header.substring(0, header.lastIndexOf(';'));
        // console.log(header);
        if (header.length > 150) {
          let headerLength = header.length - 1;
          // const v = headers.lastIndexOf(';');
          // console.log(v);
          let count = 0;
          doc.text(15, 25, header.substring(0, 150));
          while (headerLength > 150) {
            ++count;
            headerLength = headerLength - 150;
            addTop = addTop + 5;
            doc.text(15, 25 + addTop, header.substring(((150 * count)), ((150 * count) + 150)));
            // console.log(headerLength);
          }

        } else {
          doc.text(15, 25, header.substring(0, header.length - 1));
        }
        const rowdata = [];
        rowsToFile.forEach((exObj) => {
          const obj = [];
          columnsExport.map((colInfo) => {
            if (colInfo.pfCheck) {
              Object.prototype.hasOwnProperty.bind(exObj)(colInfo.field) ? obj.push(exObj[colInfo.field]) : obj.push('');
              return obj;
            }
          });
          rowdata.push(obj);
        });
        const img = new Image();
        img.src = 'assets/images/BT_purple_logo.png';
        img.onload = () => {
          doc.addImage(img, 'PNG', 380, 10, 20, 10);
          doc.autoTable(colsToFile, rowdata, {
            rowHeight: 4, fontSize: 8, overflow: 'linebreak', margin: { top: (30 + (addTop + 5)), left: 15, right: 15, bottom: 10 },
          });
          doc.save('CapacityDemandPredictionReport.pdf');
          param = null;
        };
      }
    }, () => { }, () => { });
  }

  onClickNavigate(columnField, columnData, linkedField) {
    if (linkedField === 'siteName') {
      this.router.navigate(['/siteDetails'], { relativeTo: this.route, queryParams: { site_Name: columnField } });
    } else {
      this.services.initFilterObject$.pipe(take(1)).subscribe((filterObj) => {
        const Json3D = filterObj.exchangeInfoFilterRequest;
        // tslint:disable-next-line:max-line-length
        this.chassisView3D = { ...Json3D, siteName: columnData.siteName, exchangeCode: columnData.exchangeCode, portStatus: linkedField.toUpperCase()};
        delete(this.chassisView3D.ein);
        // delete(this.chassisView3D.nodeType);
      });
      this.services.view3D.next(this.chassisView3D);
      this.router.navigate(['/chassisView']);
    }
  }

}

