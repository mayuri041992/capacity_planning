import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';

import { ChassisViewService } from 'src/app/core/services/chassis-view-service/chassis-view.service';
import devicevisualizer from 'device-visualizer';
import { AppService } from 'src/app/core/services/app-service/app.service';
import { debounceTime, switchMap, catchError, filter, map, tap } from 'rxjs/operators';
import { of, Observable, Subject, merge, Subscription } from 'rxjs';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-chassis-view',
  templateUrl: './chassis-view.component.html',
  styleUrls: ['./chassis-view.component.scss']
})
export class ChassisViewComponent implements OnInit, OnDestroy {

  rightPanelstatus: any[] = [];
  rightPanelproducts: any[] = [];
  rightPanelChassisInfo: any[] = [];
  leftPanelInfoDetails: any = {};
  rightPanelChassisInfoSiteName: string;
  leftPanelInfoTitle: any;
  statusArray: any = [];
  chassis: any;
  prevChassViewData: any;
  selectedSneID: any;
  rightPanelStatusList: any[] = [];
  rightPanelProductList: any[] = [];
  deviceData: any;
  sneID: any[] = [];
  currentIndex = 0;
  snesearch: any;
  prevSne: any;
  nextSne: any;
  urlCallSNE = false;
  isUpDisabled = false;
  isDownDisabled = false;
  loading = false;
  showHtml = false;
  searchInput;
  checkColor: any[];
  click$ = new Subject<string>();
  view3DUnsubcrib: Subscription;
  chassViewData;
  @ViewChild('instance') instance: NgbTypeahead;
  constructor(private chassisViewService: ChassisViewService, private services: AppService) {

    // this.services.view3D$.subscribe((chassViewData) => {
    //   this.urlCallSNE = false;
    //   this.services.getChassView(chassViewData).subscribe((sneID) => {
    //     if (sneID.length) {
    //       this.services.get3DPortData(chassViewData, sneID[0]).subscribe((json) => {
    //         console.log(json);
    //       });
    //     }
        //   this.snesearch.updateSearchList(sneID);
        // this.get3DData();
        // const saveElems: HTMLElement = document.querySelector('.autocomplete');
        // saveElems.click();
        // -
        // });

        // this.services.siteView3D$.subscribe((siteViewData) => {
        //   this.urlCallSNE = false;
        //   const siteSNE = siteViewData.searchType;
        //   delete (siteViewData.searchType);
        //   this.services.getSiteChassView3D(siteViewData, siteSNE).subscribe((sneID) => {
        //     const bodyViewData = { ...siteViewData, siteName: siteSNE, exchangeCode: '' };
        //     if (sneID.length) {
        //       this.services.getDetailed3DPortData(bodyViewData, sneID[0]).subscribe(console.log);
        //     }
        //     //  this.snesearch.updateSearchList(sneID);
        //     // this.get3DData();
        //   });
        // });
      }

  getModelData(data) {
    this.showHtml = true;
    this.deviceData = data;
    this.deviceData.modelData.verticalPixelAdjust = 100;
    console.log(this.deviceData.modelData);
    this.getLeftPanelInfo(this.deviceData);
    this.getRightPanelInfo(this.deviceData);
    this.chassis = new devicevisualizer(this.deviceData, '../assets/models/');
    this.chassis.init('#srims_renderer').then(() => {
      this.disableLoader();
    });

    this.chassis.listenToObjectClick((leftData) => {
      this.leftPanelInfoTitle = leftData.header;
      this.leftPanelInfoDetails = leftData.leftInfoPanelData;
    });
  }


  getLeftPanelInfo(data) {
          this.showHtml = true;
          this.leftPanelInfoDetails = {};
          this.leftPanelInfoTitle = data.modelData.defaultInfo.title;
          this.leftPanelInfoDetails = data.modelData.defaultInfo.info;
        }

  getRightPanelInfo(data) {
          this.showHtml = true;
          this.rightPanelstatus = data.modelData.statusList.map((value) => {
            return value.displayName;
          });
          this.rightPanelStatusList = data.modelData.statusList;
          this.checkColor = data.modelData.statusList;
          //   console.log(this.checkColor);
          this.rightPanelproducts = data.modelData.productList.map((value) => {
            return value.displayName;
          });
          this.rightPanelProductList = data.modelData.productList;
          this.rightPanelChassisInfo = [];
          this.rightPanelChassisInfoSiteName = data.modelData.deviceInfo.siteName;
          this.rightPanelChassisInfo = data.modelData.deviceInfo.deviceDetails;
        }

  /* autoSuggestionSNE(sneID, focus) {
    const placeHolder = 'Search SNE ID';
    const container = '#searchSNE';
    const searchID = 'searchInput';
    const searchName = 'search_sne';
    const searchData = sneID;
    const active = focus;

    this.snesearch = new AutoSuggest({
      container, searchData, searchID, searchName, placeHolder, active
    });
    console.log(sneID);
    this.snesearch.listenToSelectEvent((selectedSneID) => {
      console.log('calling the SNE');
      this.selectedSneID = selectedSneID;
      this.getModelData(this.selectedSneID);
      this.currentIndex = sneID.indexOf(this.selectedSneID);
      this.showTooltip();
      if (this.currentIndex <= 0) {
        this.isUpDisabled = true;
        this.isDownDisabled = false;
      }
      if (this.currentIndex > 0 && this.currentIndex <= sneID.length - 1) {
        this.isUpDisabled = false;
        this.isDownDisabled = false;
      }
      if (this.currentIndex >= sneID.length - 1) {
        this.isDownDisabled = true;
      }
    });



    this.snesearch.listenToemptyListEvent((inputEntered, element) => {
      console.log(inputEntered.length + 'input length');
      if (inputEntered.length === 2) {
        console.log('calling the listenToemptyListEvent');
        // this.chassisViewService.getSneData().subscribe((sneID) => {
        //   this.sneID = sneID;
        //     this.snesearch.updateSearchList(sneID);
        //   //  this.get3DData();
        // });

        this.chassisViewService.getSneList(inputEntered).subscribe((sneID) => {
          this.snesearch.updateSearchList(sneID, element);
        });
      }
    });
  } */

  returnZero() {
          return 0;
        }

  changeSneID(value) {
    if (value === 'prev') {
      this.currentIndex--;
      if (this.currentIndex >= 0) {
        const index = this.sneID.indexOf(this.selectedSneID) - 1;
        this.prevSne = this.sneID[index];
      }
    }
    if (value === 'next') {
      this.currentIndex++;
      if (this.currentIndex <= this.sneID.length) {
        const index = this.sneID.indexOf(this.selectedSneID) + 1;
        this.nextSne = this.sneID[index];
      }
    }
    if (this.currentIndex <= 0) {
      this.isUpDisabled = true;
    }
    if (this.currentIndex > 0 && this.currentIndex <= this.sneID.length - 1) {
      this.isUpDisabled = false;
      this.isDownDisabled = false;
    }
    if (this.currentIndex >= this.sneID.length - 1) {
      this.isDownDisabled = true;
    }
  }

  checkAll(event: any) {
        return new Promise((resolve, reject) => {
          let productElements = (<HTMLInputElement[]><any>document.getElementsByName('product'));
          if (event.target.name === 'all') {
            for (let i = 0; i < productElements.length; i++) {
              if (event.target.checked) {
                productElements[i].checked = true;
              } else {
                productElements[i].checked = false;
              }
              if (productElements.length - 1 === i) {
                resolve();
              }
            }
          }
        });
      }
  search = (text$: Observable<string>) => {
        this.urlCallSNE = false;
        let valueJSOn1;
        const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
        this.view3DUnsubcrib = this.services.view3D$.subscribe((chassViewData) => {
          this.urlCallSNE = true;
          this.services.getChassView(chassViewData).subscribe((valueJSOn) => {
            valueJSOn1 = valueJSOn;
            this.searchInput = valueJSOn1[0];
            this.services.get3DCapacityData( chassViewData, valueJSOn1[0]).subscribe((JSON3d) => {
              this.getModelData(JSON3d);
            });
           // this.getModelData(valueJSOn1[0]);
          });
        });

        this.services.siteView3D$.subscribe((siteViewData) => {
          this.urlCallSNE = true;
          const siteSNE = siteViewData.searchType;
          delete (siteViewData.searchType);
          if ( siteSNE) {
            this.services.getSiteChassView3D(siteViewData, siteSNE).subscribe((sneID) => {
            valueJSOn1 = sneID;
            this.searchInput = valueJSOn1[0];
            this.getModelData(valueJSOn1[0]);
            });
            }
          // this.services.getSiteChassView3D(siteViewData, siteSNE).subscribe((sneID) => {
          //   valueJSOn1 = sneID;
          //   this.searchInput = valueJSOn1[0];
          //   this.getModelData(valueJSOn1[0]);
          //  // this.getModelData(valueJSOn1[0]);
          // });
        });
        if (this.urlCallSNE) {
          return merge(clicksWithClosedPopup$).pipe(map(() => valueJSOn1));
        } else {
          const valueSearch$ = text$.pipe(debounceTime(1000));
          return merge(clicksWithClosedPopup$, valueSearch$).pipe(
            switchMap(term => this.chassisViewService.getSneList(term).pipe(
              catchError(() => {
                return of([]);
              })
            )));
        }

      }
  // // this.services.view3D$.subscribe((chassViewData) => {
  // //   this.services.getChassView(this.chassViewData).subscribe((valueJSOn) => {
  // //      valueJSOn1 = valueJSOn;
  // //   });
  // return merge(clicksWithClosedPopup$).pipe(
  //   map(term =>  ['53125316523', '1231236263'] ));
  // text$.pipe(
  //   debounceTime(300),
  //   switchMap(term =>
  //     this.chassisViewService.getSneList(term).pipe(
  //       catchError(() => {
  //         return of([]);
  //       }))
  //   )
  // )


  // searchSNE = (text$: Observable<string>) =>
  //   text$.pipe(
  //   switchMap(() =>
  //     this.services.getChassView(this.chassViewData).pipe(
  //       catchError(() => {
  //         return of([]);
  //       }))
  //   )
  // )
  selected(item) {
        this.enableLoader();
        this.services.getDefault3DportData(item.item).subscribe((DefaultJSON ) => {
          this.getModelData(DefaultJSON);
        });
      }

  checkAllProducts(event: any) {
        this.checkAll(event).then(() => {
          this.selectedFilters();
        });
      }

  selectedFilters() {
        this.selectedProducts().then((productNames) => {
          this.selectedStatus().then((statusNames) => {
            this.chassis.filter_status(productNames, statusNames);
          });
        });
      }

  selectedProducts() {
        return new Promise((resolve, reject) => {
          let productElements = (<HTMLInputElement[]><any>document.getElementsByName('product'));
          let productsArray: any = [];
          for (let i = 0; i < productElements.length; i++) {
            if (productElements[i].type === 'checkbox') {
              if (productElements[i].checked) {
                productsArray.push(productElements[i].value);
              }
            }
            if (productElements.length - 1 === i) {
              resolve(productsArray);
            }
          }
        });


      }

  selectedStatus() {
        return new Promise((resolve, reject) => {
          let statusElements = (<HTMLInputElement[]><any>document.getElementsByName('status'));
          let statusArray: any = [];
          for (let i = 0; i < statusElements.length; i++) {
            if (statusElements[i].type === 'checkbox') {
              if (statusElements[i].checked) {
                statusArray.push(statusElements[i].value);
              }
            }
            if (statusElements.length - 1 === i) {
              resolve(statusArray);
            }
          }
        });
      }

  enableLoader() {
        this.loading = true;
      }

  disableLoader() {
        setTimeout(() => {
        this.loading = false;
      }, 5000);
  }

  showTooltip() {
    if (this.currentIndex >= 0) {
      const index = this.sneID.indexOf(this.selectedSneID) - 1;
      this.prevSne = this.sneID[index];
    }
    if (this.currentIndex <= this.sneID.length) {
      const index = this.sneID.indexOf(this.selectedSneID) + 1;
      this.nextSne = this.sneID[index];
    }
  }
  ngOnInit() {
    //   this.getModelData(this.selectedSneID);

    //  this.autoSuggestionSNE(this.sneID, false);

    this.returnZero();
    this.showTooltip();

    if (this.sneID.length <= 0 && this.sneID.length !== undefined) {
      this.isDownDisabled = true;
      this.isUpDisabled = true;
    }

    if (this.currentIndex <= 0) {
      this.isUpDisabled = true;
    }
    if (this.currentIndex >= this.sneID.length) {
      this.isDownDisabled = true;
    }
  }
  ngOnDestroy() {
    this.services.view3D.next(null);
    this.services.siteView3D.next(null);
    this.view3DUnsubcrib.unsubscribe();
  }
}
