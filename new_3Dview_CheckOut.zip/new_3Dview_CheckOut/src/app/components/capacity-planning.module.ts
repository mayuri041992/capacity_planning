import { NgModule } from '@angular/core';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxLoadingModule } from 'ngx-loading';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { CapacityDemandPredictionComponent } from './capacity-demand-prediction-report/capacity-demand-prediction-report';
import { FilterComponent } from './filter/filter.component';
import { SharedModule } from '../shared/shared.module';
import { CapacityDashboardComponent } from './capacity-dashboard/capacity-dashboard';
import { AppService } from '../core/services/app-service/app.service';
import { ToastModule } from 'primeng/toast';


// importing Angular Material Module
// import { MatMaterialModule } from './mat-material.module';

const components = [
  FilterComponent,
  CapacityDemandPredictionComponent,
  CapacityDashboardComponent,
];

const routes: Routes = [
  { path: '', component: CapacityDashboardComponent }
];

@NgModule({
  declarations: components,
  imports: [
    CommonModule,
    SharedModule,
    NgbModule,
    HttpClientModule,
    ToastModule,
    NgxLoadingModule.forRoot({}),
    FormsModule,
    PaginatorModule,
    TableModule,
    RouterModule.forChild(routes),
    // MatMaterialModule
  ],
  providers: [
    NgbActiveModal
  ]
})
export class CapacityPlanningModule {
}
