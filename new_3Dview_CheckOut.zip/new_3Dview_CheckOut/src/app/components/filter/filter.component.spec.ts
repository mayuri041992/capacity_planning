import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { FilterComponent } from './filter.component';
import { BehaviorSubject, of } from 'rxjs';
import { switchMap, filter, map } from 'rxjs/operators';
import { SvgComponent } from '../../shared/components/svg/svg.component';
import { AppService } from '../../core/services/app-service/app.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { Component, Renderer, ElementRef, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LoginService } from '../../core/services/login-service/login.service';
import { filterObject } from '../../shared/models/filterObject.model';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalRef, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { element } from 'protractor';
import { By } from '@angular/platform-browser';
import { eventNames } from 'cluster';




describe('FilterComponent', () => {
  let component: FilterComponent;
  let fixture: ComponentFixture<FilterComponent>;
  let service: AppService;
  let httpMock: HttpTestingController;
  let testBedService: AppService;
  let catSearchCom;
  // tslint:disable-next-line:prefer-const
  let displayColumnsBtn;
  // tslint:disable-next-line:prefer-const
  let deviceType;
  // tslint:disable-next-line:prefer-const
  let portSpeed;
  // tslint:disable-next-line:prefer-const
  let productType;
  const ButtonText = 'Collapse';
  const ButtonTextChang = 'Expand All';
  const savePre = {
    ein: null,
    filterId: []
  };


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ToastModule, FormsModule, NgbModule],
      declarations: [FilterComponent, SvgComponent],
      providers: [AppService, MessageService, LoginService, NgbModal],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    }).overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [] } })
      .compileComponents();
    service = TestBed.get(AppService);
    httpMock = TestBed.get(HttpTestingController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterComponent);
    component = fixture.componentInstance;
    catSearchCom = fixture.debugElement.componentInstance;
    testBedService = TestBed.get(AppService);


    component._success.next('some data');
    spyOn(component, '_success').and.returnValue(of('some data'));
    // component.uploadData.subscribe( data =>  expect(data).toEqual({fileType: 'cst', data: [] }));
    // expect(component.options.animation.onComplete).toHaveBeenCalled();
    component._danger.next('some data');
    spyOn(component, '_danger').and.returnValue(of('some data'));
    fixture.detectChanges();
  });


  it('should check function filtertoggle', () => {
    // tslint:disable-next-line:prefer-const
    let param;
    const active = {
      device_Model: true,
      Device_Usages: true,
      Device_Type: true,
      Device_Version: true,
      Product_Type: true,
      Port_Speed: true,
      card_Model: true,
      card_Type: true,
      card_Version: true,
      market_Type: true,
      chassisSpeed: true,
      node_Type: true
    };
    // const ele = window.document.getElementById('modId');
    // if(ele) {

    // }
    // ele.style.removeProperty('height');
    component.filtertoggle(param);
    expect(component.active).toBeDefined();
  });


  it('should check function toggle', () => {
    const event = {
      target: {
        value: 'chassisSpeed',
        id: 8,
        checked: true,
      }
    };
    component.productType = [
      { title: 'chassisSpeed', value: false, id: 10 },
      { title: 'Broadband', value: true, id: 8 },
      { title: 'Ethernet', value: false, id: 9 }];
    component.toggle(event, 'nodeType');
    component.toggle(event, 'chassisSpeed');
    component.toggle(event, 'marketType');
    component.toggle(event, 'deviceModel');
    component.toggle(event, 'deviceUsages');
    component.toggle(event, 'deviceType');
    component.toggle(event, 'productType');
    component.toggle(event, 'portSpeed');
    component.toggle(event, 'deviceVersion');
    component.toggle(event, 'cardModel');
    component.toggle(event, 'cardType');
    expect(component.toggle).toBeDefined();
    expect(component.productType.length).toEqual(3);
  });
  it('should check function toggle else', () => {
    const event = {
      target: {
        value: true,
        id: 8,
        checked: false,
      }
    };
    component.productType = [
      { title: 'Backhaul', value: false, id: 10 },
      { title: 'Broadband', value: true, id: 8 },
      { title: 'Ethernet', value: false, id: 9 }];
    component.toggle(event, 'nodeType');
    component.toggle(event, 'chassisSpeed');
    component.toggle(event, 'marketType');
    component.toggle(event, 'deviceModel');
    component.toggle(event, 'deviceUsages');
    component.toggle(event, 'deviceType');
    component.toggle(event, 'productType');
    component.toggle(event, 'portSpeed');
    component.toggle(event, 'deviceVersion');
    component.toggle(event, 'cardModel');
    component.toggle(event, 'cardType');
    expect(component.toggle).toBeDefined();
    expect(component.productType.length).toEqual(3);
  });


  it('should check function bindDataFilter', () => {
    const masterFilter = [
      {
        filterName: 'Node Type',
        filterValue: 'CMSAN',
        id: 69,
        selected: true
      },
      {
        filterName: 'Chassis Speed',
        filterValue: '1 TB',
        id: 16,
        selected: true
      },
      {
        filterName: 'Market Type',
        filterValue: 'Market A',
        id: 18,
        selected: true
      },
      {
        filterName: 'Device Model',
        filterValue: '7750 SR-12',
        id: 1,
        selected: true
      },
      {
        filterName: 'Device Usage',
        filterValue: 'EEA',
        id: 3,
        selected: true
      },
      {
        filterName: 'Device Type',
        filterValue: 'Edge Rt',
        id: 6,
        selected: true
      },
      {
        filterName: 'Product Type',
        filterValue: 'Backhaul',
        id: 10,
        selected: true
      },
      {
        filterName: 'Port Speed',
        filterValue: '100GE',
        id: 14,
        selected: true
      },
      {
        filterName: 'Device Version',
        filterValue: '(N/A)',
        id: 7,
        selected: true
      },
      {
        filterName: 'Card Model',
        filterValue: 'IMM 1 x 100G',
        id: 79,
        selected: true
      },
      {
        filterName: 'Card Type',
        filterValue: '1 x 10GB MDA',
        id: 44,
        selected: true
      },
      {
        filterName: 'Card Type',
        filterValue: '1 x 10GB MDA',
        id: 44,
        selected: true
      },
      {
        filterName: 'Card Version',
        filterValue: '(1Tb)',
        id: 86,
        selected: true
      },
      {
        filterName: 'Card Version',
        filterValue: '(20Pt)',
        id: 60,
        selected: false
      }
    ];
    component.bindDataFilter(masterFilter);
    expect(component.bindDataFilter).toBeDefined();
    expect(component.nodeType.length).toEqual(1);
  });


  it('should check function getSavedPref', () => {
    component.siteFilterData = [
      { id: 79, filterName: 'Card Model', filterValue: 'IMM 1 x 100G', selected: true },
      { id: 44, filterName: 'Card Type', filterValue: '1 x 10GB MDA', selected: true },
      { id: 56, filterName: 'Card Version', filterValue: '(12Pt Lic)', selected: true },
      { id: 16, filterName: 'Chassis Speed', filterValue: '1 TB', selected: true },
      { id: 1, filterName: 'Device Model', filterValue: '7750 SR-12', selected: true },
      { id: 6, filterName: 'Device Type', filterValue: 'Edge Rt', selected: true },
      { id: 3, filterName: 'Device Usage', filterValue: 'EEA', selected: true },
      { id: 7, filterName: 'Device Version', filterValue: '(N/A)', selected: true },
      { id: 18, filterName: 'Market Type', filterValue: 'Market A', selected: true },
      { id: 69, filterName: 'Node Type', filterValue: 'CMSAN', selected: true },
      { id: 14, filterName: 'Port Speed', filterValue: '100GE', selected: true },
      { id: 10, filterName: 'Product Type', filterValue: 'Backhaul', selected: true }
    ];

    // tslint:disable-next-line:no-string-literal
    component.siteFilterData['filterMasterResponse'] = [
      { id: 79, filterName: 'Card Model', filterValue: 'IMM 1 x 100G', selected: true },
      { id: 44, filterName: 'Card Type', filterValue: '1 x 10GB MDA', selected: true },
      { id: 56, filterName: 'Card Version', filterValue: '(12Pt Lic)', selected: true },
      { id: 16, filterName: 'Chassis Speed', filterValue: '1 TB', selected: true },
      { id: 1, filterName: 'Device Model', filterValue: '7750 SR-12', selected: true },
      { id: 6, filterName: 'Device Type', filterValue: 'Edge Rt', selected: true },
      { id: 3, filterName: 'Device Usage', filterValue: 'EEA', selected: true },
      { id: 7, filterName: 'Device Version', filterValue: '(N/A)', selected: true },
      { id: 18, filterName: 'Market Type', filterValue: 'Market A', selected: true },
      { id: 69, filterName: 'Node Type', filterValue: 'CMSAN', selected: true },
      { id: 14, filterName: 'Port Speed', filterValue: '100GE', selected: true },
      { id: 10, filterName: 'Product Type', filterValue: 'Backhaul', selected: true }
    ];

    spyOn(service, 'getSavedpref').and.returnValue(of(component.siteFilterData));
    component.getSavedPref();
    // tslint:disable-next-line:no-unused-expression
    fixture.detectChanges;
    expect(component.getSavedPref).toBeDefined();
    expect(component.siteFilterData).toEqual(component.siteFilterData);
    expect(component.siteFilterData).not.toBeNull();
    expect(component.filterObject).toEqual(component.filterObject);
    expect(component.filterObject).not.toBeNull();
  });

  it('should check function upadtedDataFilter', () => {
    const masterFilter = [
      {
        filterName: 'Node Type',
        filterValue: 'CMSAN',
        id: 69,
        selected: true
      },
      {
        filterName: 'Chassis Speed',
        filterValue: '1 TB',
        id: 16,
        selected: true
      },
      {
        filterName: 'Market Type',
        filterValue: 'Market A',
        id: 18,
        selected: true
      },
      {
        filterName: 'Device Model',
        filterValue: '7750 SR-12',
        id: 1,
        selected: true
      },
      {
        filterName: 'Device Usage',
        filterValue: 'EEA',
        id: 3,
        selected: true
      },
      {
        filterName: 'Device Type',
        filterValue: 'Edge Rt',
        id: 6,
        selected: true
      },
      {
        filterName: 'Product Type',
        filterValue: 'Backhaul',
        id: 10,
        selected: true
      },
      {
        filterName: 'Port Speed',
        filterValue: '100GE',
        id: 14,
        selected: true
      },
      {
        filterName: 'Device Version',
        filterValue: '(N/A)',
        id: 7,
        selected: true
      },
      {
        filterName: 'Card Model',
        filterValue: 'IMM 1 x 100G',
        id: 79,
        selected: true
      },
      {
        filterName: 'Card Type',
        filterValue: '1 x 10GB MDA',
        id: 44,
        selected: true
      },
      {
        filterName: 'Card Type',
        filterValue: '1 x 10GB MDA',
        id: 44,
        selected: true
      },
      {
        filterName: 'Card Version',
        filterValue: '(1Tb)',
        id: 86,
        selected: true
      },
      {
        filterName: 'Card Version',
        filterValue: '(20Pt)',
        id: 60,
        selected: false
      }
    ];
    component.upadtedDataFilter(masterFilter);
    expect(component.upadtedDataFilter).toBeDefined();
    expect(component.nodeType.length).toEqual(1);
  });

  it('should check function UpdatedFilterMasterInfo', () => {
    const masterFilter = [
      { id: 79, filterName: 'Card Model', filterValue: 'IMM 1 x 100G', selected: true },
      { id: 44, filterName: 'Card Type', filterValue: '1 x 10GB MDA', selected: true },
      { id: 56, filterName: 'Card Version', filterValue: '(12Pt Lic)', selected: true },
      { id: 16, filterName: 'Chassis Speed', filterValue: '1 TB', selected: true },
      { id: 1, filterName: 'Device Model', filterValue: '7750 SR-12', selected: true },
      { id: 6, filterName: 'Device Type', filterValue: 'Edge Rt', selected: true },
      { id: 3, filterName: 'Device Usage', filterValue: 'EEA', selected: true },
      { id: 7, filterName: 'Device Version', filterValue: '(N/A)', selected: true },
      { id: 18, filterName: 'Market Type', filterValue: 'Market A', selected: true },
      { id: 69, filterName: 'Node Type', filterValue: 'CMSAN', selected: true },
      { id: 14, filterName: 'Port Speed', filterValue: '100GE', selected: true },
      { id: 10, filterName: 'Product Type', filterValue: 'Backhaul', selected: true }
    ];
    spyOn(service, 'getFilterMasterInfo').and.returnValue(of(masterFilter));
    component.UpdatedFilterMasterInfo();
    // tslint:disable-next-line:no-unused-expression
    fixture.detectChanges;
    expect(component.UpdatedFilterMasterInfo).toBeDefined();
  });

  it('should check function onSavePreference', () => {
    // tslint:disable-next-line:prefer-const
    let savepref;
    // spyOn(service, 'getSaveUserPre').and.returnValue(of({}));
    expect(component.onSavePreference(savepref)).toBeUndefined();
  });

  it('should check function getFilterResults', () => {
    component.getFilterResults();
    expect(component.getFilterResults).toBeDefined();
    expect(component.showFilter).toBe(true);
  });

  it('should check function fetchMasterInfo', () => {
    component.savedvalue = false;
    const masterFilter = [
      { id: 79, filterName: 'Card Model', filterValue: 'IMM 1 x 100G', selected: true },
      { id: 44, filterName: 'Card Type', filterValue: '1 x 10GB MDA', selected: true },
      { id: 56, filterName: 'Card Version', filterValue: '(12Pt Lic)', selected: true },
      { id: 16, filterName: 'Chassis Speed', filterValue: '1 TB', selected: true },
      { id: 1, filterName: 'Device Model', filterValue: '7750 SR-12', selected: true },
      { id: 6, filterName: 'Device Type', filterValue: 'Edge Rt', selected: true },
      { id: 3, filterName: 'Device Usage', filterValue: 'EEA', selected: true },
      { id: 7, filterName: 'Device Version', filterValue: '(N/A)', selected: true },
      { id: 18, filterName: 'Market Type', filterValue: 'Market A', selected: true },
      { id: 69, filterName: 'Node Type', filterValue: 'CMSAN', selected: true },
      { id: 14, filterName: 'Port Speed', filterValue: '100GE', selected: true },
      { id: 10, filterName: 'Product Type', filterValue: 'Backhaul', selected: true }
    ];
    component.fetchMasterInfo();
    expect(component.fetchMasterInfo).toBeDefined();
  });

  it('should check function open', () => {
    const modalService = fixture.debugElement.injector.get(NgbModal);
    spyOn(modalService, 'open').and.callThrough();
    component.open('aa');
    expect(modalService.open).toHaveBeenCalled();
    // expect(component.open).toBeDefined();

  });

  it('should check function getDismissReason', () => {
    spyOn<any>(component, 'getDismissReason').and.returnValue('');

  });

  it('getFilterMasterInfo should return value from observable', () => {
    service.getFilterMasterInfo().subscribe(value => {
      expect(value).toBe('observable value');
    });
  });

  it('Service injected in FilterComponent',
    inject([AppService], (injectService: AppService) => {
      expect(injectService).toBe(testBedService);
    })
  );

  it('should check function expandFilterResults', () => {

    const mockedDocElement = document.createElement('div');
    document.getElementById = jasmine.createSpy('ChanButton').and.returnValue(mockedDocElement);
    const txtBtn = fixture.debugElement.query(By.css('#ChanButton'));
    const txtBtn1 = 'Expand All';
    expect(txtBtn).toEqual(null);
    component.expandFilterResults();
    expect(component.expandFilterResults).toBeDefined();
  });

  it('should check function expandFilterResults yes', () => {
    fixture.detectChanges();
    const mockedDocElement = document.createElement('div');
    document.getElementById = jasmine.createSpy('ChanButton').and.returnValue(mockedDocElement);
    document.getElementById('ChanButton').innerHTML = 'Expand All';
    const txtBtn = fixture.debugElement.query(By.css('#ChanButton'));
    component.expandFilterResults();
    expect(component.expandFilterResults).toBeDefined();
  });


  it('should check function clearFilterResults', () => {
    component.clearFilterResults();
    expect(component.clearFilterResults).toBeDefined();
  });

  it('should check function openSavePrefModal', () => {
    const content = 'abcc';
    component.openSavePrefModal(content);
    expect(component.openSavePrefModal).toBeDefined();
  });

  it('should check function clearSaveSearches', () => {
    component.clearSaveSearches();
    expect(component.clearSaveSearches).toBeDefined();
  });

  it('should check function expandFilterResults Button text change', () => {
    const button = fixture.debugElement.query(By.css('#ChanButton'));
    //   console.log(button);
    expect(button).toEqual(null);
  });
});
