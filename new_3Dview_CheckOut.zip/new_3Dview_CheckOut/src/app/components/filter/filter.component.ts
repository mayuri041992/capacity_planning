import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { filterObject } from '../../shared/models/filterObject.model';
import { AppService } from '../../core/services/app-service/app.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbAccordion } from '@ng-bootstrap/ng-bootstrap';
import { pageObject } from '../../shared/models/pageObject.model';
import {  NO_ERRORS_SCHEMA  } from '@angular/core';
import { MessageService } from 'primeng/api';
import { environment } from '../../../environments/environment';
import { debounceTime } from 'rxjs/operators';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss'],
})

export class FilterComponent implements OnInit {

  public savePre = {
    ein: null,
    filterIds: []
  };
  public showFilter = false;
  public savedvalue = true;
  public einId;
  public siteFilterData;
  deviceModel: any[];
  deviceUsages: any[];
  deviceType: any[];
  deviceVersion: any[];
  productType: any[];
  portSpeed: any[];
  chassisSpeed: any[];
  cardModel: any[];
  cardType: any[];
  cardVersion: any[];
  marketType: any[];
  nodeType: any[];
  filterObj = new filterObject();
  active = this.initActiveObj();
  closeResult: string;
  filterObject = this.filterObj.exchangeInfoFilterRequest;
  invokeServiceCall = new BehaviorSubject<boolean>(false);
  public preferenceName: string;
  marked = false;
  public preferenceType: string;
  public preferenceTypes = [
    'Private',
    'Public'
  ];
  // tslint:disable-next-line:variable-name
  public _success = new Subject<string>();
  // tslint:disable-next-line:variable-name
  public _danger = new Subject<string>();
  successMessage: string;
  dangerMessage: string;
  private initActiveObj() {
    return {
      device_Model: true,
      Device_Usages: true,
      Device_Type: true,
      Device_Version: true,
      Product_Type: true,
      Port_Speed: true,
      card_Model: true,
      card_Type: true,
      card_Version: true,
      market_Type: true,
      chassisSpeed: true,
      node_Type: true
    };
  }
  constructor(private service: AppService, private messageService: MessageService, private modalService: NgbModal) {
    this.einId = environment.ein;
    // this.einId = 6125327639
    this.filterObj.exchangeInfoFilterRequest.ein = Number(this.einId);
    this.getSavedPref();
    this._success.subscribe((message) => this.successMessage = message);
    this._success.pipe(debounceTime(1000)).subscribe(() => this.successMessage = null);
    this._danger.subscribe((message) => this.dangerMessage = message);
    this._danger.pipe(debounceTime(2000)).subscribe(() => this.dangerMessage = null);
  }

  ngOnInit() {
  }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    this.active = this.initActiveObj();
    this.fetchMasterInfo();
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getSavedPref() {
    this.service.getSavedpref(this.einId).subscribe((siteFilterData) => {
      this.service.Rowdata.next(siteFilterData);
      this.siteFilterData = siteFilterData;
      // tslint:disable-next-line:no-string-literal
      if (this.siteFilterData && siteFilterData['filterMasterResponse'] !== null) {
        // tslint:disable-next-line:no-string-literal
        const masterInfo = this.siteFilterData['filterMasterResponse'];
        masterInfo.forEach((filterData) => {
          if (filterData.selected) {
            if (filterData.filterName === 'Device Model') {
              const deviceModel = this.filterObject.deviceModel as string[];
              if (deviceModel.indexOf(filterData.filterValue) === -1) {
                this.filterObject.deviceModel.push(filterData.filterValue);

              }
            }
            if (filterData.filterName === 'Device Usage') {
              const deviceUsages = this.filterObject.deviceUsages as string[];
              if (deviceUsages.indexOf(filterData.filterValue) === -1) {
                this.filterObject.deviceUsages.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Device Type') {
              const deviceType = this.filterObject.deviceType as string[];
              if (deviceType.indexOf(filterData.filterValue) === -1) {
                this.filterObject.deviceType.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Device Version') {
              const deviceVersion = this.filterObject.deviceVersion as string[];
              if (deviceVersion.indexOf(filterData.filterValue) === -1) {
                this.filterObject.deviceVersion.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Product Type') {
              const productType = this.filterObject.productType as string;
              if (productType.indexOf(filterData.filterValue) === -1) {
                this.filterObject.productType = filterData.filterValue;
              }
            }
            if (filterData.filterName === 'Port Speed') {
              const portSpeed = this.filterObject.portSpeed as string[];
              if (portSpeed.indexOf(filterData.filterValue) === -1) {
                this.filterObject.portSpeed.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Chassis Speed') {
              const ChassisSpeed = this.filterObject.chassisSpeed as string[];
              if (ChassisSpeed.indexOf(filterData.filterValue)) {
                this.filterObject.chassisSpeed.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Market Type') {
              const marketType = this.filterObject.marketType as string[];
              if (marketType.indexOf(filterData.filterValue) === -1) {
                this.filterObject.marketType.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Card Model') {
              const cardModel = this.filterObject.cardModel as string[];
              if (cardModel.indexOf(filterData.filterValue) === -1) {
                this.filterObject.cardModel.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Card Type') {
              const cardType = this.filterObject.cardType as string[];
              if (cardType.indexOf(filterData.filterValue) === -1) {
                this.filterObject.cardType.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Card Version') {
              const cardVersion = this.filterObject.cardVersion as string[];
              if (cardVersion.indexOf(filterData.filterValue) === -1) {
                this.filterObject.cardVersion.push(filterData.filterValue);
              }
            }
            if (filterData.filterName === 'Node Type') {
              const nodeType = this.filterObject.nodeType as string[];
              if (nodeType.indexOf(filterData.filterValue) === -1) {
                this.filterObject.nodeType.push(filterData.filterValue);
              }
            }
            this.savePre.filterIds.push(filterData.id);
          }
          // this.savePre.filterIds.push(filterData.id);
        });
        this.service.initFilterObject.next({ ...this.filterObj });
        this.showFilter = true;
        this.service.selectedFilter.next(true);
      }
    });
  }

  fetchMasterInfo() {
    this.service.getFilterMasterInfo({ ...this.filterObject }).subscribe((masterFilter) => {
      if (this.savedvalue) {
        this.savedvalue = false;
        this.bindDataFilter(masterFilter);
      //  this.service.initFilterObject.next({ ...this.filterObj });
      }
    });
  }

  bindDataFilter(masterFilter) {

    this.deviceModel = masterFilter.filter(x => x.filterName === 'Device Model');
    this.deviceUsages = masterFilter.filter(x => x.filterName === 'Device Usage');
    this.deviceType = masterFilter.filter(x => x.filterName === 'Device Type');
    this.deviceVersion = masterFilter.filter(x => x.filterName === 'Device Version');
    this.productType = masterFilter.filter(x => x.filterName === 'Product Type');
    this.portSpeed = masterFilter.filter(x => x.filterName === 'Port Speed');
    this.chassisSpeed = masterFilter.filter(x => x.filterName === 'Chassis Speed');
    this.marketType = masterFilter.filter(x => x.filterName === 'Market Type');
    this.cardModel = masterFilter.filter(x => x.filterName === 'Card Model');
    this.cardType = masterFilter.filter(x => x.filterName === 'Card Type');
    this.nodeType = masterFilter.filter(x => x.filterName === 'Node Type');
    this.cardVersion = masterFilter.filter(x => x.filterName === 'Card Version');
    /*
      device model is not a default value
    */
    // this.savePre.filterIds.push(1);


    /*
      the filterObject is reset , to prevent addition of dup value
      ein is set to logged user ein
    */
    // this.filterObject =  { ...new filterObject().exchangeInfoFilterRequest, ein: +this.loginService.EIN }
    this.savePre.filterIds = [];
    this.filterObject.deviceModel = [];
    const deviceModels: any = [];
    this.deviceModel.forEach(element => {
      deviceModels.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.deviceModel.push(element.filterValue);
      }
    });
    this.deviceModel = deviceModels;
    this.filterObject.deviceUsages = [];
    const deviceUsage: any = [];
    this.deviceUsages.forEach(element => {
      deviceUsage.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.deviceUsages.push(element.filterValue);
      }
    });
    this.deviceUsages = deviceUsage;
    this.filterObject.deviceType = [];
    const deviceTypes: any = [];
    this.deviceType.forEach(element => {
      deviceTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.deviceType.push(element.filterValue);
      }
    });
    this.deviceType = deviceTypes;
    this.filterObject.deviceVersion = [];
    const deviceVersions: any = [];
    this.deviceVersion.forEach(element => {
      deviceVersions.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.deviceVersion.push(element.filterValue);
      }
    });
    this.deviceVersion = deviceVersions;
    this.filterObject.productType = '';
    const productTypes: any = [];
    this.productType.forEach(element => {
      productTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.productType = element.filterValue;
      }
    });
    this.productType = productTypes;
    this.filterObject.portSpeed = [];
    const portSpeeds: any = [];
    this.portSpeed.forEach(element => {
      portSpeeds.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.portSpeed.push(element.filterValue);
      }
    });
    this.portSpeed = portSpeeds;
    this.filterObject.chassisSpeed = [];
    const chassisSpeeds: any = [];
    this.chassisSpeed.forEach(element => {
      chassisSpeeds.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.chassisSpeed.push(element.filterValue);
      }
    });
    this.chassisSpeed = chassisSpeeds;
    const marketTypes: any = [];
    this.filterObject.marketType = [];
    this.marketType.forEach(element => {
      marketTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.marketType.push(element.filterValue);
      }
    });
    this.marketType = marketTypes;
    this.filterObject.cardModel = [];
    const cardModels: any = [];
    this.cardModel.forEach(element => {
      cardModels.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.cardModel.push(element.filterValue);
      }
    });
    this.cardModel = cardModels;
    const cardTypes: any = [];
    this.filterObject.cardType = [];
    this.cardType.forEach(element => {
      cardTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.cardType.push(element.filterValue);
      }
    });
    this.cardType = cardTypes;
    const nodeTypes: any = [];
    this.filterObject.nodeType = [];
    this.nodeType.forEach(element => {
      nodeTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.nodeType.push(element.filterValue);
      }
    });
    this.nodeType = nodeTypes;
    this.filterObject.cardVersion = [];
    const cardVersions: any = [];
    this.cardVersion.forEach(element => {
      cardVersions.push({ title: element.filterValue, value: element.selected, id: element.id });
      if (element.selected) {
        this.savePre.filterIds.push(Number(element.id));
        this.filterObject.cardVersion.push(element.filterValue);
      }
    });
    this.cardVersion = cardVersions;
  }

  filtertoggle(param) {
    const currentActiveState = this.active[param];
    // document.getElementById('modId').style.height = 200 + 'px';
    const ele = document.getElementById('modId');
    if (ele) {
      ele.style.removeProperty('height');
    }
    this.active = this.initActiveObj();
    this.active[param] = !currentActiveState;
  }

  onSavePreference(savepref) {
    this.savePre.ein = this.einId;
    this.service.getSaveUserPre(this.savePre).subscribe((data) => {
      this._success.next(`Preference Saved`);
    },
      () => { this._danger.next(`Preference Not Saved`); }
    );
  }

  toggle(event, filterOn) {
    const saveFilterId = new Set(this.savePre.filterIds);
    if (filterOn === 'productType') {
      this.productType.map((prod) => {
        if (saveFilterId.has(Number(prod.id))) {
          saveFilterId.delete(Number(prod.id));
        }
        return prod;
      });
      this.productType.forEach((prodObj) => {
        if (prodObj.title === event.target.value) {
          prodObj.value = !prodObj.value;
        } else {
          prodObj.value = false;
        }
      });
      this.filterObject[filterOn] = event.target.value;
      saveFilterId.add(Number(event.target.id));
    } else {
      const filterSet = new Set(this.filterObject[filterOn]);
      if (event.target.checked) {
        filterSet.add(event.target.value);
        saveFilterId.add(Number(event.target.id));
      } else {
        filterSet.delete(event.target.value);
        saveFilterId.delete(Number(event.target.id));
      }
      this.filterObject[filterOn] = Array.from(filterSet.values());
    }
    this.savePre.filterIds = Array.from(saveFilterId.values());
    this.UpdatedFilterMasterInfo({ ...this.filterObject });
  }

  UpdatedFilterMasterInfo(body: object = {}) {
    this.service.getFilterMasterInfo(body).subscribe((masterFilter) => {
      this.deviceModel = [];
      this.deviceUsages = [];
      this.deviceType = [];
      this.deviceVersion = [];
      this.productType = [];
      this.portSpeed = [];
      this.chassisSpeed = [];
      this.cardModel = [];
      this.cardType = [];
      this.cardVersion = [];
      this.marketType = [];
      this.nodeType = [];
      this.upadtedDataFilter(masterFilter);
    });
  }

  upadtedDataFilter(masterFilter) {
    this.deviceModel = masterFilter.filter(x => x.filterName === 'Device Model');
    this.deviceUsages = masterFilter.filter(x => x.filterName === 'Device Usage');
    this.deviceType = masterFilter.filter(x => x.filterName === 'Device Type');
    this.deviceVersion = masterFilter.filter(x => x.filterName === 'Device Version');
    this.productType = masterFilter.filter(x => x.filterName === 'Product Type');
    this.portSpeed = masterFilter.filter(x => x.filterName === 'Port Speed');
    this.chassisSpeed = masterFilter.filter(x => x.filterName === 'Chassis Speed');
    this.marketType = masterFilter.filter(x => x.filterName === 'Market Type');
    this.cardModel = masterFilter.filter(x => x.filterName === 'Card Model');
    this.cardType = masterFilter.filter(x => x.filterName === 'Card Type');
    this.nodeType = masterFilter.filter(x => x.filterName === 'Node Type');
    this.cardVersion = masterFilter.filter(x => x.filterName === 'Card Version');
    const deviceModel: any = [];
    this.deviceModel.forEach(element => {
      deviceModel.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.deviceModel = deviceModel;
    const deviceUsage: any = [];
    this.deviceUsages.forEach(element => {
      deviceUsage.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.deviceUsages = deviceUsage;
    const deviceTypes: any = [];
    this.deviceType.forEach(element => {
      deviceTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.deviceType = deviceTypes;
    const deviceVersions: any = [];
    this.deviceVersion.forEach(element => {
      deviceVersions.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.deviceVersion = deviceVersions;
    const productTypes: any = [];
    this.productType.forEach(element => {
      productTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.productType = productTypes;
    const portSpeeds: any = [];
    this.portSpeed.forEach(element => {
      portSpeeds.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.portSpeed = portSpeeds;
    const chassisSpeeds: any = [];
    this.chassisSpeed.forEach(element => {
      chassisSpeeds.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.chassisSpeed = chassisSpeeds;
    const marketTypes: any = [];

    this.marketType.forEach(element => {
      marketTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.marketType = marketTypes;
    const cardModels: any = [];
    this.cardModel.forEach(element => {
      cardModels.push({ title: element.filterValue, value: element.selected, id: element.id });
    });

    this.cardModel = cardModels;
    const cardTypes: any = [];
    this.cardType.forEach(element => {
      cardTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.cardType = cardTypes;
    const nodeTypes: any = [];
    this.nodeType.forEach(element => {
      nodeTypes.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.nodeType = nodeTypes;
    const cardVersions: any = [];
    this.cardVersion.forEach(element => {
      cardVersions.push({ title: element.filterValue, value: element.selected, id: element.id });
    });
    this.cardVersion = cardVersions;
  }

  getFilterResults() {
    this.service.loading.next(true);
    const pageData = new pageObject();
    this.service.callExchangeInfo.next(true);
    this.service.initFilterObject.next({ ...this.filterObj });
   // this.service.initPageObject.next({ ...pageData, pageNo: 0 });
    this.showFilter = true;
    this.service.selectedFilter.next(true);
    this.service.showdata.next(true);
    this.modalService.dismissAll();
  }

  expandFilterResults() {
    const txtBtn = document.getElementById('ChanButton').innerText;
    if (txtBtn === 'Expand All') {
      document.getElementById('ChanButton').innerText = 'Collapse';
      document.getElementById('modId').style.height = 500 + 'px';
      this.active = this.initActiveObj();
      const key = Object.keys(this.active);
      key.forEach((a) => {
        this.active[a] = false;
      });
    }    else {

      document.getElementById('ChanButton').innerText = 'Expand All';
      const ele = document.getElementById('modId');
      ele.style.removeProperty('height');
      this.active = this.initActiveObj();

    }
  }

  clearFilterResults() {
    this.savePre.filterIds = [];
    this.filterObject.deviceModel = [];
    this.filterObject.deviceUsages = [];
    this.filterObject.deviceType = [];
    this.filterObject.deviceVersion = [];
    this.filterObject.productType = '';
    this.filterObject.portSpeed = [];
    this.filterObject.chassisSpeed = [];
    this.filterObject.marketType = [];
    this.filterObject.cardModel = [];
    this.filterObject.cardType = [];
    this.filterObject.nodeType = [];
    this.filterObject.cardVersion = [];
    this.deviceModel = [];
    this.deviceUsages = [];
    this.deviceType = [];
    this.deviceVersion = [];
    this.productType = [];
    this.portSpeed = [];
    this.chassisSpeed = [];
    this.cardModel = [];
    this.cardType = [];
    this.cardVersion = [];
    this.marketType = [];
    this.nodeType = [];
    this.savedvalue = true;
    this.fetchMasterInfo();
  }


  // Opens Save Pref Modal
  openSavePrefModal(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', windowClass: 'save-pref-modal' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      // TODO api call to save preference with name
      this.service.addSavePreferenceSubject.next(this.preferenceName);
      this.clearSaveSearches();
    }, (reason) => {
      this.clearSaveSearches();
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  // to clear data on Save Search popup
  clearSaveSearches() {
    this.preferenceType = '';
    this.preferenceName = '';
  }
}

