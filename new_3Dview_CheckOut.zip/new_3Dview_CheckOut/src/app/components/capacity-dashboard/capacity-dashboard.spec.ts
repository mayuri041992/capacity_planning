import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CapacityDashboardComponent } from './capacity-dashboard';
import { FilterComponent } from '../filter/filter.component';
import { CapacityDemandPredictionComponent } from '../capacity-demand-prediction-report/capacity-demand-prediction-report';
import { SvgComponent } from '../../shared/components/svg/svg.component';
import { Component, Renderer, ElementRef } from '@angular/core';
import { ToastModule } from 'primeng/toast';
import { NgxLoadingModule } from 'ngx-loading';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { By } from '@angular/platform-browser';
import { LoginService } from '../../core/services/login-service/login.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('CapacityDashboardComponent', () => {
  let component: CapacityDashboardComponent;
  let fixture: ComponentFixture<CapacityDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ToastModule, NgxLoadingModule, PaginatorModule, TableModule, NgbModule, HttpClientTestingModule, RouterTestingModule],
      declarations: [CapacityDashboardComponent, FilterComponent, CapacityDemandPredictionComponent, SvgComponent],
      providers: [MessageService, LoginService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CapacityDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should check function OnLoad', () => {
    component.loading = true;
    component.OnLoad(component.loading);
    expect(component.OnLoad).toBeDefined();
  });

  it('should check header component', () => {
    expect(component).toBeDefined();
    expect(fixture.debugElement.query(By.css('filter'))).toBeTruthy();
  });

  it('should check navigation component', () => {
    expect(fixture.debugElement.query(By.css('capacity-demand-prediction'))).toBeTruthy();

  });
});
