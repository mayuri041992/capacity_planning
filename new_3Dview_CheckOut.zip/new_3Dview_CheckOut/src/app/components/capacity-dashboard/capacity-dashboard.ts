import { Component } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'capacity-dashboard',
  templateUrl: './capacity-dashboard.html',
  styleUrls: ['./capacity-dashboard.scss']
})
export class CapacityDashboardComponent  {
  loading = false;
  OnLoad(event: boolean) {
    this.loading = true;
  }

}
