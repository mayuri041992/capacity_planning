import { Component, OnInit, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of, Subject, Subscription } from 'rxjs';
import { debounceTime, switchMap, catchError, map, take, timeout } from 'rxjs/operators';
import { ngxCsv } from 'ngx-csv/ngx-csv';
import { AppService } from '../../core/services/app-service/app.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-divercity-report',
  templateUrl: './divercity-report.component.html',
  styleUrls: ['./divercity-report.component.scss']
})
export class DiversityReportComponent implements OnInit, OnDestroy {

  diversityForm = new FormGroup({
    ports: new FormControl(null, [Validators.required, this.formPortValidation]),
    groupName: new FormControl('', [Validators.required, this.formGroupNameValidate.bind(this)]),
    code: new FormControl('', [Validators.required, this.formCodeValidate.bind(this)])
  });
  closeResult: string;
  ports: number;
  groupName: '';
  code: '';
  public searchInput;

  public rows  = [];
  public searchObject = {
    port: null,
    groupName: '',
    code: ''
  };
  data;
  @ViewChild('content') content: ElementRef;
  columnShow: Array<any> = [
    { header: 'MSE(SNE ID)', field: 'sneId' },
    { header: 'Card Detail', field: 'cardDetail' },
    { header: 'Free Port Details', field: 'freePortDetail' },
    { header: 'Card Status', field: 'cardStatus'}
  ];
  @ViewChild('headerWidth') headerWidth: ElementRef;
  messageRow;
  diversityReportUnsubcribe: Subscription;
  flagGroupName = '';
  flagCode;
  public dangerMsg = new Subject<string>();
  dangerMessage: string;
  constructor(private modalService: NgbModal, private services: AppService,  private router: Router) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.diversityReportUnsubcribe = this.services.diversityReport$.subscribe((dataJson) => {
      this.data = dataJson;
      if (this.data.diversityGroupForecastList) {
        this.rows = this.data.diversityGroupForecastList;
      } else {
        this.rows = [];
      }
      this.messageRow = this.data.portAvailablity;
      this.dangerMsg.next(this.messageRow);
       // console.log(this.messageRow);
    }, (err) => { });
    this.dangerMsg.subscribe((message) => this.dangerMessage = message);
    // this.dangerMsg.pipe(debounceTime(4000)).subscribe(() => this.dangerMessage = null);
  }
  ngOnInit() {
  }
  // Search Api Call for diversity GropName search
  searchDG = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      switchMap(term =>
        this.services.getGroupNameSearch(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    )
  // Search Api Call for Site Name and 1141 Code search
  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      switchMap(term =>
        this.services.getSiteNameDiversitySearch(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    )
    formatter = (result: { data: string }) => result.data;
  public onClear(event: any) {
    if ((event.target as HTMLInputElement).value === '') {
      this.searchInput = '';
    }
  }
  // function for popup modal on info.
  openVerticallyCentered() {
    const modalRef = this.modalService.open(this.content, { centered: true, windowClass: 'diversity' });
  }
  // function for form validation.
  formPortValidation(control: FormControl): { [msg: string]: boolean } {
    if (control.value) {
      const pattern = /[0-9]/;
      const inputChar = String.fromCharCode(control.value.charCode);
      if ((+control.value > 40 || (+control.value <= 0))) {
        return { portsValid: true };
      }
      return null;
    }
  }
  // GroupName and code custom validator
  formGroupNameValidate(control: FormControl): {[msg: string]: boolean} {
    if (this.flagGroupName && this.flagGroupName !== '' ) {
      if (control.value !== this.flagGroupName) {
        return { validGroupName : true };
      }
      return null;
    }
    return { validCodeGroupName : true };
  }
  formCodeValidate(control: FormControl): {[msg: string]: boolean} {
    if (this.flagCode && this.flagCode !== '' ) {
      if (control.value.data !== this.flagCode) {
        return { validCode : true };
      }
      return null;
    }
    return { validCode : true };
  }
  // key press function for not entering value other than number.
  keyPress(event: any) {
    const pattern = /[0-9]/;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }
  // Function for submit the form on click.
  onSubmit() {
    if (this.searchObject.code !== this.diversityForm.value.code ||
      this.searchObject.groupName !== this.diversityForm.value.groupName ||
      this.searchObject.port !== this.diversityForm.value.ports) {
      this.searchObject.code = this.diversityForm.value.code;
      this.searchObject.groupName = this.diversityForm.value.groupName;
      this.searchObject.port = this.diversityForm.value.ports;
      this.services.diversityReport.next(this.searchObject);
      this.dangerMsg.next('');
    }
    }
  // It is for download the XLX from java side and make api call.
  downloadXLXReport() {
    this.services.getDownloadDiversityReport(this.searchObject);
  }
  selected(item, formName) {
    if (formName === 'groupName') {
      this.flagGroupName = item.item;
    } else if (formName === 'code') {
      this.flagCode = item.item.data;
    }
  }
  // to destroy the service call on change of page or anything.
  ngOnDestroy() {
    this.services.diversityReport.next('');
    this.diversityReportUnsubcribe.unsubscribe();
  }
}
