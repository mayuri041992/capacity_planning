import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SvgComponent } from '../../shared/components/svg/svg.component';
import { RouterTestingModule } from '@angular/router/testing';
import { TableComponent } from '../../shared/components/table/table.component';
import { ReactiveFormsModule, FormsModule, FormControl, FormBuilder, FormGroup, Validators, FormGroupName  } from '@angular/forms';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ForecastLineService } from '../../core/services/product-line-forecast-service/product-line-forecast.service';
import { AppService } from '../../core/services/app-service/app.service';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { controllers } from 'chart.js';
import { NgbModalRef, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { of } from 'rxjs';
import { DiversityReportComponent } from './divercity-report.component';



describe('DiversityReportComponent', () => {
  let component: DiversityReportComponent;
  let fixture: ComponentFixture<DiversityReportComponent>;
  let services: AppService;
  const formBuilder: FormBuilder = new FormBuilder();
  const mockData = {
    diversityGroupForecastList: '',
    portAvailablity: 'Not Enough Capacity'
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiversityReportComponent , SvgComponent , TableComponent ] ,
      providers : [RouterTestingModule , HttpClient , HttpHandler , ForecastLineService],
      imports: [FormsModule, ReactiveFormsModule, NgbModule ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    }).overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [DiversityReportComponent] } })
    .compileComponents();
    services = TestBed.get(AppService);
  
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiversityReportComponent);
    component = fixture.componentInstance;
    component.diversityForm = new FormGroup({
      ports: new FormControl(null, Validators.required),
      groupName: new FormControl('', Validators.required),
      code: new FormControl('' , Validators.required)
     });
    // mockEvent = new Event('inputChar');
    // spyOn(mockEvent, 'preventDefault');
    // services = TestBed.get(AppService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    services.diversityReport.next(mockData);
    component.dangerMsg.next('some data');
    spyOn(component, 'dangerMsg').and.returnValue(of('some data'));
   // spyOn(services, 'diversityReport$').and.callFake(() => true );
    });
  it('should define openVerticallyCentered', ()  =>  {
    component.openVerticallyCentered();
    expect(component.openVerticallyCentered).toBeDefined();
  });

  it('should define keyPress', () => {
    const event = {
      charCode: 67,
      preventDefault : () => {}
};
    component.keyPress(event);
    expect(component.keyPress).toBeDefined();
  });
  it('should define ', () => {
    const event = {
      charCode: 67,
      preventDefault : () => {}
};
    component.keyPress(event);
    expect(component.keyPress).toBeDefined();
  });

  it('should define onSubmit groupname', () => {
    component.searchObject.code = 'abcd';
    component.searchObject.groupName = 'ab';
    component.searchObject.port = 10;
    expect(component.onSubmit()).not.toBeNull();
  });
  it('should define onSubmit for code check condition', () => {
    component.searchObject.code = '';
    component.searchObject.groupName = 'acd';
    component.searchObject.port = 20;
    expect(component.onSubmit()).not.toBeNull();
  });
  it('should define onSubmit for port check condition', () => {
    component.searchObject.code = '';
    component.searchObject.groupName = '';
    component.searchObject.port = 10;
    expect(component.onSubmit()).not.toBeNull();
  });

  it('should define selected ', () => {
    const item =  {
      groupName: 'EE-BTREN-1',
      code: 'LONDON FOREST HILL'
    };
    const formGroup = 'groupName';
    component.flagGroupName = 'groupName';
    component.selected(item, formGroup);
    expect(component.selected).toBeDefined();
    const appService = fixture.debugElement.injector.get(AppService);
    appService.diversityReport.next('null');
    spyOn(appService, 'diversityReport$').and.returnValue(of([1]));
  });
  it('should define selected ', () => {
    const item =  {
      groupName: 'EE-BTREN-1',
      code: 'LONDON FOREST HILL',
      item: {
        data: 'LONDON FOREST HILL'
      }
    };
    const formGroup = 'code';
    component.flagGroupName = 'code';
    component.selected(item, formGroup);
    expect(component.selected).toBeDefined();
    const appService = fixture.debugElement.injector.get(AppService);
    appService.diversityReport.next('null');
    spyOn(appService, 'diversityReport$').and.returnValue(of([1]));
  });
  it('should define selected ', () => {
    const item =  {
      groupName: 'EE-BTREN-1',
      code: 'LONDON FOREST HILL'
    };
    const formGroup = 'port';
    component.flagGroupName = 'port';
    component.selected(item, formGroup);
    expect(component.selected).toBeDefined();
    const appService = fixture.debugElement.injector.get(AppService);
    appService.diversityReport.next('null');
    spyOn(appService, 'diversityReport$').and.returnValue(of([1]));
  });

  it('should define downloadXLXReport', () => {
    const a = component.searchObject = {
      port: 20,
      groupName: 'EE-BTRN-1',
      code: 'LONDON FOREST HILL'

    };
    expect(component.downloadXLXReport()).toBeUndefined();
  });
  it('should define ngOnDestroy', () => {
    component.ngOnDestroy();
    expect(component.ngOnDestroy()).not.toBeDefined();
  });
  it('should define formCodeValidate', () => {
    // tslint:disable-next-line:prefer-const
    let control = new FormControl('code');
    control.setValue('abcd');
    component.flagCode = 'abc';
    component.formCodeValidate(control);
    expect(component.formCodeValidate).toBeDefined();
  });
  it('should define formCodeValidate for return true', () => {
    // tslint:disable-next-line:prefer-const
    let control = new FormControl('code');
    control.setValue('abc');
    component.flagCode = 'abc';
    component.formCodeValidate(control);
    expect(component.formCodeValidate).toBeDefined();
  });
  it('should define formGroupNameValidate', () => {
    // tslint:disable-next-line:prefer-const
    let control = new FormControl('groupName');
    control.setValue('abc');
    component.flagGroupName = 'abc';
    component.formGroupNameValidate(control);
    expect(component.formGroupNameValidate).toBeDefined();
  });
  it('should define formGroupNameValidate for return true', () => {
    // tslint:disable-next-line:prefer-const
    let control = new FormControl('groupName');
    control.setValue('abcf');
    component.flagGroupName = 'abc';
    component.formGroupNameValidate(control);
    expect(component.formGroupNameValidate).toBeDefined();
  });
  it('should define formPortValidation ', () => {
    // tslint:disable-next-line:prefer-const
    let control = new FormControl('port');
    control.setValue(2);
    component.ports = 2;
    component.formPortValidation(control);
    expect(component.formPortValidation).toBeDefined();
  });
  it('should define formPortValidation for return true', () => {
    // tslint:disable-next-line:prefer-const
    let control = new FormControl('port');
    control.setValue(42);
    component.ports = 2;
    component.formPortValidation(control);
    expect(component.formPortValidation).toBeDefined();
  });
});
