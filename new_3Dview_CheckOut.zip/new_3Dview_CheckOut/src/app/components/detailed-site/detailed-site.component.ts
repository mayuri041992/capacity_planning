// tslint:disable-next-line:max-line-length
import { Component, OnInit, Output, EventEmitter, Input, ViewChild, ElementRef, OnDestroy, AfterViewInit, AfterViewChecked } from '@angular/core';
import { Observable, of, Subscription } from 'rxjs';
import { catchError, debounceTime, map, switchMap } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../../core/services/app-service/app.service';
import { DetailedSiteObject } from '../../shared/models/detailedSiteObject.model';
import * as html2canvas from 'html2canvas';


export interface BarDataSetObject {
  label: string;
   data: number[];
  backgroundColor: string;
  borderColor: string;
  stack: number;
}
// import { jsonpCallbackContext } from '@angular/common/http';

@Component({
  selector: 'app-detailed-site',
  templateUrl: './detailed-site.component.html',
  styleUrls: ['./detailed-site.component.scss']
})
export class DetailedSiteComponent implements OnInit, OnDestroy {
  detailsiteservice$: Subscription;
  @ViewChild('abc') screen: ElementRef;
  @ViewChild('canvas') canvas: ElementRef;
  @ViewChild('downloadLink') downloadLink: ElementRef;
  @ViewChild('headerWidth') headerWidth: ElementRef;
  @ViewChild('pieScreen') pieScreen: ElementRef;
  datanew;
  loading = false;
  siteName = false;
  showResult = false;
  showlineData = false;
  showTableData = false;
  showBarChar = false;
  public detailedSiteObj: DetailedSiteObject = { searchType: '', serachData: '', productType: '' };
  rowGroupMetadata: any;
  testPieChart = '10GE';
  testPieCharts = '10GE';
  public searchInput;
  public searchtype;
  public searchData;
  public data1 = { responsive: false, maintainAspectRatio: false };
  public data;
  public tableRowData = [];
  datapies;
  datapiesbroad;
  totalPorts;
  totalPortsbroad;
  productTypeFlag = true;
  keyNetwork = [];
  trendArray = [];
  messageDisplay = 'Search the Site/SNE for Detailed Site Report';
  hightlightStatus: Array<boolean> = [];
  preSelectedProductTab = '';
  selectedProductType = '';
  public productType;
  pieHeight;
  // productType = [
  //   { name: 'Overall', active: true },
  //   { name: 'Ethernet', active: false },
  //   { name: 'Broadband', active: false },
  //   { name: 'Backhaul', active: false },
  //   { name: 'Infrastructure', active: false },
  //   { name: 'P2PE', active: false }
  // ];
  public serviceData = { label: [], dataset: []};
  databar = { labels: [] , datasets: [] };
  pieChartData = {
    ethernet: [],
    broadband: []
  };
  // dataPie = [['Backhaul ', 170.0], ['Broadband', 335.0], ['Ethernet', 200.0]];
  public index: number;
   productTab() {
    return [
      { name: 'Overall', active: true },
      { name: 'Ethernet', active: false },
      { name: 'Broadband', active: false },
      { name: 'Backhaul', active: false },
      { name: 'Infrastructure', active: false },
      { name: 'P2PE', active: false }
    ];
   }
  change(index: number): void {
    this.index = index;
  }

  handleChange(e) {
    this.index = e.index;
  }
  constructor(
    private activateRouter: ActivatedRoute,
    private services: AppService,
    private router: Router
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.detailsiteservice$ = this.services.detailedSiteChart$.subscribe((chartJson ) => {
      this.showBarChar = false;
      this.showResult = true;
      const lineBarJson = chartJson[0];
      this.loading = false;
      if ( chartJson.length === 2) {
        this.testPieCharts = '10G';
        this.testPieChart = '10G';
        this.productType = this.productTab();
        this.productTypeFlag = true;
        this.showlineData = false;
        this.showTableData = false;
        const donutTableJson = chartJson[1];
        // this.showResult = true;
        if (lineBarJson !== null && lineBarJson.dataPointsForQuarter) {
          this.showlineData = true;
          this.serviceData = {
            ...this.serviceData, label: lineBarJson.dataPointsForQuarter,
            dataset: lineBarJson.quarterlyData
          };
          this.data = { ...this.data1, trendName: 'line_char_detail', labels: this.serviceData.label, datasets: [] };
          this.serviceData.dataset.forEach(set => {
            const objectData = {};
            const value = {
              ...objectData,
              label: set.productType,
              data: set.totalPorts,
              fill: false,
              borderColor: ''
            };
            value.borderColor =  '#6D00A7';
            const BackhaulColor = new RegExp('Backhaul', 'gi');
            const BroadbandColor = new RegExp('Broadband', 'gi');
            const EthernetColor = new RegExp('Ethernet', 'gi');
            const InfrastructureColor = new RegExp('Infrastructure', 'gi');
            const P2PEColor = new RegExp('P2PE', 'gi');
            const TotalCapacityColor = new RegExp('Total Capacity', 'gi');
            if (value.label.match(BackhaulColor) && value.label.match(BackhaulColor).length > 0) {
              value.borderColor = '#0991ce';
            } else if (value.label.match(BroadbandColor) && value.label.match(BroadbandColor).length > 0) {
              value.borderColor = '#6400aa';
            } else if (value.label.match(EthernetColor) && value.label.match(EthernetColor).length > 0) {
              value.borderColor = '#FC8C1D';
            } else if (value.label.match(InfrastructureColor) && value.label.match(InfrastructureColor).length > 0) {
              value.borderColor = '#c1c1c1';
            } else if (value.label.match(P2PEColor) && value.label.match(P2PEColor).length > 0) {
              value.borderColor = '#e60050';
            } else if (value.label.match(TotalCapacityColor) && value.label.match(TotalCapacityColor).length > 0) {
              value.borderColor = '#6c6c6c';
            }
            this.data.datasets.push(value);
          });
        }
        if (donutTableJson !== null && donutTableJson.donutChartResponse) {
          this.showTableData = true;
          this.pieChartData.ethernet = [...donutTableJson.donutChartResponse.ethernet];
          this.pieChartData.broadband = [...donutTableJson.donutChartResponse.broadband];
          this.changePieChart('ethernet');
          this.changePieCharts('broadband');
          //  this.tableRowData = donutTableJson.tableChartResponses;
          setTimeout(() => {
            const that = this;
            const thwidth = (this.headerWidth.nativeElement.offsetWidth / 9) - 5.4;
            const classTh = Array.from(document.querySelectorAll('th'));
            classTh.map((th) => th.style.width = thwidth + 'px');
            this.tableRowData = donutTableJson.tableChartResponses;
            this.pieHeight = this.pieScreen.nativeElement.clientHeight + 'px';
            // tslint:disable-next-line:no-string-literal
            document.querySelector('.ui-table-thead')['style'].width = '98.9%';
            // console.log(this.pieHeight);
            // this is generated by the p-table
            const tableWrapper: HTMLElement = this.headerWidth.nativeElement.querySelector('.ui-table-wrapper');
            tableWrapper.style.height = this.pieHeight;
          }, 500);
        }
        if ( !this.showTableData &&  ! this.showlineData) {
          this.showResult = false;
          this.messageDisplay =  this.searchtype.replace(/NODE_TYPE/g, '1141_Code') + ' - ' + this.searchData + ' is not available';
        }
      } else if ( lineBarJson !== null && lineBarJson.dataPointsForHalfYearly) {
        this.showBarChar = true;
        this.databar.labels = [ ...lineBarJson.dataPointsForHalfYearly ];
        const halfYearlyData: object[] = lineBarJson.halfYearlyData;
        this.databar.datasets = halfYearlyData.map( ( data ) => {
          const dataObj: BarDataSetObject  = {} as BarDataSetObject;
          // tslint:disable-next-line:no-string-literal
          dataObj.label = data['portSpeed'];
          // tslint:disable-next-line:no-string-literal
          dataObj.data = data['totalPorts'];
          dataObj.borderColor =  '';

          // handle the backgroundColor
          dataObj.backgroundColor =  '#6D00A7';
          const freeportcolor = new RegExp('Free', 'gi');
          const reservedcolor = new RegExp('Reserved', 'gi');
          const usedcolor = new RegExp('Used', 'gi');
          if (dataObj.label.match(freeportcolor) && dataObj.label.match(freeportcolor).length > 0) {
            dataObj.backgroundColor = '#008A24';
          } else if (dataObj.label.match(reservedcolor) && dataObj.label.match(reservedcolor).length > 0) {
            dataObj.backgroundColor = '#6D00A7';
          } else if (dataObj.label.match(usedcolor) && dataObj.label.match(usedcolor).length > 0) {
            dataObj.backgroundColor = '#00A2D7';
          }
          // handle stack value
          const G1Reg = new RegExp('1G', 'gi');
          const G10Reg = new RegExp('10G', 'gi');
          const G100Reg = new RegExp('100G', 'gi');
          if (dataObj.label.match(G1Reg) && dataObj.label.match(G1Reg).length > 0) {
            dataObj.stack = 1;
          } else if (dataObj.label.match(G10Reg) && dataObj.label.match(G10Reg).length > 0) {
            dataObj.stack = 2;
          } else if (dataObj.label.match(G100Reg) && dataObj.label.match(G100Reg).length > 0) {
            dataObj.stack = 3;
          }
          return dataObj;
        });
        this.databar.datasets = [
          ...this.databar.datasets.filter( ( data ) => data.stack === 1) ,
          ...this.databar.datasets.filter( ( data ) => data.stack === 2),
          ...this.databar.datasets.filter( ( data ) => data.stack === 3)];
        this.databar = { ...this.databar };
      }
    }, (error) => {
      this.showResult = false;
      this.loading = false;
    } );
  }

  ngOnInit() {
    this.activateRouter.queryParams.subscribe((data) => {
      if (data.site_Name) {
        this.siteName = data.site_Name;
        this.detailedSiteObj.searchType = 'SITE_NAME';
        this.detailedSiteObj.serachData = data.site_Name;
        this.services.detailedSite.next(this.detailedSiteObj);
        this.loading = true;
      }
    });
    this.updateRowGroupMetaData();
  }
  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      switchMap(term =>
        this.services.getDetailedSiteSearch(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    )
  formatter = (result: { data: string }) => result.data;
  public onClear(event: any) {
    if ((event.target as HTMLInputElement).value === '') {
      this.searchInput = '';
    }
  }

  selected(item) {
    const searchValue = item;
    this.searchInput = searchValue.item.data;
    this.searchtype = searchValue.item.type;
    this.searchData = searchValue.item.data;
    this.siteName = searchValue.item.data;
    if (searchValue.item.description != null) {
      this.siteName = searchValue.item.description;
    }
    this.detailedSiteObj.searchType = searchValue.item.type;
    this.detailedSiteObj.serachData = searchValue.item.data;
    this.detailedSiteObj.productType = '';
    this.services.detailedSite.next(this.detailedSiteObj);
    this.loading = true;
  }

  changeProduct(type) {
    this.selectedProductType =  '';
    this.productType.forEach(element => {
      if (element.name === type.name) {
        element.active = true;
      } else {
        element.active = false;
      }
    });
    if (type.name === 'Overall') {
      this.productTypeFlag = true;
    } else {
      this.selectedProductType = type.name;
      this.productTypeFlag = false;
      this.detailedSiteObj.productType = this.selectedProductType;
      this.services.detailedSite.next({ ...this.detailedSiteObj });
      this.loading = true;
    }
  }

  changePieChart(value) {
    const portSpeed = this.pieChartData[value].filter((data) => {
      if (data.port === this.testPieChart) {
        return data;
      }
    });
    this.datapies = portSpeed[0].portValues;
    this.totalPorts = portSpeed[0].totalPort;
    this.datanew = {
      labels: ['Free Port', 'Used Port', 'Reserved Port'],
      datasets: [
        {
          data: this.datapies,
          backgroundColor: [
            '#008A24',
            '#00A2D7',
            '#6D00A7'
          ],
          hoverBackgroundColor: [
            '#02af2f',
            '#36A2EB',
            '#8b25c1'
          ]
        }]
    };
  }
  changePieCharts(value) {
    const portSpeed = this.pieChartData[value].filter((data) => {
      if (data.port === this.testPieCharts) {
        return data;
      }
    });
    this.datapiesbroad = portSpeed[0].portValues;
    this.totalPortsbroad = portSpeed[0].totalPort;
  }
  onSort() {
    this.updateRowGroupMetaData();
  }
  updateRowGroupMetaData() {
    this.rowGroupMetadata = {};
    if (this.tableRowData) {
      for (let i = 0; i < this.tableRowData.length; i++) {
        const rowData = this.tableRowData[i];
        const groupName = rowData.groupName;
        if (i === 0) {
          this.rowGroupMetadata[groupName] = { index: 0, size: 1 };
        } else {
          const previousRowData = this.tableRowData[i - 1];
          const previousRowGroup = previousRowData.groupName;
          if (groupName === previousRowGroup) {
            this.rowGroupMetadata[groupName].size++;
          } else {
            this.rowGroupMetadata[groupName] = { index: i, size: 1 };
          }
        }
      }
    }
  }
  download(productTypeId) {
    window.scrollTo(0, 0);
    setTimeout(() => {
      html2canvas.default(document.querySelector('#' + productTypeId)).then((canvas) => {
        this.canvas.nativeElement.src = canvas.toDataURL();
        const hrefData = canvas.toDataURL('image/png').replace('data:image/png;base64,', '');
        const blobData = this.convertBase64ToBlobData(hrefData);
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                  window.navigator.msSaveOrOpenBlob(blobData, 'Pie-chart');
        } else { // chrome
          const blob = new Blob([blobData], { type: 'image/png' });
          const url = window.URL.createObjectURL(blob);
          // window.open(url);
          const link = document.createElement('a');
          link.href = url;
          link.download = 'Pie-chart';
          link.click();
        }
      });
    }, 500);
  }

  convertBase64ToBlobData(base64Data: string, contentType: string = 'image/png', sliceSize = 512) {
    const byteCharacters = atob(base64Data);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      const slice = byteCharacters.slice(offset, offset + sliceSize);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    const blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }
  onClickNavigation(field, rowFetch) {
    // console.log(field, rowFetch);
    const jsonView3D = {portProductType: rowFetch.groupName,
                portProductValue: rowFetch.dataName, portStatus: field, searchType: this.siteName};
    this.services.siteView3D.next(jsonView3D);
    this.router.navigate(['/chassisView']);
  }
  ngOnDestroy() {
    this.services.detailedSite.next('');
    this.detailsiteservice$.unsubscribe();
  }

}
