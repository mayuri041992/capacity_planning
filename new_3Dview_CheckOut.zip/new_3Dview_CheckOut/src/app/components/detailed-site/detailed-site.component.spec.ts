// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { DetailedSiteComponent } from './detailed-site.component';
// import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
// import { RouterTestingModule } from '@angular/router/testing';
// import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
// import { ActivatedRoute } from '@angular/router';
// import html2canvas from 'html2canvas';
// import { of } from 'rxjs';
// import { AppService } from '../../core/services/app-service/app.service';
// import { ReplaySubject, BehaviorSubject, Observable } from 'rxjs';
// import { HttpClientModule } from '@angular/common/http';


// describe('DetailedSiteComponent', () => {
//   let component: DetailedSiteComponent;
//   tslint:disable-next-line:prefer-const
//   let service: AppService;
//   tslint:disable-next-line:prefer-const
//   let activatedRoute: ActivatedRoute;
//   let fixture: ComponentFixture<DetailedSiteComponent>;
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [FormsModule, RouterTestingModule, HttpClientModule, HttpClientTestingModule],
//       declarations: [DetailedSiteComponent, NgbTypeahead],
//       schemas: [
//         CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA
//       ],
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DetailedSiteComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     component.detailedSiteObj.searchType = 'SITE_NAME';
//     component.detailedSiteObj.serachData = 'London';
//     expect(component).toBeTruthy();
//   });

//   it('should ngOnInit', () => {
//     const data = {
//       site_Name: 'Ethernet'
//     };
//     const detailedSiteObj = {
//       searchType: '',
//       serachData: '',
//       productType: ''
//     };
//     TestBed.get(ActivatedRoute).queryParams = of({ site_Name: 'London' });
//     spyOn(fixture.debugElement.injector.get(ActivatedRoute), 'queryParams').and.returnValue(of({site_Name: 'London'}));
//     const appService = fixture.debugElement.injector.get(AppService);
//     spyOn(appService, 'detailedSiteChart$').and.returnValue(of([1, 2]));
//     component.ngOnInit();
//     expect(component.ngOnInit).toBeDefined();
//   });

//   it('should define updateRowGroupMetaData', () => {
//     component.tableRowData =
//       [
//         {
//           groupName: 'FE', ABC: 'L2 only', Total: 43,
//           InFlight: 11, Inuse: 14, Reserved: 7, Blocked: 4, Free: 5, fraultyUnavailble: 2
//         },
//         {
//           groupName: 'GE Ethernet', ABC: 'L2+L3+Timing',
//           Total: 43, InFlight: 11, Inuse: 14, Reserved: 7, Blocked: 4, Free: 5,
//           fraultyUnavailble: 2
//         },
//         {
//           groupName: 'GE Ethernet', ABC: 'L2+L3', Total: 43, InFlight: 11, Inuse: 14, Reserved: 7, Blocked: 4, Free: 5,
//           fraultyUnavailble: 2
//         }];
//     component.updateRowGroupMetaData();
//     expect(component.updateRowGroupMetaData).toBeDefined();
//   });

//   it('should define onSort', () => {
//     expect(component.onSort()).not.toBeNull();
//   });

//   it('should define change', () => {
//     const index = 1;
//     component.change(index);
//     expect(component.change).toBeDefined();
//   });
//   it('should define handleChange', () => {
//     const e = {
//       index: 1
//     };
//     component.handleChange(e);
//     expect(component.handleChange).toBeDefined();
//   });

//   it('should define download', () => {
//     const productTypeId = 'abc';
//     component.download(productTypeId);
//     expect(component.download).toBeTruthy();
//   });

//   it('should define changeProduct if case', () => {
//     const type = {
//       name: 'Overall',
//     };
//     component.productType = component.productTab();
//     component.changeProduct(type);
//     expect(component.changeProduct).toBeDefined();
//   });

//   it('should define changeProduct else case', () => {
//     const type = {
//       name: 'Overall1',
//     };
//     component.productType = component.productTab();
//     component.changeProduct(type);
//     expect(component.changeProduct).toBeDefined();

//   });

//   Provide proper data
//   it('should define selected ', () => {
//     const item = {
//       item: {
//         data: 'London forcast Hill',
//         type: 'L/FOR',
//         description: 'London'
//       }
//     };
//     component.selected(item);
//     expect(component.selected).toBeDefined();
//   });

//   it('should define onClear', () => {
//     const event = {
//       target: { value: '' }
//     };
//     component.onClear(event);
//     expect(component.onClear).toBeTruthy();
//   });

//   it('should define changePieChart', () => {
//     const value = 'ethernet';
//     component.testPieChart = '10G';
//     component.pieChartData  =  {
//       ethernet:  [
//         {
//           port:  '1G',
//           portValues:  [45,  25,  625],
//           totalPort:  695
//         },
//         {
//           port:  '10G',
//           portValues:  [45,  215,  65],
//           totalPort:  65
//         },
//         {
//           port:  '100G',
//           portValues:  [45,  325,  65],
//           totalPort:  65
//         }
//       ],
//       broadband:  [
//         {
//           port:  '1G',
//           portValues:  [45,  525,  65],
//           totalPort:  65
//         },
//         {
//           port:  '10G',
//           portValues:  [415,  255,  65],
//           totalPort:  654
//         }
//       ]
//     };
//     component.changePieChart(value);
//     expect(component.changePieChart).toBeDefined();
//   });

//   it('should define changePieCharts', () => {
//     const value = 'broadband';
//     component.testPieCharts = '1G';
//     component.pieChartData  =  {
//       ethernet:  [
//         {
//           port:  '1G',
//           portValues:  [45,  25,  625],
//           totalPort:  695
//         },
//         {
//           port:  '10G',
//           portValues:  [45,  215,  65],
//           totalPort:  65
//         },
//         {
//           port:  '100G',
//           portValues:  [45,  325,  65],
//           totalPort:  65
//         }
//       ],
//       broadband:  [
//         {
//           port:  '1G',
//           portValues:  [45,  525,  65],
//           totalPort:  65
//         },
//         {
//           port:  '10G',
//           portValues:  [415,  255,  65],
//           totalPort:  654
//         }
//       ]
//     };
//     component.changePieCharts(value);
//     expect(component.changePieCharts).toBeDefined();
//   });
// });
