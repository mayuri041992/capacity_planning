import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DashboardCapacityComponent } from './dashboard-capacity.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { AppService } from '../../core/services/app-service/app.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { of, Observable } from 'rxjs';


describe('DashboardCapacityComponent', () => {
  let component: DashboardCapacityComponent;
  let fixture: ComponentFixture<DashboardCapacityComponent>;
  let services: AppService;
  const mockData = { dataPointsNetworkCapacityTrendForQuarter:
  ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
    label: 'NETWORK_CAPACITY_TREND',
    quarterlyDataNetworkCapacityTrend: [{ productType: 'Backhaul', tbps: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    { productType: 'Broadband', tbps: [179, 176, 178, 183, 183, 183, 184, 188, 189, 188] },
    { productType: 'Ethernet', tbps: [865, 854, 868, 885, 876, 876, 873, 885, 863, 866] },
    { productType: 'Infrastructure', tbps: [0, 0, 0, 0, 0, 0, 0, 0, 0, 24] },
    { productType: 'P2PE', tbps: [0, 0, 0, 0, 0, 0, 0, 0, 0, 16] },
    { productType: 'Total Capacity', tbps: [380, 386, 386, 376, 376, 376, 375, 384, 369, 304] }]
  };
  const keyMockData = [{
    // tslint:disable-next-line:object-literal-key-quotes
    'typeName': 'Backhaul', 'dataPointsProductCapacityTrendForQuarter':
    ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
    // tslint:disable-next-line:object-literal-key-quotes
    'quarterlyDataProductCapacityTrend': [{ 'portSpeed': '10G', 'totalPorts': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    // tslint:disable-next-line:object-literal-key-quotes
    { 'portSpeed': '1G', 'totalPorts': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }]
  }, {
    // tslint:disable-next-line:object-literal-key-quotes
    'typeName': 'Broadband', 'dataPointsProductCapacityTrendForQuarter':
    ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
     // tslint:disable-next-line:object-literal-key-quotes
     'quarterlyDataProductCapacityTrend': [{ 'portSpeed': '10G',
     // tslint:disable-next-line:object-literal-key-quotes
     'totalPorts': [13917, 13779, 14675, 15242, 15213, 15213, 15313, 15772, 15864, 15725] },
    // tslint:disable-next-line:object-literal-key-quotes
    { 'portSpeed': '1G', 'totalPorts': [40792, 38871, 31440, 31264, 31134, 31134, 31059, 30866, 30328, 31134] }]},
    // tslint:disable-next-line:object-literal-key-quotes
    { 'typeName': 'Ethernet',
  // tslint:disable-next-line:object-literal-key-quotes
  'dataPointsProductCapacityTrendForQuarter':
   ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
  // tslint:disable-next-line:object-literal-key-quotes
  'quarterlyDataProductCapacityTrend':
   // tslint:disable-next-line:object-literal-key-quotes
   [{ 'portSpeed': '10G', 'totalPorts': [64188, 62885, 63931, 65097, 64272, 64272, 64120, 64801, 62826, 62231] },
   // tslint:disable-next-line:object-literal-key-quotes
   { 'portSpeed': '1G', 'totalPorts': [152430, 156055, 159765, 159882, 159548, 159548, 159021, 158482, 154800, 159618] }] },
    // tslint:disable-next-line:object-literal-key-quotes
    { 'typeName': 'Infrastructure', 'dataPointsProductCapacityTrendForQuarter':
    ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
    // tslint:disable-next-line:object-literal-key-quotes
    'quarterlyDataProductCapacityTrend': [{ 'portSpeed': '10G', 'totalPorts': [0, 0, 0, 0, 0, 0, 0, 0, 0, 2483] },
     // tslint:disable-next-line:object-literal-key-quotes
     { 'portSpeed': '1G', 'totalPorts': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }] },
  // tslint:disable-next-line:object-literal-key-quotes
  { 'typeName': 'P2PE', 'dataPointsProductCapacityTrendForQuarter':
   ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
    // tslint:disable-next-line:object-literal-key-quotes
    'quarterlyDataProductCapacityTrend': [{ 'portSpeed': '10G', 'totalPorts': [0, 0, 0, 0, 0, 0, 0, 0, 0, 1648] },
    // tslint:disable-next-line:object-literal-key-quotes
    { 'portSpeed': '1G', 'totalPorts': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }] }, {
    // tslint:disable-next-line:object-literal-key-quotes
    'typeName': 'Total Capacity', 'dataPointsProductCapacityTrendForQuarter':
     ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
     // tslint:disable-next-line:object-literal-key-quotes
     'quarterlyDataProductCapacityTrend':
      // tslint:disable-next-line:object-literal-key-quotes
      [{ 'portSpeed': '10G', 'totalPorts': [25810, 24571, 24601, 23502, 23487, 23487, 23615, 23822, 22430, 15006] },
    // tslint:disable-next-line:object-literal-key-quotes
    { 'portSpeed': '1G', 'totalPorts': [50724, 68006, 67065, 66816, 66816, 66816, 66473, 66539, 64444, 70526] }]
  }];
  const donutMock = {productTypes: ['Ethernet', 'Broadband', 'Backhaul', 'Infrastructure', 'P2PE'],
  tbpsValues: [880, 188, 0, 25, 16], totalTbps: 1109};
  const productMock = [{ typeName: 'Backhaul',
  dataPointsProductCapacityTrendForQuarter:
   ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
   quarterlyDataProductCapacityTrend: [{ portSpeed: '10G', totalPorts: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
   { portSpeed: '1G', totalPorts: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }] }, { typeName: 'Broadband', dataPointsProductCapacityTrendForQuarter:
    ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
    quarterlyDataProductCapacityTrend: [{ portSpeed: '10G',
    totalPorts: [13917, 13779, 14675, 15242, 15213, 15213, 15313, 15772, 15864, 15725] },
    { portSpeed: '1G', totalPorts: [40792, 38871, 31440, 31264, 31134, 31134, 31059, 30866, 30328, 31134] }] },
    { typeName: 'Ethernet', dataPointsProductCapacityTrendForQuarter:
    ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'],
     // tslint:disable-next-line:max-line-length
     quarterlyDataProductCapacityTrend: [{ portSpeed: '10G', totalPorts: [64188, 62885, 63931, 65097, 64272, 64272, 64120, 64801, 62826, 62231] },
      { portSpeed: '1G', totalPorts: [152430, 156055, 159765, 159882, 159548, 159548, 159021, 158482, 154800, 159618] }] },
       // tslint:disable-next-line:max-line-length
       { typeName: 'Infrastructure', dataPointsProductCapacityTrendForQuarter: ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'], quarterlyDataProductCapacityTrend: [{ portSpeed: '10G', totalPorts: [0, 0, 0, 0, 0, 0, 0, 0, 0, 2483] }, { portSpeed: '1G', totalPorts: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }] }, { typeName: 'P2PE', dataPointsProductCapacityTrendForQuarter: ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'], quarterlyDataProductCapacityTrend: [{ portSpeed: '10G', totalPorts: [0, 0, 0, 0, 0, 0, 0, 0, 0, 1648] }, { portSpeed: '1G', totalPorts: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }] }, {
    // tslint:disable-next-line:max-line-length
    typeName: 'Total Capacity', dataPointsProductCapacityTrendForQuarter: ['W31,2019', 'W32,2019', 'W33,2019', 'W34,2019', 'W35,2019', 'W36,2019', 'W37,2019', 'W38,2019', 'W39,2019', 'W40,2019'], quarterlyDataProductCapacityTrend: [{ portSpeed: '10G', totalPorts: [25810, 24571, 24601, 23502, 23487, 23487, 23615, 23822, 22430, 15006] },
    { portSpeed: '1G', totalPorts: [50724, 68006, 67065, 66816, 66816, 66816, 66473, 66539, 64444, 70526] },
    { portSpeed: '100G', totalPorts: [50724, 67001, 67065, 60816, 66816, 66816, 66473, 66539, 64444, 71526] },
    { portSpeed: 'FE', totalPorts: [50724, 68006, 67065, 66816, 66816, 66816, 66473, 66539, 64444, 70526] },
    { portSpeed: 'Ethernet Planned', totalPorts: [50724, 68006, 67065, 66816, 66816, 66816, 66473, 66539, 64444, 70526] },
    { portSpeed: 'Ethernet Built', totalPorts: [50724, 68006, 67065, 66816, 66816, 66816, 66473, 66539, 64444, 70526] },
    { portSpeed: 'Broadband Planned', totalPorts: [50724, 68006, 67065, 66816, 66816, 66816, 66473, 66539, 64444, 70526] },
    { portSpeed: 'Broadband Built', totalPorts: [50724, 68006, 67065, 66816, 66816, 66816, 66473, 66539, 64444, 70526] },
  ]
  }];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardCapacityComponent ],
      providers : [RouterTestingModule , HttpClient , HttpHandler],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA,  NO_ERRORS_SCHEMA
      ],
    }).overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [DashboardCapacityComponent] } })
    .compileComponents();
    services = TestBed.get(AppService);
    spyOn(services, 'getLineCapacityReport').and.returnValue(of(JSON.parse(JSON.stringify(mockData))));
    spyOn(services, 'getKeynetwork').and.returnValue(of(JSON.parse(JSON.stringify(keyMockData))));
    spyOn(services, 'getDonutLineChartData').and.returnValue(of(JSON.parse(JSON.stringify(donutMock))));
    spyOn(services, 'getProductLineCapacity').and.returnValue(of(JSON.parse(JSON.stringify(productMock))));
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardCapacityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    component.keyNetwork = [];
    expect(services.getLineCapacityReport).toHaveBeenCalled();
    expect(services.getKeynetwork).toHaveBeenCalled();
    expect(services.getDonutLineChartData).toHaveBeenCalled();
    expect(services.getProductLineCapacity).toHaveBeenCalled();
  });
  it('should define background color BackhaulColor', () => {
    const value = {
      label: 'Backhaul',
      borderColor : ''
    };
    component.backGroundColor(value);
    expect(component.backGroundColor).toBeDefined();
  });
  it('should define background color BroadbandColor', () => {
    const value = {
      label: 'Broadband',
      borderColor : ''
    };
    component.backGroundColor(value);
    expect(component.backGroundColor).toBeDefined();
  });
  it('should define background color EthernetColor', () => {
    const value = {
      label: 'Ethernet',
      borderColor : ''
    };
    component.backGroundColor(value);
    expect(component.backGroundColor).toBeDefined();
  });
  // it('should define background color InfrastructureColor', () => {
  //   const value = {
  //     label: 'Infrastructure',
  //     borderColor : ''
  //   };
  //   component.backGroundColor(value);
  //   expect(component.backGroundColor).toBeDefined();
  // });
  // it('should define background color P2PEColor', () => {
  //   const value = {
  //     label: 'P2PE',
  //     borderColor : ''
  //   };
  //   component.backGroundColor(value);
  //   expect(component.backGroundColor).toBeDefined();
  // });
  // it('should define background color Total Capacity', () => {
  //   const value = {
  //     label: 'Total Capacity',
  //     borderColor : ''
  //   };
  //   component.backGroundColor(value);
  //   expect(component.backGroundColor).toBeDefined();
  // });
});
