import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AppService } from '../../core/services/app-service/app.service';

@Component({
  selector: 'app-dashboard-capacity',
  templateUrl: './dashboard-capacity.component.html',
  styleUrls: ['./dashboard-capacity.component.scss']
})
export class DashboardCapacityComponent implements OnInit {
  @ViewChild('mainScreen') elementView: ElementRef;
  viewHeight;
  viewWidth;
  public data1 = {responsive: false,
        maintainAspectRatio: false };
  public data;
  keyNetwork = [];
  trendArray = [];
  donutChartResponse;
  constructor(private service: AppService) {
    this.service.getLineCapacityReport().subscribe((combinaJSON) => {
      // console.log(combinaJSON);
      if (combinaJSON) {
        this.data = { ...this.data1, trendName: combinaJSON.label,
        labels: combinaJSON.dataPointsNetworkCapacityTrendForQuarter, datasets: [] };
        combinaJSON.quarterlyDataNetworkCapacityTrend.forEach((set) => {
          const objectData = {};
          const value = { ...objectData,
            label: set.productType,
            data: set.tbps,
            fill: false,
            borderColor: '' };
          this.backGroundColor(value);
          this.data.datasets.push(value);
        });
      }
    });
    this.service.getKeynetwork().subscribe((keyJSON) => {
      if (keyJSON) {
        keyJSON.forEach((key) => {
          const keyNet = {
            ...{},
            label: key.productType,
            borderColor: '',
            totalPorts: key.totalPorts,
            freePorts: key.freePorts
          };
          this.backGroundColor(keyNet);
          this.keyNetwork.push(keyNet);
        });
      }
      this.viewWidth =  this.elementView.nativeElement.offsetWidth;
      this.viewWidth = this.viewWidth - 40;
      this.viewWidth = Math.floor(this.viewWidth / (this.keyNetwork.length));
      this.viewWidth = this.viewWidth - 10 + 'px';
    });
    this.service.getDonutLineChartData().subscribe((donutJSON) => {
      if (donutJSON) {
        // console.log(donutJSON);
        this.donutChartResponse = donutJSON;
        setTimeout(() => {
          this.viewHeight = this.elementView.nativeElement.offsetHeight + 'px';
        }, 1000);
      }
    });
    this.service.getProductLineCapacity().subscribe((productJSON) => {
       if (productJSON) {
         productJSON.forEach((lineData) => {
          const trend = { ...{}, trendName: lineData.typeName, labels: lineData.dataPointsProductCapacityTrendForQuarter,
                         datasets: [] };
          lineData.quarterlyDataProductCapacityTrend.forEach((trendData) => {
             const dataset = { ...{},
             label: trendData.portSpeed,
             data: trendData.totalPorts,
             fill: false,
             borderColor: '' };
             dataset.borderColor = '#6D00A7';
             const G1Color = new RegExp('1G', 'gi');
             const G10Color = new RegExp('10G', 'gi');
             const G100Color = new RegExp('100G', 'gi');
             const FEColor = new RegExp('FE', 'gi');
             const ethernetPlanned = new RegExp('Ethernet Planned', 'gi');
             const ethernetBuilt = new RegExp('Ethernet Built', 'gi');
             const broadbandPlanned = new RegExp('Broadband Planned', 'gi');
             const broadbandBuilt = new RegExp('Broadband Built', 'gi');
             if (dataset.label.match(G1Color) && dataset.label.match(G1Color).length > 0) {
               dataset.borderColor = '#bfb2ff';
             } else if (dataset.label.match(G10Color) && dataset.label.match(G10Color).length > 0) {
               dataset.borderColor = '#7f69eb';
             } else if (dataset.label.match(G100Color) && dataset.label.match(G100Color).length > 0) {
               dataset.borderColor = '#f8bf5d';
             } else if (dataset.label.match(FEColor) && dataset.label.match(FEColor).length > 0) {
               dataset.borderColor = '#fc6b89';
             } else if (dataset.label.match(ethernetPlanned) && dataset.label.match(ethernetPlanned).length > 0) {
              dataset.borderColor = '#f3a65a';
            } else if (dataset.label.match(ethernetBuilt) && dataset.label.match(ethernetBuilt).length > 0) {
              dataset.borderColor = '#da9c5e';
            } else if (dataset.label.match(broadbandPlanned) && dataset.label.match(broadbandPlanned).length > 0) {
              dataset.borderColor = '#c584f2';
            } else if (dataset.label.match(broadbandBuilt) && dataset.label.match(broadbandBuilt).length > 0) {
              dataset.borderColor = '#7e2cb8';
            }
             trend.datasets.push(dataset);
          });
          this.trendArray.push(trend);
         });
       }
    });

  }
  ngOnInit() {
  }
  backGroundColor(value) {
    value.borderColor = '#6D00A7';
    const BackhaulColor = new RegExp('Backhaul', 'gi');
    const BroadbandColor = new RegExp('Broadband', 'gi');
    const EthernetColor = new RegExp('Ethernet', 'gi');
    const InfrastructureColor = new RegExp('Infrastructure', 'gi');
    const P2PEColor = new RegExp('P2PE', 'gi');
    const TotalCapacityColor = new RegExp('Total Capacity', 'gi');
    if (value.label.match(BackhaulColor) && value.label.match(BackhaulColor).length > 0) {
      value.borderColor = '#0991ce';
    } else if (value.label.match(BroadbandColor) && value.label.match(BroadbandColor).length > 0) {
      value.borderColor = '#6400aa';
    } else if (value.label.match(EthernetColor) && value.label.match(EthernetColor).length > 0) {
      value.borderColor = '#FC8C1D';
    } else if (value.label.match(InfrastructureColor) && value.label.match(InfrastructureColor).length > 0) {
      value.borderColor = '#c1c1c1';
    } else if (value.label.match(P2PEColor) && value.label.match(P2PEColor).length > 0) {
      value.borderColor = '#e60050';
    } else if (value.label.match(TotalCapacityColor) && value.label.match(TotalCapacityColor).length > 0) {
      value.borderColor = '#6c6c6c';
    }
  }

}
