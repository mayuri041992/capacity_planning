import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivate } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { AppService } from '../services/app-service/app.service';
import { LoginService } from '../services/login-service/login.service';

@Injectable()

export class AccessGurad implements CanActivate {
    constructor(private router: Router, private loginService: LoginService) { }
    canActivate(next: ActivatedRouteSnapshot,
                state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        if ((this.loginService.userProfileRole.indexOf('ADMIN') !== -1 || this.loginService.userProfileRole.indexOf('VIEWER') !== -1)
            && (next.routeConfig.path === 'dashboard')) {
            return true;
            // tslint:disable-next-line:align
        } else if ((this.loginService.userProfileRole.indexOf('DESIGNER') !== -1) && (next.routeConfig.path === 'forecast')) {
            return true;
        } else {
            return false;
        }
    }
}
