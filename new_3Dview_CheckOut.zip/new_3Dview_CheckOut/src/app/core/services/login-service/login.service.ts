import { Injectable } from '@angular/core';
@Injectable()
export class LoginService {
  // tslint:disable-next-line:variable-name
  private _ein;
  // tslint:disable-next-line:variable-name
  private _groupName;
  public userProfileRole;
  set EIN(ein) {
    this._ein = window.localStorage.setItem('ein', ein);
  }
  get EIN(): string {
    return window.localStorage.getItem('ein');
  }
  set GroupName(groupName) {
    this._groupName = window.localStorage.setItem('groupName', groupName);
  }
  get GroupName() {
    return window.localStorage.getItem('groupName');
  }
  get UserProfile(): string {
    return window.localStorage.getItem('userProfile');
  }
  set UserProfile(userProfile) {
    this.userProfileRole = window.localStorage.setItem('userProfile', userProfile);
  }
}
