import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { LoginService } from './login.service';
import { AppService } from '../app-service/app.service';
import { EINPROGRESS } from 'constants';

describe('LoginService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
    ],
    providers: [AppService, LoginService]

  }));

  it('should be created', () => {
    const service: LoginService = TestBed.get(LoginService);
    expect(service).toBeTruthy();
  });

  it('should check get EIN', () => {
    const service: LoginService = TestBed.get(LoginService);
    expect(service.EIN).toBeDefined();
  });
  it('should check get EIN', () => {
    const service: LoginService = TestBed.get(LoginService);
    service.EIN = '';
    expect(service.EIN).toBeDefined();
  });

  it('should check get GroupName', () => {
    const service: LoginService = TestBed.get(LoginService);
    expect(service.GroupName).toBeDefined();
  });
  it('should check get GroupName', () => {
    const service: LoginService = TestBed.get(LoginService);
    service.GroupName = 'PRE_PROD_CE_ADMIN^PRE_PROD_CE_DESIGNER';
    expect(service.GroupName).toBeDefined();
  });
  it('should check  get UserProfile', () => {
    const service: LoginService = TestBed.get(LoginService);
    expect(service.UserProfile).toBeDefined();
  });
  it('should check  set UserProfile', () => {
    const service: LoginService = TestBed.get(LoginService);
    service.UserProfile = 'Aafg';
    expect(service.UserProfile).toBeDefined();
  });
});

