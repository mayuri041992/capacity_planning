import { Injectable } from '@angular/core';
import { Tab } from '../../../shared/models/forecast.model';
import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { filter, map, tap, delay, switchMap } from 'rxjs/operators';
@Injectable()
export class ForecastLineService {
  constructor() { }
  private tabs: BehaviorSubject<Tab[]> = new BehaviorSubject<Tab[]>([
    { name: 'upload_forecast', active: true },
    { name: 'manage_forecast', active: false },
  ]);
  public showHide =  new Subject();
  private tableAccountData = new BehaviorSubject<{ 'status': string, 'data': object[] }>(null);
  tableAccountData$ = this.tableAccountData.asObservable().pipe(filter(data => data ? true : false));

  private tableManageData = new BehaviorSubject<object[]>(null);
  tableManageData$ = this.tableManageData.asObservable().pipe(filter(data => data ? true : false));

  private sendUpdatedData: BehaviorSubject<object> = new BehaviorSubject<object>(null);
  public sendUpdatedData$ = this.sendUpdatedData.asObservable();

  private seachText: BehaviorSubject<any> = new BehaviorSubject('');
  public seachText$ = this.seachText.asObservable();

  public cancelEvent: BehaviorSubject<any> = new BehaviorSubject(null);
  public cancelEvent$ = this.cancelEvent.asObservable().pipe(switchMap(() => of(this.seachText.value)));

  // tslint:disable-next-line:variable-name
  public _success = new Subject<string>();
  // tslint:disable-next-line:variable-name
  public _danger = new Subject<string>();

  tabs$ = this.tabs.asObservable();
  getActiveTab(): Observable<Tab[]> {
    return this.tabs$.pipe(
      map((data) => data.filter((tabs: Tab) => tabs.active))
    );
  }
  setActiveTab(tabName): Observable<any> {
    const activeTab = this.tabs.value.map((tabs) => {
      tabs.name === tabName ? tabs.active = true : tabs.active = false;
      return tabs;
    });
    this.tabs.next(activeTab);
    return this.tabs$;
  }
  settableData(tableData) {
    this.tableAccountData.next(tableData);
    //  return of(1).pipe( tap( () => { console.log('inv')}), delay(1000))
  }
  setManageData(tableData: object[]) {
    this.tableManageData.next(tableData);
  }

  setUpadtedData(data) {
    this.sendUpdatedData.next(data);
  }

  setSearchText(searchText) {
    this.seachText.next(searchText);
  }
}
