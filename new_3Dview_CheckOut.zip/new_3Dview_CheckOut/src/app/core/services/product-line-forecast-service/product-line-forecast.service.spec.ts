import { TestBed } from '@angular/core/testing';
import { ForecastLineService } from './product-line-forecast.service';
import { Injectable, COMPILER_OPTIONS } from '@angular/core';
import { Observable, BehaviorSubject, Subject, observable, throwError, of, combineLatest } from 'rxjs';

describe('ProductLineService', () => {
  beforeEach(() => TestBed.configureTestingModule({

    providers: [ForecastLineService]
  }));

  it('should be created', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    expect(service).toBeTruthy();
  });

  it('settableData to be defined', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    // tslint:disable-next-line:prefer-const
    let tableData;
    service.settableData(tableData);
    expect(service.settableData).toBeDefined();
  });


  it('setUpadtedData to be defined', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    // tslint:disable-next-line:prefer-const
    let tableData;
    service.setUpadtedData(tableData);
    expect(service.setUpadtedData).toBeDefined();
  });
  it('setManageData to be defined', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    // tslint:disable-next-line:prefer-const
    let tableData: object[];
    service.setManageData(tableData);
    expect(service.setManageData).toBeDefined();
  });
  it('setSearchText to be defined', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    // tslint:disable-next-line:prefer-const
    let searchText = 'abcc';
    service.setSearchText(searchText);
    expect(service.setSearchText).toBeDefined();
  });
  it('setActiveTab should return value from observable', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    // tslint:disable-next-line:prefer-const
    let tabName = 'abc';
    service.setActiveTab(tabName).subscribe(value => {
      expect(value).not.toBeNull();
    });
  });
  it('setActiveTab should return value from observable', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    // tslint:disable-next-line:prefer-const
    let tabName = '';
    service.setActiveTab(tabName).subscribe(value => {
      expect(value).not.toBeNull();
    });
    expect(service.setActiveTab).toBeDefined();
  });
  it('getActiveTab should return value from observable', () => {
    const service: ForecastLineService = TestBed.get(ForecastLineService);
    service.getActiveTab().subscribe(value => {
      expect(value).not.toBeNull();
    });
  });

});

