import { Injectable, COMPILER_OPTIONS } from '@angular/core';
import { Observable, BehaviorSubject, Subject, observable, throwError, of, combineLatest, empty} from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { tap, switchMap, retry, catchError, filter, map, delay } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { filterObject } from '../../../shared/models/filterObject.model';
import { pageObject } from '../../../shared/models/pageObject.model';
import { DetailedSiteObject } from '../../../shared/models/detailedSiteObject.model';
@Injectable({
  providedIn: 'root'
})
export class AppService {
  addSavePreferenceSubject = new Subject();
  loading = new Subject<boolean>();
  Rowdata = new Subject();
  showdata = new Subject<boolean>();
  selectedFilter = new Subject<boolean>();
  showFilter = new Subject<boolean>();
  downLoadPieChart = new Subject<object>();
  initPageObject = new BehaviorSubject<pageObject>(null);
  initPageObject$ = this.initPageObject.asObservable().pipe(filter(data => data ? true : false));
  capacityData = new BehaviorSubject<object[]>([]);
  capacityData$ = this.capacityData.asObservable();
  initFilterObject = new BehaviorSubject<filterObject>(null);
  initFilterObject$ = this.initFilterObject.asObservable().pipe(filter(data => data ? true : false));
  gridData = new BehaviorSubject<any[]>([]);
  gridData$ = this.gridData.asObservable();
  detailedSite = new BehaviorSubject<any>(null);
  detailedSite$ = this.detailedSite.asObservable().pipe(filter(data => data ? true : false));
  detailedSiteChart = new BehaviorSubject<any>([]);
  detailedSiteChart$ = this.detailedSite.asObservable();
  diversityReport =  new BehaviorSubject<any>(null);
  diversityReport$ = this.diversityReport.asObservable().pipe(filter(data => data ? true : false));
  view3D = new BehaviorSubject(null);
  view3D$ = this.view3D.asObservable().pipe(filter(data => data ? true : false));
  siteView3D = new BehaviorSubject(null);
  siteView3D$ = this.siteView3D.asObservable().pipe(filter(data => data ? true : false));
  callExchangeInfo = new Subject<boolean>();

  constructor(private httpClient: HttpClient) {
    // Apolo 5G Diversity report Api services
    this.diversityReport$ = this.diversityReport$.pipe(
      filter((data) => data),
      switchMap((diversityObj) => {
        const body = { ...diversityObj };
        let param = new HttpParams().set('noofport', body.port);
        param = param.append('diversitygroup', body.groupName);
        param = param.append('searchType', body.code.type);
        param = param.append('searchData', body.code.data);
        return this.httpClient.get(environment.api +
          'diversity-group-forecast-management/diversity-group-forecast/', { params: param });
       // tslint:disable-next-line:max-line-length
      //  return of ({"diversityGroupForecastList":[{"sneId":"20744972","cardDetail":"1 x 10GB MDA","freePortDetail":"20744972:/shelf=1/slot=7/sub_slot=1/subsub_slot=5/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20787117","cardDetail":"Dummy IMM Module","freePortDetail":"20787117:/shelf=1/slot=3/sub_slot=2/subsub_slot=4/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20787117","cardDetail":"Dummy IMM Module","freePortDetail":"20787117:/shelf=1/slot=3/sub_slot=2/subsub_slot=3/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20787117","cardDetail":"Dummy IMM Module","freePortDetail":"20787117:/shelf=1/slot=3/sub_slot=2/subsub_slot=5/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20749633","cardDetail":"Dummy IMM Module","freePortDetail":"20749633:/shelf=1/slot=5/sub_slot=1/subsub_slot=5/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20749633","cardDetail":"Dummy IMM Module","freePortDetail":"20749633:/shelf=1/slot=1/sub_slot=2/subsub_slot=6/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"}, {"sneId":"20781756","cardDetail":"Dummy IMM Module","freePortDetail":"20781756:/shelf=1/slot=1/sub_slot=2/subsub_slot=7/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage1-cardtod=Y-cardstatus=Installed-porttod=Capable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20781756","cardDetail":"Dummy IMM Module","freePortDetail":"20781756:/shelf=1/slot=1/sub_slot=2/subsub_slot=9/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage1-cardtod=Y-cardstatus=Installed-porttod=Capable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20781756","cardDetail":"Dummy IMM Module","freePortDetail":"20781756:/shelf=1/slot=1/sub_slot=2/subsub_slot=8/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage1-cardtod=Y-cardstatus=Installed-porttod=Capable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20781756","cardDetail":"Dummy IMM Module","freePortDetail":"20781756:/shelf=1/slot=1/sub_slot=2/subsub_slot=10/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage1-cardtod=Y-cardstatus=Installed-porttod=Capable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20744972","cardDetail":"1 x 10GB MDA","freePortDetail":"20744972:/shelf=1/slot=7/sub_slot=1/subsub_slot=5/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20787117","cardDetail":"Dummy IMM Module","freePortDetail":"20787117:/shelf=1/slot=3/sub_slot=2/subsub_slot=4/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20787117","cardDetail":"Dummy IMM Module","freePortDetail":"20787117:/shelf=1/slot=3/sub_slot=2/subsub_slot=3/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20787117","cardDetail":"Dummy IMM Module","freePortDetail":"20787117:/shelf=1/slot=3/sub_slot=2/subsub_slot=5/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20749633","cardDetail":"Dummy IMM Module","freePortDetail":"20749633:/shelf=1/slot=5/sub_slot=1/subsub_slot=5/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"},{"sneId":"20749633","cardDetail":"Dummy IMM Module","freePortDetail":"20749633:/shelf=1/slot=1/sub_slot=2/subsub_slot=6/port=1","cardStatus":"Installed","scenario":"Scenario-3-Stage2-cardtod=N-cardstatus=Installed-porttod=Incapable-portCUF=Ethernet Access-DG=BTRAN-LON-02"}],"portAvailablity":""});
      })
    );

    // detail site service for constructor
    this.detailedSiteChart$ = this.detailedSite$.pipe(
      filter((data) => data),
      switchMap((dataJson) => {
        const body = { ...dataJson };
        if (body.productType !== '') {
          return combineLatest( this.httpClient.get(environment.api + 'detail-site-report/history-trends-bar' +
          '/' +  body.productType + '/' + body.searchType + '/searchData?searchData=' + body.serachData  )
          .pipe( catchError( () => of(null)) ) );

        } else {
           return combineLatest( (this.httpClient.get(environment.api + 'detail-site-report/history-trends' +
          '/' + body.searchType + '/searchData?searchData=' + body.serachData  )
          .pipe( catchError( () => of(null)) ) ),
          (this.httpClient.get(environment.api + 'detail-site-report/port-details' +
          '/' + body.searchType + '/searchData?searchData=' + body.serachData  ))
          .pipe( catchError( () => of(null)) ));
        }
      })
    );

    // this.gridData$ = combineLatest(this.initPageObject$, this.initFilterObject$).pipe(
    //   switchMap((reffr) => {
    //     const [pageObj, filterObj] = [...reffr];
    //     // tslint:disable-next-line:no-string-literal
    //     const concatObjs = { ...filterObj['exchangeInfoFilterRequest'], ...pageObj };
    //     // tslint:disable-next-line:no-string-literal
    //     const exportData = { ...concatObjs['exchangeInfoFilterRequest'] };
    //     return this.getfilterdata(concatObjs);
    //   })
    // );
    this.gridData$  =  combineLatest(this.initPageObject$,  this.initFilterObject$,  this.callExchangeInfo ).pipe(
      filter(([p,  f,  call])  =>  call ),
      switchMap((reffr)  =>  {
        const  [pageObj,  filterObj]  =  reffr;
        // tslint:disable-next-line:no-string-literal
        const  concatObjs  =  {  ...filterObj['exchangeInfoFilterRequest'],  ...pageObj  };
        // tslint:disable-next-line:no-string-literal
        const  exportData  =  {  ...concatObjs['exchangeInfoFilterRequest'] };
        return  this.getfilterdata(concatObjs);
      })
    );
  }
  getserachData(): Observable<any> {
    return this.httpClient.get(environment.api + 'site-management/site-exchange');
  }
  search(term: string) {
    if (term === '') {
      return of([]);
    } else if (term.length === 2 || term.length > 2) {
      return this.getserachData().pipe(
        map((searchResultArray) => {
          return searchResultArray.filter((searchResultData) => {
            const searchRegex = new RegExp(term, 'gi');
            const regResult = searchResultData.match(searchRegex);
            return (regResult && regResult.length > 0);
          });
        })
      );
    } else {
      return of([]);
    }
  }
  getDetailedSiteSearch(term: string) {
    if (term === '') {
      return of([]);
    } else if (term.length === 2 || term.length > 2) {
      const params = { params: new HttpParams().set('searchData', term) };
      // return of([{"type":"SITE_NAME","data":"LONDON FOREST HILL"}]);
      return this.httpClient.get(environment.api + 'site-management/search-data', params);
    } else {
      return of([]);
    }
  }
  getGridDataToExport(): Observable<any> {
    const checkFilter$ = this.initFilterObject.pipe(
      switchMap((filters) => {
        if (filters) {
          return of(filters);
        } else {
          return of({ exchangeInfoFilterRequest: {} });
        }
      })
    );
    const checkPage$ = this.initPageObject$.pipe(
      switchMap((page) => {
        if (page) {
          return of(page);
        } else {
          return of({});
        }
      })
    );
    return combineLatest(checkFilter$, checkPage$).pipe(
      switchMap((combinedData) => {
        const [filters, page] = combinedData;
        const requestBody = { ...filters.exchangeInfoFilterRequest, ...page, enableSorting: false };
        return this.httpClient.post(environment.api + 'site-management/exchange-info',
          JSON.stringify(requestBody), { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } }).
          pipe(tap(d => {
          }));
      })
    );
  }
  getfilterdata( body: object = {}): Observable<any> {
    return this.httpClient.post(environment.api + 'site-management/exchange-info', JSON.stringify(body),
      { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
      .pipe(
        catchError(this.handleError)
      );
  }
  getFilterInfo(): Observable<any> {
    return this.httpClient.get(environment.api + 'filter-management/filter-info');
  }
  // getLogout(): Observable<any> {
  //   // const logoutUrl = environment.api.split('/api-v1');
  //   return this.httpClient.get( environment.api + 'srimsCapacityPlanning/logout');
  // }
  getFilterMasterInfo(body: object = {}): Observable<any> {
    return this.httpClient.post(environment.api + 'filter-management/cascaded-filter-master', JSON.stringify(body),
      { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
      .pipe(
        catchError(this.handleError)
      );
  }
  getSaveUserPre(body: object = {}): Observable<any> {
    return this.httpClient.post(environment.api + 'preference-management/save-preference', JSON.stringify(body),
      { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
      .pipe(
        catchError(this.handleError)
      );
  }
  getSavedpref(body: number) {
    return this.httpClient.post(environment.api + 'preference-management/preference', JSON.stringify(body),
      { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
      .pipe(
        catchError(this.handleError)
      );
  }
  handleError(error) {
    let errorMessage = 'service unavailable';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    // window.alert(errorMessage);
    return throwError(errorMessage);
  }

  postExcelFile( body: object = []): Observable<any> {
    // console.log(JSON.stringify(body));
    return this.httpClient.post(environment.api + 'forecast-management/upload-forecast-info', JSON.stringify(body),
      { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
      .pipe(
        catchError(this.handleError)
      );
  }
  searchDetails(search: string) {
    const params = search ?  new HttpParams().set('searchData', search)  : new HttpParams().set('searchData', '') ;
    const headers = {'Cache-Control': 'no-cache', Pragma: 'no-cache'};
    // tslint:disable-next-line:max-line-length
    // return of([{ "id": "1", "forcastCode": "321", "siteName": "shngalore", "fastEforecast": "1", "gigEforecast": "2", "hE10Gforecast": "3", "bB10Gforecast": "4" }, { "id": "2", "forcastCode": "sahoo", "siteName": "sarnataka", "fastEforecast": "1", "gigEforecast": "2", "hE10Gforecast": "3", "bB10Gforecast": "4" }, { "id": "4", "forcastCode": "765", "siteName": "shngalore", "fastEforecast": "1", "gigEforecast": "2", "hE10Gforecast": "3", "bB10Gforecast": "4" }, { "id": "3", "forcastCode": "987", "siteName": "sarnataka", "fastEforecast": "1", "gigEforecast": "2", "hE10Gforecast": "3", "bB10Gforecast": "4" }])
    return this.httpClient.get(environment.api + 'forecast-management/forecast-info', { params, headers });
  }
  DownloadXLSX() {
    window.open(environment.api + 'forecast-management/download-forecast-info', '_self');
    // return this.httpClient.get(environment.api + "forecast-management/download-forecast-info");
  }

  deleteGridItem(id): Observable<any> {
    const params = id ? { params: new HttpParams().set('id', id) } : { params: new HttpParams().set('id', null) };
    return this.httpClient.delete(environment.api + 'forecast-management/delete-forecast-info?id=' + id).pipe();
  }

  updateData( body: object = []): Observable<any> {
    return this.httpClient.post(environment.api + 'forecast-management/update-forecast-info', JSON.stringify(body),
      { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
      .pipe(
        catchError(this.handleError)
      );
  }
  logInPage() {
    const  url  =  environment.api.split(':');
    // return  ( url[0]  +  ':'  +  url[1]  + ':/srimsCapacityPlanning');
    return  ( url[0]  +  ':'  +  url[1]  + ':8081/srimsCapacityPlanning');
  }
  // DetailedSite Report CSV Download API
  getDownloadDetailedSite(body) {
    // tslint:disable-next-line:max-line-length
    window.open(environment.api + 'site-management/lineGraph-data-download?searchData=' + body.serachData + '&searchType=' + body.searchType , '_self');
    // return this.httpClient.get(environment.api + '//' + '/' + body.searchType + '/' + body.serachData );
  }
  // Apolo 5G Diversity report Api services
  getGroupNameSearch(term: string) {
      if (term === '') {
        return of([]);
      } else if (term.length === 3 || term.length > 3) {
        const params = term ? new HttpParams().set('diversitygroupname', term) : new HttpParams().set('diversitygroupname', '');
        const headers = { 'Cache-Control': 'no-cache', Pragma: 'no-cache' };
        return this.httpClient.get(environment.api + 'diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname',
        { params });
      } else {
        return of([]);
      }
   }
   getDownloadDiversityReport(body) {
    // tslint:disable-next-line:max-line-length
    window.open(environment.api + 'diversity-group-forecast-management/diversity-group-forecast-download?noofport=' + body.port + '&diversitygroup=' + body.groupName + '&searchType=' + body.code.type + '&searchData=' + body.code.data, '_self');
    // return this.httpClient.get(environment.api + '//' + '/' + body.searchType + '/' + body.serachData );
    // console.log(body);
  }
  getSiteNameDiversitySearch(term: string) {
    if (term === '') {
      return of([]);
    } else if (term.length === 2 || term.length > 2) {
      const params = { params: new HttpParams().set('searchData', term) };
      // return of([{"type":"SITE_NAME","data":"LONDON FOREST HILL"}]);
      return this.httpClient.get(environment.api + 'site-management/search-excode', params);
    } else {
      return of([]);
    }
  }
  getLineCapacityReport() {

    return  this.httpClient.get(environment.api + 'network-capacity-trend-management/total-network-bandwidth-product')
     .pipe(catchError (() => of(null)));
     // ,
     // this.httpClient.get(environment.api + '')
     // .pipe(catchError( () =>  of(null))),
     // this.httpClient.get(environment.api + '')
     // .pipe(catchError( () => of(null)))
}
getProductLineCapacity() {
 return this.httpClient.get(environment.api + 'network-capacity-trend-management/total-product-bandwidth-port')
 .pipe(catchError(() => of(null)));
}
getKeynetwork() {
 return this.httpClient.get(environment.api + 'network-capacity-trend-management/key-network-statistics')
 .pipe(catchError(() => of(null)));
}
getDonutLineChartData() {
  return this.httpClient.get(environment.api + 'network-capacity-trend-management/capacity-distribution')
  .pipe(catchError(() => of(null)));
 }
getDownloadCapacityDashboard() {
 window.open(environment.api + 'network-capacity-trend-management/lineGraph-networkCapacitydata-download', '_self');
 }
 getDownloadDashboardEthernet() {
  window.open(environment.api + 'network-capacity-trend-management/lineGraph-ethernetCapacitydata-download', '_self');
  }
  getDownloadDashboardBroadband() {
    window.open(environment.api + 'network-capacity-trend-management/lineGraph-broadBandCapacitydata-download', '_self');
    }
  getDownloadDashboardBackhaul() {
    window.open(environment.api + 'network-capacity-trend-management/lineGraph-backHaulCapacitydata-download', '_self');
    }
  getDownloadDashboardInfraStructure() {
    window.open(environment.api + 'network-capacity-trend-management/lineGraph-infraStructureCapacitydata-download', '_self');
    }
  getDownloadDashboardP2PE() {
    window.open(environment.api + 'network-capacity-trend-management/lineGraph-P2PECapacitydata-download', '_self');
    }
    getChassView( body: object = []): Observable<any> {
      console.log(JSON.stringify(body));
      return this.httpClient.post(environment.api + 'chassis-viewer/snefilterData', JSON.stringify(body),
        { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
        .pipe(
          catchError(this.handleError)
        );
    }
    getSiteChassView3D( body: object = [] , siteName): Observable<any> {
      const params = { params: new HttpParams().set('searchType', siteName) };
      return this.httpClient.post(environment.api + 'chassis-viewer/snefilterDetailSiteData/searchType?searchType=' + siteName,
       JSON.stringify(body), { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
        .pipe(
          catchError(this.handleError)
        );
    }
    get3DCapacityData(body: object = [], sneID ): Observable<any> {
      console.log(JSON.stringify(body));
      return this.httpClient.post(environment.api + 'chassis-viewer/prediction-report/SNEID:' + sneID,
       JSON.stringify(body), { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
        .pipe(
          catchError(this.handleError)
        );
    }
    getDetailed3DPortData(body: object = [], sneID ): Observable<any> {
      console.log(JSON.stringify(body));
      return this.httpClient.post(environment.api + 'chassis-viewer/detailed-site-report/' + sneID,
       JSON.stringify(body), { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } })
        .pipe(
          catchError(this.handleError)
        );
    }
    getDefault3DportData(sneID) {
      return this.httpClient.get(environment.api + 'chassis-viewer/sne-detail/SNEID:' + sneID)
      .pipe(catchError(() => of(null)));
     }
}
