import { TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { AppService } from './app.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Injectable, COMPILER_OPTIONS } from '@angular/core';
import { Observable, BehaviorSubject, Subject, observable, throwError, of, combineLatest } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { tap, switchMap, retry, catchError, filter } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { filterObject } from '../../../shared/models/filterObject.model';
import { pageObject } from '../../../shared/models/pageObject.model';
describe('AppService', () => {
  let service: AppService;
  // tslint:disable-next-line:prefer-const
  let testBedService: AppService;
  // tslint:disable-next-line:prefer-const
  let httpMock: HttpTestingController;
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
    ],
    providers: [AppService]
  }));
  beforeEach(() => {
    service = TestBed.get(AppService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it(
    'should be initialized',
    inject([AppService], (authService: AppService) => {
      expect(authService).toBeTruthy();
    })
  );
  it(
    'should perform getFilterInfo correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {

          // Set up
          const url = 'http://172.31.10.220:9082/filter-management/filter-info';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          // End Setup

          authService.getFilterInfo().subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/filter-management/filter-info'});
        //  requestWrapper.flush(responseObject);
          tick();
         // expect(requestWrapper.request.method).toEqual('GET');
       //   expect(response.body).toBeUndefined();
        }
      )
    )
  );
  it(
    'should perform getFilterInfo correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set up
          const url = 'http://172.31.10.220:9082/site-management/site-exchange';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          // End Setup

          authService.getserachData().subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/site-management/site-exchange'});
        //  requestWrapper.flush(responseObject);
          tick();
        //  expect(requestWrapper.request.method).toEqual('GET');
         // expect(response.body).toBeUndefined();
        }
      )
    )
  );
  it(
    'should perform getDetailedSiteSearch correctly with 2length',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/site-management/site-exchange';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          // End Setup

          authService.getDetailedSiteSearch('ab').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/site-management/search-data?searchData="ab"'});
          // requestWrapper.flush(responseObject);
          tick();
          // expect(requestWrapper.request.method).toEqual('GET');
          // expect(requestWrapper.request.params).toEqual(dummyParams);
          // expect(response.body).toBeUndefined();
        }
      )
    )
  );
  it(
    'should perform getFilterInfo correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/site-management/site-exchange';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getDetailedSiteSearch('').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/site-management/search-data?searchData="ab"'});
          tick();
        }
      )
    )
  );
  it(
    'should perform getDetailedSiteSearch correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/site-management/site-exchange';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getDetailedSiteSearch('a').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/site-management/search-data?searchData="ab"'});
          tick();
        }
      )
    )
  );
  it(
    'should perform searchDetails correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/forecast-management/forecast-info';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.searchDetails('Lon').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082//forecast-management/forecast-info?searchData="Lon"'});
          tick();
        }
      )
    )
  );
  it(
    'should perform searchDetails correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/forecast-management/forecast-info';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.searchDetails('').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082//forecast-management/forecast-info?searchData=""'});
          tick();
        }
      )
    )
  );
  it(
    'should perform DownloadXLSX correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          authService.DownloadXLSX();
          expect(authService.DownloadXLSX).toBeDefined();
        }
      )
    )
  );
  it(
    'should perform getDownloadDetailedSite correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          const body = {
            serachData : 'London',
            searchType : 'SNE'
          };
          authService.getDownloadDetailedSite(body);
          expect(authService.DownloadXLSX).toBeDefined();
        }
      )
    )
  );
  // Detailed site and Divercity report page
  it(
    'should perform getLineCapacityReport correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {

          // Set up
          const url = 'http://172.31.10.220:9082/network-capacity-trend-management/total-network-bandwidth-product';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          // End Setup

          authService.getLineCapacityReport().subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url:
            'http://172.31.10.220:9082/network-capacity-trend-management/total-network-bandwidth-product'});
        //  requestWrapper.flush(responseObject);
          tick();
         // expect(requestWrapper.request.method).toEqual('GET');
       //   expect(response.body).toBeUndefined();
        }
      )
    )
  );
  it(
    'should perform getProductLineCapacity correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {

          // Set up
          const url = 'http://172.31.10.220:9082/network-capacity-trend-management/total-product-bandwidth-port';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          // End Setup

          authService.getProductLineCapacity().subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          const requestWrapper = backend.expectNone({url:
            'http://172.31.10.220:9082/network-capacity-trend-management/total-product-bandwidth-port'});
        //  requestWrapper.flush(responseObject);
          tick();
         // expect(requestWrapper.request.method).toEqual('GET');
       //   expect(response.body).toBeUndefined();
        }
      )
    )
  );
  it(
    'should perform getSiteNameDiversitySearch1 correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getSiteNameDiversitySearch('Lon').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          // tslint:disable-next-line:max-line-length
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname?searchData="Lon"'});
          tick();
        }
      )
    )
  );
  it(
    'should perform getSiteNameDiversitySearch3 correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getSiteNameDiversitySearch('a').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          // tslint:disable-next-line:max-line-length
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname?searchData="a"'});
          tick();
        }
      )
    )
  );
  it(
    'should perform getSiteNameDiversitySearch2 correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getSiteNameDiversitySearch('').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          // tslint:disable-next-line:max-line-length
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname?searchData=""'});
          tick();
        }
      )
    )
  );
  it(
    'should perform getGroupNameSearch1 correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('diversitygroupname', 'ab');
          const url = 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getGroupNameSearch('Lond').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          // tslint:disable-next-line:max-line-length
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname?diversitygroupname="Lond"'});
          tick();
        }
      )
    )
  );
  it(
    'should perform getGroupNameSearch2 correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getGroupNameSearch('a').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          // tslint:disable-next-line:max-line-length
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname?diversitygroupname="a"'});
          tick();
        }
      )
    )
  );
  it(
    'should perform getGroupNameSearch3 correctly',
    fakeAsync(
      inject(
        [AppService, HttpTestingController],
        (authService: AppService, backend: HttpTestingController) => {
          // Set upnew HttpParams().set('searchData', term)
          const dummyParams = new HttpParams().set('searchData', 'ab');
          const url = 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname';
          const responseObject = {
            success: true,
            message: 'login was successful'
          };
          let response = null;
          authService.getGroupNameSearch('').subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );
          // tslint:disable-next-line:max-line-length
          const requestWrapper = backend.expectNone({url: 'http://172.31.10.220:9082/diversity-group-forecast-management/diversity-group-forecast-data/diversitygroupname?diversitygroupname=""'});
          tick();
        }
      )
    )
  );

  it('updateData should return value from observable', () => {
    const body: object = [];
    service.updateData(body).subscribe(value => {
      expect(value).toBe('observable value');
    });
  });
  it('updateData should Defined', () => {
    expect(service.updateData()).toBeDefined();
  });
  it('getSavedpref should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let body: number;
    service.getSavedpref(body).subscribe(value => {
      expect(value).toBe('observable value');
    });
  });
  it('getserachData should return value from observable', () => {
    service.getserachData().subscribe(value => {
      expect(value).toBe('observable value');
    });
  });
  it('getserachData should Defined', () => {
    expect(service.getserachData()).toBeDefined();
  });

  it('getfilterdata should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let body;
    service.getfilterdata(body).subscribe(value => {
      expect(value).toBe('observable value');
    });
  });

  it('getfilterdata should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let body;
    service.getfilterdata(body).subscribe(value => {
      expect(value).toBe(null);
    });
  });

  it('getFilterInfo should return value from observable', () => {
    service.getFilterInfo().subscribe(value => {
      expect(value).toBe('observable value');
    });
  });

  it('should throw an error if the service is unavailable  ', () => {
    service.handleError((err) => {
      expect(err).toBeUndefined();
    });
  });
  it('should throw an error if the service is unavailable  ', () => {
    const errObj = new ErrorEvent('errr');
    service.handleError((err) => {
      expect(err).toBeUndefined();
    });
  });

  it('getFilterMasterInfo should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let body = {deviceModel: [], deviceUsages: [], deviceType: [], deviceVersion: [], productType: '',
    portSpeed: [], chassisSpeed: [], cardModel: [], cardType: [],
    cardVersion: [], marketType: [], nodeType: [], ein: 121221};
    service.getFilterMasterInfo(body).subscribe((value: any) => {
      expect(value).toBe('observable value');
    });
  });

  it('getSaveUserPre should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let body;
    service.getSaveUserPre().subscribe(value => {
      expect(value).toBe('observable value');
    });
  });

  it('getSavedpref should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let body;
    service.getSavedpref(body).subscribe(value => {
      expect(value).toBe('observable value');
    });
  });

  // it('getLogout should return value from observable', () => {
  //   service.getLogout().subscribe(value => {
  //     expect(value).toBe('observable value');
  //   });
  // });

  it('postExcelFile should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let body: number;
    service.postExcelFile().subscribe(value => {
      expect(value).toBe('observable value');
    });
  });

  it('deleteGridItem should return value from observable', () => {
    const id = 2;
    service.deleteGridItem(id).subscribe(value => {
      expect(value).toBe('observable value');
    });
  });
  it('deleteGridItem should return value from observable', () => {
    // tslint:disable-next-line:prefer-const
    let id;
    service.deleteGridItem(id).subscribe(value => {
      expect(value).toBe('observable value');
    });
  });
  it('DownloadXLSX should Defined', () => {
    expect(service.DownloadXLSX()).not.toBeNull();
  });
  it('searchDetails should Defined', () => {
    const search = 'abc';
    expect(service.searchDetails(search)).toBeDefined();
  });
  it('searchDetails should Defined', () => {
    // tslint:disable-next-line:prefer-const
    let search = '';
    expect(service.searchDetails(search)).toBeDefined();
  });
  it('getGridDataToExport should return value from observable', () => {
    service.getGridDataToExport().subscribe(value => {
      expect(value).toBe('observable value');
    });
  });
  it('getGridDataToExport should Defined', () => {
    expect(service.getGridDataToExport()).toBeDefined();
  });
  it('search should Defined', () => {
    const term = '';
    expect(service.search(term)).toBeDefined();
  });
  it('search should Defined', () => {
    // tslint:disable-next-line:prefer-const
    let term = 'abcdef';
    expect(service.search(term)).toBeDefined();
  });
  it('search should Defined', () => {
    // tslint:disable-next-line:prefer-const
    let term = 'a';
    expect(service.search(term)).toBeDefined();
  });
  it('logInPage should Defined', () => {
    const url = environment.api.split(':');
    expect(service.logInPage()).toBeDefined();
  });

  // it('getDownloadDetailedSite should Defined', () => {
  //   const body = [];
  //   expect(service.getDownloadDetailedSite(body)).not.toBeNull();
  // });

  it('getDetailedSiteSearch should Defined if case', () => {
    const term = '';
    expect(service.getDetailedSiteSearch(term)).toBeDefined();
  });

  it('getDetailedSiteSearch should Defined else case', () => {
    const term = 'abc';
    expect(service.getDetailedSiteSearch(term)).toBeDefined();
  });
  it('getDetailedSiteSearch should Defined else case', () => {
    const term = 'a';
    expect(service.getDetailedSiteSearch(term)).toBeDefined();
  });

});
