import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { environment } from '../../../../environments/environment';


@Injectable()

export class ChassisViewService {

  chassisDataUrl: string;
  chassisUrl: string;
  sneList: string;
  chassisDeviceData = new BehaviorSubject(null);

  constructor(private httpClient: HttpClient) {
    this.chassisDataUrl = './assets/3ddata.json';
    this.chassisUrl = './assets/3dData_working.json';
    this.sneList = './assets/sneList.json';
  }


  // getChassisData(sneID): Observable<any> {
  //   return this.httpClient.get(this.chassisDataUrl);
  // }

  getSneList(term) {
    if (term === '') {
      return of([]);
    } else if (term.length === 2 || term.length > 2) {
      const params = { params: new HttpParams().set('searchData', term) };
      // return this.httpClient.get(environment.api + 'chassis-viewer/sne-details/searchData', params);
      return this.httpClient.get(this.sneList); // Hardcoded SNE list json call
    } else {
      return of([]);
    }
  }

  /* getSneData(): Observable<any> {
    return this.httpClient.get('http://172.31.10.212:9081//chassis-viewer/sne-details/searchData?searchData=20');
  } */

  /* getSneData(): Observable<any> {
    return this.httpClient.get(environment.api + 'chassis-viewer/sne-details/searchData?searchData=20');
  } */

}
