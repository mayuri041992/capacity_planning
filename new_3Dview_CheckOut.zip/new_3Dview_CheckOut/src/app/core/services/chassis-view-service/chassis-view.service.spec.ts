import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ChassisViewService } from './chassis-view.service';


describe('ChassisViewService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
    ],
    providers: [ChassisViewService]

  }));

  it('should be created', () => {
    const service: ChassisViewService = TestBed.get(ChassisViewService);
    expect(service).toBeTruthy();
  });

});

