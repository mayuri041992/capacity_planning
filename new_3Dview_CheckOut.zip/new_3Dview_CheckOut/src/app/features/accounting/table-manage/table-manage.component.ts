import { Component, OnInit, Input, OnChanges, Output, EventEmitter, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { AppService } from '../../../core/services/app-service/app.service';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subject, Subscription } from 'rxjs';
import { switchMap, tap, filter } from 'rxjs/operators';

@Component({
  selector: 'app-table-manage',
  templateUrl: './table-manage.component.html',
  styleUrls: ['./table-manage.component.scss']
})
export class TableManageComponent implements OnInit, OnChanges, OnDestroy {
  searchData: string;
  // all subscription tokens
  cancelEvent$: Subscription;
  seachText$: Subscription;
  @Input() search: string;
  @ViewChild('confirmDelete') confirmDelete: ElementRef;
  currentDeleteItem = null;
  currentDeleteId;
  editedItems: object = {};
  private uniqueGridItemKey = 'id';
  // columnShow: Array<any> = [
  //   { header: 'Site', field: 'Site Name', width: '20%' },
  //   { header: '1141 code', field: '1141 Code', width: '20%' },
  //   { header: 'FastE Ethernet', field: 'FastE Ethernet', width: '15%' },
  //   { header: 'GigE Ethernet', field: 'GigE Ethernet', width: '15%' },
  //   { header: '10G Ethernet', field: '10G Ethernet', width: '15%' },
  //   { header: '10G Broadband', field: '10G Broadband', width: '15%' },
  //   { header: '10G WMC', field: '10G WMC', width: '15%' },
  //   { header: '10G WMC-Apollo', field: '10G WMC-Apollo', width: '15%' },
  //   { header: '10G WMC-TEF', field: '10G WMC-TEF', width: '15%' },
  //   { header: '10G HE', field: '10G HE', width: '15%' },
  //   { header: '10G Backhaul', field: '10G Backhaul', width: '15%' },
  //   { header: '10G PRTC', field: '10G PRTC', width: '15%' },
  //   { header: 'Action', field: 'action', width: '08%' }
  // ];
  public frozenCols: Array<any> = [
    { header: 'Site', field: 'Site Name', width: '20%' },
    { header: '1141 code', field: '1141 Code', width: '20%' },
  ];
  public Scrollabel: Array<any> = [
    { header: 'FastE Ethernet', field: 'FastE Ethernet', width: '15%' },
    { header: 'GigE Ethernet', field: 'GigE Ethernet', width: '15%' },
    { header: '10G Ethernet', field: '10G Ethernet', width: '15%' },
    { header: '10G Broadband', field: '10G Broadband', width: '15%' },
    { header: '10G WMC', field: '10G WMC', width: '15%' },
    { header: '10G WMC-Apollo', field: '10G WMC-Apollo', width: '15%' },
    { header: '10G WMC-TEF', field: '10G WMC-TEF', width: '15%' },
    { header: '10G HE', field: '10G HE', width: '15%' },
    { header: '10G Backhaul', field: '10G Backhaul', width: '15%' },
    { header: '10G PRTC', field: '10G PRTC', width: '15%' },
    { header: 'Action', field: 'action', width: '08%' }
  ];
  public Rows = [];
  constructor(private modalService: NgbModal, private services: AppService, private forecastLineService: ForecastLineService) {
     // 1.check for the string
    // 2. make a network call if string is not empty
    // 3.network call will cancel the updates made
    this.cancelEvent$ = this.forecastLineService.cancelEvent$.pipe(
      filter((data) => data),
      switchMap((searchString) => this.services.searchDetails(searchString))
    ).subscribe((tableDetails: object[]) => this.serviceCallToGetRow(tableDetails));

    // 1.check for the string
    // 2. make a network call if string is not empty
    // 3.network call will save the updates made
    this.seachText$ = this.forecastLineService.seachText$.pipe(
      filter((data) =>  data),
      switchMap((searchString) => this.services.searchDetails(searchString))
    ).subscribe((tableDetails: object[]) => this.serviceCallToGetRow(tableDetails));

    // this.forecastLineService.cancelEvent$.pipe(switchMap( (searchString) => this.services.searchDetails(searchString))).
    // subscribe((tableDetails: object[]) => this.serviceCallToGetRow(tableDetails));

    // this.forecastLineService.seachText$.pipe(
    //   switchMap( (searchString) => this.services.searchDetails(searchString))
    // ).subscribe((tableDetails: object[]) => this.serviceCallToGetRow(tableDetails));
  }
  ngOnInit() {}
  ngOnChanges() {}
  serviceCallToGetRow(tableDetails: object[]) {
    this.Rows = tableDetails;
    const rowdata = [];
    if (this.Rows) {
      this.Rows.forEach(key => {
        rowdata.push({
          id: (key.id ? key.id : key.id),
          '1141 Code': (key.forecastCode ? key.forecastCode : key['1141 code']),
          'Site Name': (key.siteName ? key.siteName : key['Site name']),
          'GigE Ethernet': (key.gigEforecast ? key.gigEforecast : key.GigEforecast),
          '10G Ethernet': (key.hE10Gforecast ? key.hE10Gforecast : key.HE10Gforecast),
          '10G Broadband': (key.bB10Gforecast ? key.bB10Gforecast : key.BB10Gforecast),
          'FastE Ethernet': (key.fastEforecast ? key.fastEforecast : key.FastEforecast),
          '10G WMC': (key.wmc10G ? key.wmc10G : key.wmc10G),
          '10G WMC-Apollo': (key.wmcApollo10G ? key.wmcApollo10G : key.wmcApollo10G),
          '10G WMC-TEF': (key.wmcTef10G ? key.wmcTef10G : key.wmcTef10G),
          '10G HE': (key.he10G ? key.he10G : key.he10G),
          '10G Backhaul': (key.backhaul10G ? key.backhaul10G : key.backhaul10G),
          '10G PRTC': (key.prtc10G ? key.prtc10G : key.prtc10G)
        });
      });
      this.Rows = rowdata;
    }
  }
  deleteEvent(deleteObj) {
    const modalRef = this.modalService.open(this.confirmDelete, {windowClass: 'myCustomClass'});
    this.currentDeleteItem = deleteObj;
    this.currentDeleteId = deleteObj.rowDetails[this.uniqueGridItemKey];
  }
  deleteRow() {
    this.services.deleteGridItem(this.currentDeleteId).subscribe(
      (data) => {
        if (data.status) {
          this.currentDeleteItem.clonedRows.splice(this.currentDeleteItem.index, 1);
          this.currentDeleteItem.clonedRows = [...this.currentDeleteItem.clonedRows];
          this.Rows.splice(this.currentDeleteItem.index, 1);
          this.Rows = [...this.Rows];
          delete this.editedItems[this.currentDeleteItem.rowDetails[this.uniqueGridItemKey]];
          this.modalService.dismissAll();
        }
      },
      () => {
        this.modalService.dismissAll();
       });
  }
  editEvent(editObj) {
    this.editedItems[editObj.rowDetails[this.uniqueGridItemKey]] = editObj.rowDetails;
    this.forecastLineService.setUpadtedData(this.editedItems);
  }
  ngOnDestroy() {
    // all subscription tokens are unsubscribed
    this.seachText$.unsubscribe();
    this.cancelEvent$.unsubscribe();
  }
}
