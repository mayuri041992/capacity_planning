import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TableManageComponent } from './table-manage.component';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppService } from '../../../core/services/app-service/app.service';
import { MessageService } from 'primeng/api';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';

describe('TableManageComponent', () => {
  let component: TableManageComponent;
  let fixture: ComponentFixture<TableManageComponent>;
  let service: AppService;
  // tslint:disable-next-line:prefer-const
  let modalService: NgbModal;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, TableModule, PaginatorModule, NgbModule],
      declarations: [TableManageComponent],
      providers: [AppService, MessageService, ForecastLineService, NgbModal],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
    service = TestBed.get(AppService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check the deleteEvent function', () => {
    const deleteObj = [{
      code: 'ZCF/K',
      BB10Gforecast: '10',
      FastEforecast: '191',
      GigEforecast: '197',
      HE10Gforecast: '112',
      id: 740
    }];
    expect(component.deleteEvent).toBeDefined();
    spyOn(service, 'deleteGridItem').and.returnValue(of(component.currentDeleteId));
  });

  it('should check the editEvent function', () => {
    const editObj = {
      rowDetails: { id: 10273, 1141: 'BSE/K', Sitename: 'BRYNMAWR', GigEforecast: '141559', HE10Gforecast: '159664' }
    };
    component.editEvent(editObj);
    expect(component.editEvent).toBeDefined();
  });

  it('should check the deleteRow function', () => {
    component.currentDeleteItem = {
       clonedRows: ''
    };
    component.currentDeleteId = [{
      code: 'ZCF/K',
      BB10Gforecast: '10',
      FastEforecast: '191',
      GigEforecast: '197',
      HE10Gforecast: '112',
      id: 740
    }];
    component.deleteRow();
    expect(component.deleteRow).toBeDefined();
    spyOn(service, 'deleteGridItem').and.returnValue(of(component.currentDeleteId));
  });

  it('should check function ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeDefined();
  });
  it('should check the serviceCallToGetRow function', () => {
    const tableDetails = [{
      forecastCode: 'ZCF/K',
      siteName: 'BRYNMAWR',
      bB10Gforecast: '10',
      fastEforecast: '191',
      gigEforecast: '197',
      hE10Gforecast: '112',
      id: 32
    }];
    component.serviceCallToGetRow(tableDetails);
    expect(component.serviceCallToGetRow).toBeDefined();
  });

  it('should check the serviceCallToGetRow function ? condition', () => {
    const tableDetails = [{
    }];
    component.serviceCallToGetRow(tableDetails);
    expect(component.serviceCallToGetRow).toBeDefined();
  });

  it('should check function deleteEvent', () => {
    const deleteObj = {
      rowDetails: { }
    };
    component.deleteEvent(deleteObj);
    expect(component.deleteEvent).toBeDefined();
  });
  it('should check function editEvent', () => {
    const editObj = {
      rowDetails: { }
    };
    component.editEvent(editObj);
    expect(component.editEvent).toBeDefined();
  });
});
