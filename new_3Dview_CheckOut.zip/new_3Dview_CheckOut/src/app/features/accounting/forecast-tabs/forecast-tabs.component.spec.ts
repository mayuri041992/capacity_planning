import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { ForecastTabsComponent } from './forecast-tabs.component';
import { Tab } from '../../../shared/models/forecast.model';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Directive, Input } from '@angular/core';
import { TabComponentDirective } from '../../../shared/directive/tab-component.directive';
import { UploadForecastComponent } from '../upload-forecast/upload-forecast.component';
import { NgbAlert } from '@ng-bootstrap/ng-bootstrap';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppService } from '../../../core/services/app-service/app.service';

describe('ForecastTabsComponent', () => {
  let component: ForecastTabsComponent;
  let fixture: ComponentFixture<ForecastTabsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule],
      declarations: [ ForecastTabsComponent, TabComponentDirective , UploadForecastComponent , NgbAlert ],
      providers: [ForecastLineService, AppService],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
    }).overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [UploadForecastComponent] } })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForecastTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check function setActiveTab', () => {
    component.setActiveTab('upload_forecast');
    expect(component.setActiveTab).toBeDefined();
  });
});
