import { Component, OnInit, OnDestroy } from '@angular/core';
import { Tab } from '../../../shared/models/forecast.model';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
@Component({
  selector: 'app-forecast-tabs',
  templateUrl: './forecast-tabs.component.html',
  styleUrls: ['./forecast-tabs.component.scss']
})
export class ForecastTabsComponent implements OnInit, OnDestroy {
  public uploadclass: string;
  successMessage;
  activeTab$: Observable<any>;
  constructor(private forecastLineService: ForecastLineService) {
    this.activeTab$ = this.forecastLineService.getActiveTab();
    this.activeTab$.subscribe((tabdetails) => {
      // tslint:disable-next-line:no-string-literal
      this.uploadclass = tabdetails[0]['name'];
    });
  }
  ngOnInit() {
  }
  setActiveTab(tabName) {
    this.forecastLineService.setActiveTab(tabName).pipe( tap( () => {
      this.activeTab$ = this.forecastLineService.getActiveTab();
    }));
  }
  ngOnDestroy() {
    this.forecastLineService.setActiveTab('upload_forecast');
  }
}
