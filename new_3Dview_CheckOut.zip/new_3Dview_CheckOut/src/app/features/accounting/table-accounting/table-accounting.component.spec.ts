import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TableComponent } from '../../../shared/components/table/table.component';
import { TableAccountingComponent } from './table-accounting.component';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { of, BehaviorSubject } from 'rxjs';

describe('TableAccountingComponent', () => {
  let component: TableAccountingComponent;
  let fixture: ComponentFixture<TableAccountingComponent>;
  let service: ForecastLineService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, TableModule, PaginatorModule],
      declarations: [TableAccountingComponent, TableComponent],
      providers: [ForecastLineService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
    service = TestBed.get(ForecastLineService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableAccountingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.columnShow = [
      { header: 'Site', field: 'Site Name', width: '20%' },
      { header: '1141 code', field: '1141 Code', width: '20%' }];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should define ngOninit', () => {
    expect(component.ngOnInit).toBeDefined();
  });
  // it('should define rows1', () => {

  //   expect(component.Rows).toBeDefined();
  // });
  it('should define rows', () => {
    expect(component.columnShow).toBeDefined();
  });

  it('should define subscribe', () => {
    const status = 'success';
    component.rowDetails(component.columnShow, status);
    expect(component.rowDetails).toBeDefined();
  });

  it('should define subscribe else condition', () => {
    const status = 'success';
    const obj = [
      { '1141 Code': 0, field: 'Site Name', width: '20%' },
      { 'Site Name': 0, field: '1141 Code', width: '20%' },
      { 'FastE forecast': 20, field: 'FastE forecast', width: '20%' },
      { 'GigE forecast': 20, field: 'GigE forecast', width: '20%' },
      { 'HE 10G forecast': 20, field: 'HE 10G forecast', width: '20%' },
      { 'BB 10G forecast': 20, field: 'BB 10G forecast', width: '20%' }
    ];
    component.rowDetails(obj, status);
    expect(component.rowDetails).toBeDefined();
  });
  it('should define subscribe else condition', () => {
    const status = '';
    const obj = [
      { '1141 Code': 0, field: 'Site Name', width: '20%' },
      { 'Site Name': 0, field: '1141 Code', width: '20%' },
      { 'FastE forecast': 20, field: 'FastE forecast', width: '20%' },
      { 'GigE forecast': 20, field: 'GigE forecast', width: '20%' },
      { 'HE 10G forecast': 20, field: 'HE 10G forecast', width: '20%' },
      { 'BB 10G forecast': 20, field: 'BB 10G forecast', width: '20%' }
    ];
    component.rowDetails(obj, status);
    expect(component.rowDetails).toBeDefined();
  });
});
