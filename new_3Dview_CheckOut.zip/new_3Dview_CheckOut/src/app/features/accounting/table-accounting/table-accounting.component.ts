import { Component, OnInit } from '@angular/core';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import _ from 'lodash';

@Component({
  selector: 'app-table-accounting',
  templateUrl: './table-accounting.component.html',
  styleUrls: ['./table-accounting.component.scss']
})
export class TableAccountingComponent implements OnInit {
  public Rows: object[];
  public rows: object[];
  // columnShow: Array<any> = [
  //   { header: 'Site', field: 'Site Name', width: '20%' },
  //   { header: '1141 code', field: '1141 Code', width: '20%' },
  //   { header: 'FastE Ethernet', field: 'FastE Ethernet', width: '15%' },
  //   { header: 'GigE Ethernet', field: 'GigE Ethernet', width: '15%' },
  //   { header: '10G Ethernet', field: '10G Ethernet', width: '15%' },
  //   { header: '10G Broadband', field: '10G Broadband', width: '15%' },
  //   { header: '10G WMC', field: '10G WMC', width: '15%' },
  //   { header: '10G WMC-Apollo', field: '10G WMC-Apollo', width: '15%' },
  //   { header: '10G WMC-TEF', field: '10G WMC-TEF', width: '15%' },
  //   { header: '10G HE', field: '10G HE', width: '15%' },
  //   { header: '10G Backhaul', field: '10G Backhaul', width: '15%' },
  //   { header: '10G PRTC', field: '10G PRTC', width: '15%' }
  // ];
  public frozenCols: Array<any> = [
    { header: 'Site', field: 'Site Name', width: '20%' },
    { header: '1141 code', field: '1141 Code', width: '20%' },
  ];
  public Scrollabel: Array<any> = [
    { header: 'FastE Ethernet', field: 'FastE Ethernet', width: '15%' },
    { header: 'GigE Ethernet', field: 'GigE Ethernet', width: '15%' },
    { header: '10G Ethernet', field: '10G Ethernet', width: '15%' },
    { header: '10G Broadband', field: '10G Broadband', width: '15%' },
    { header: '10G WMC', field: '10G WMC', width: '15%' },
    { header: '10G WMC-Apollo', field: '10G WMC-Apollo', width: '15%' },
    { header: '10G WMC-TEF', field: '10G WMC-TEF', width: '15%' },
    { header: '10G HE', field: '10G HE', width: '15%' },
    { header: '10G Backhaul', field: '10G Backhaul', width: '15%' },
    { header: '10G PRTC', field: '10G PRTC', width: '15%' }
  ];
  constructor(private forecastLineService: ForecastLineService) {
   }
  ngOnInit() {
    this.forecastLineService.tableAccountData$.subscribe((tableDetails) => {
      // this.rowDetails(tableDetails.data);
      this.rowDetails(tableDetails.data,  tableDetails.status);
    });
  }
  rowDetails(data, status) {
    this.Rows = data;
    const rowdata = [];
    if (this.Rows && status === 'success') {
      this.Rows.forEach((rowValue) => {
        const obj = [];
        rowValue['1141 Code'] === 0 ? rowValue['1141 Code'] = '' :     rowValue['1141 Code'] = rowValue['1141 Code'];
        rowValue['Site Name'] === 0 ? rowValue['Site Name'] = '' :     rowValue['Site Name'] = rowValue['Site Name'];
        rowValue['FastE Ethernet'] ? rowValue['FastE Ethernet'] = rowValue['FastE Ethernet'] :  rowValue['FastE Ethernet'] = 0;
        rowValue['GigE Ethernet']  ?  rowValue['GigE Ethernet'] = rowValue['GigE Ethernet'] : rowValue['GigE Ethernet'] = 0;
        rowValue['10G Ethernet']  ?  rowValue['10G Ethernet'] = rowValue['10G Ethernet'] : rowValue['10G Ethernet'] = 0;
        rowValue['10G Broadband']  ? rowValue['10G Broadband'] = rowValue['10G Broadband'] : rowValue['10G Broadband'] = 0;
        rowValue['10G WMC']  ?  rowValue['10G WMC'] = rowValue['10G WMC'] : rowValue['10G WMC'] = 0;
        rowValue['10G WMC-Apollo']  ?  rowValue['10G WMC-Apollo'] = rowValue['10G WMC-Apollo'] : rowValue['10G WMC-Apollo'] = 0;
        rowValue['10G WMC-TEF']  ? rowValue['10G WMC-TEF'] = rowValue['10G WMC-TEF'] : rowValue['10G WMC-TEF'] = 0;
        rowValue['10G HE']  ?  rowValue['10G HE'] = rowValue['10G HE'] : rowValue['10G HE'] = 0;
        rowValue['10G Backhaul']  ?  rowValue['10G Backhaul'] = rowValue['10G Backhaul'] : rowValue['10G Backhaul'] = 0;
        rowValue['10G PRTC']  ? rowValue['10G PRTC'] = rowValue['10G PRTC'] : rowValue['10G PRTC'] = 0;
        rowdata.push(rowValue);
      });
      this.rows = _.uniqBy(rowdata, uniqData => JSON.stringify([uniqData['1141 Code'], uniqData['Site Name']]));
      // this.Rows = rowdata;
    } else {
      this.Rows.forEach((rowValue) => {
        const obj = [];
        rowValue['1141 Code'] === 0 ? rowValue['1141 Code'] = '' :     rowValue['1141 Code'] = rowValue['1141 Code'];
        rowValue['Site Name'] === 0 ? rowValue['Site Name'] = '' :     rowValue['Site Name'] = rowValue['Site Name'];
        rowdata.push(rowValue);
      });
      this.rows = rowdata;
    }

  }
}
