import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppService } from '../../../core/services/app-service/app.service';
import { ActionComponent } from './action.component';
import { LoginService } from '../../../core/services/login-service/login.service';
import { MessageService } from 'primeng/api';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject, of } from 'rxjs';
describe('ActionComponent', () => {
  let component: ActionComponent;
  let fixture: ComponentFixture<ActionComponent>;
  let service: AppService;
  let foreService: ForecastLineService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgbModule],
      declarations: [ActionComponent],
      providers: [AppService, LoginService, MessageService, ForecastLineService]
    })
    .compileComponents();
    service = TestBed.get(AppService);
    foreService = TestBed.get(ForecastLineService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.submitClick = false;

  });

  it('should create', () => {
    expect(component).toBeTruthy();
    foreService.showHide.next(true);
    component.dangerMsg.next('failed Data');
    component.successMsg.next('Success Data');
   // foreService.tableAccountData$.next(true);
    spyOn(foreService, 'tableAccountData$').and.callThrough();
   // expect(foreService.tableAccountData$).toHaveBeenCalled();
  });

  it('should check function onSubmit', () => {
    component.onSubmit();
    expect(component.onSubmit).toBeDefined();
   // spyOn(service, 'postExcelFile').and.returnValue(of([]));
   // expect(service.postExcelFile).toHaveBeenCalled();
  });
  it('should check function ngOnInit', () => {
    const successMessage = 'pass';
    const dangerMessage = 'fail';
    component.ngOnInit();
    expect(component.ngOnInit).toBeDefined();
  });

  it('should check function onCancel', () => {
    component.onCancel();
    expect(component.onCancel).toBeDefined();
  });

  it('should check function onUpdate', () => {
    component.updateDetail = [{ '1141 Code': 'BSE/K' },
    { 'BB 10G forecast': '13866' },
    { 'FastE forecast': '1256' },
    { 'GigE forecast': '14155' },
    { 'HE 10G forecast': '15966' },
    { 'Site Name': 'BRYNMAWR' },
    { id: 10273 }];
    expect(component.updateDetail.length).toEqual(7);
    spyOn(service, 'updateData').and.returnValue(of(component.updateDetail));
    component.onUpdate();
    expect(component.onUpdate).toBeDefined();

  });


  it('should check function ngOnChanges', () => {
    component.ngOnChanges();
    expect(component.ngOnChanges).toBeDefined();
  });
  it('should define submit', () => {
    component.submitClick = true;
    const success = { data : [{ '1141 Code': 'BSE/K' },
    { 'BB 10G forecast': '13866' }, { 'FastE forecast': '1256' },
    { 'GigE forecast': '14155' },
    { 'HE 10G forecast': '15966' },
    { 'Site Name': 'BRYNMAWR' },
    { id: 10273 }] , status: 'success' };
    component.submit(success);
    expect(component.submit).toBeDefined();
  });
  it('should define submit', () => {
    component.submitClick = true;
    const success = { status: 'fail' };
    component.submit(success);
    expect(component.submit).toBeDefined();
  });
});
