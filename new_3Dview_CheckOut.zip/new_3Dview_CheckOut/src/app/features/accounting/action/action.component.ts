import { Component, OnInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';
import { AppService } from '../../../core/services/app-service/app.service';
import { tap, debounceTime } from 'rxjs/operators';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { MessageService } from 'primeng/api';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.scss']
})

export class ActionComponent implements OnInit, OnChanges {
  public submitClick: boolean;
  @Input() nameComponent: string;
  @Output() submitted = new EventEmitter();
  @Output() cancel = new EventEmitter();
  public updateDetail;
  public successMsg = new Subject<string>();
  public dangerMsg = new Subject<string>();
  successMessage: string;
  dangerMessage: string;
  showUpdateButton = false;
  constructor(private services: AppService, private forecastLineService: ForecastLineService, private messageService: MessageService) {
      this.forecastLineService.showHide.subscribe((data) => {
              if (data) {
                this.showUpdateButton = true;
              }
      });
  }
  ngOnInit() {
    this.forecastLineService.sendUpdatedData$.subscribe((updateData) => {
      this.updateDetail = updateData;
    });
    this.successMsg.subscribe((message) => this.successMessage = message);
    this.successMsg.pipe(debounceTime(2000)).subscribe(() => this.successMessage = null);
    this.dangerMsg.subscribe((message) => this.dangerMessage = message);
    this.dangerMsg.pipe(debounceTime(2000)).subscribe(() => this.dangerMessage = null);
  }
  ngOnChanges() { }
  onSubmit() {
    this.submitClick = true;
    this.forecastLineService.tableAccountData$.subscribe((success) => {
    this.submit(success);
    this.submitClick = false;
    });
  }
  submit(success) {
    if (this.submitClick) {
      if (success.status === 'success') {
        const keyValue = success.data;
        const importData = [];
        keyValue.forEach((key) => {
          importData.push({
            code_1141: (key['1141 Code'] ? key['1141 Code'] : ''),
            site_Name: (key['Site Name'] ? key['Site Name'] : ''),
            gige_Forecast: (key['GigE Ethernet'] ? key['GigE Ethernet'] : ''),
            he10G_Forecast: (key['10G Ethernet'] ? key['10G Ethernet'] : ''),
            bb10G_Forecast: (key['10G Broadband'] ? key['10G Broadband'] : ''),
            faste_Forecast: (key['FastE Ethernet'] ? key['FastE Ethernet'] : ''),
            WMC_10G: (key['10G WMC'] ? key['10G WMC'] : ''),
            WMC_Apollo_10G: (key['10G WMC-Apollo'] ? key['10G WMC-Apollo'] : ''),
            WMC_TEF_10G: (key['10G WMC-TEF'] ? key['10G WMC-TEF'] : ''),
            HE_10G: (key['10G HE'] ? key['10G HE'] : ''),
            BACKHAUL_10G: (key['10G Backhaul'] ? key['10G Backhaul'] : ''),
            PRTC_10G: (key['10G PRTC'] ? key['10G PRTC'] : '')
          });
        });
        this.services.postExcelFile(importData).subscribe(() => {
          this.forecastLineService._success.next(`File has been succesfully submitted`);
          this.submitted.next(false);
        },
          () => {
            this.forecastLineService._danger.next(`File has not submitted`);
            this.submitted.next(true);
          });
      } else {
        this.forecastLineService._danger.next(`File has not submitted`);
        this.submitted.next(true);
      }
    }
  }
  onCancel() {
    this.forecastLineService.cancelEvent.next('');
    const saveElems = Array.from(document.querySelectorAll('#updatedTable'));
    saveElems.map((elem: HTMLElement) => {
      elem.click();
    });
    this.showUpdateButton = false;
    this.cancel.next(false);
  }
  onUpdate() {
    if (this.updateDetail) {
      const keyObjesct = Object.keys(this.updateDetail);
      const updateRow = [];
      keyObjesct.forEach(a => updateRow.push(this.updateDetail[a]));
      const keyValue = updateRow;
      const importData = [];
      keyValue.forEach((key) => {
        importData.push({
          code_1141: (key['1141 Code'] ? key['1141 Code'] : ''),
          site_Name: (key['Site Name'] ? key['Site Name'] : ''),
          gige_Forecast: (key['GigE Ethernet'] ? key['GigE Ethernet'] : ''),
          he10G_Forecast: (key['10G Ethernet'] ? key['10G Ethernet'] : ''),
          bb10G_Forecast: (key['10G Broadband'] ? key['10G Broadband'] : ''),
          faste_Forecast: (key['FastE Ethernet'] ? key['FastE Ethernet'] : ''),
          WMC_10G: (key['10G WMC'] ? key['10G WMC'] : ''),
          WMC_Apollo_10G: (key['10G WMC-Apollo'] ? key['10G WMC-Apollo'] : ''),
          WMC_TEF_10G: (key['10G WMC-TEF'] ? key['10G WMC-TEF'] : ''),
          HE_10G: (key['10G HE'] ? key['10G HE'] : ''),
          BACKHAUL_10G: (key['10G Backhaul'] ? key['10G Backhaul'] : ''),
          PRTC_10G: (key['10G PRTC'] ? key['10G PRTC'] : '')
        });
      });
      this.services.updateData(importData).subscribe(() => {
        this.successMsg.next(`Updated Successfully`);
        const saveElems = Array.from(document.querySelectorAll('#updatedTable'));
        saveElems.map((elem: HTMLElement) => {
          elem.click();
        });
      },
        () => {
          this.dangerMsg.next(`Updated Failed`);
        });
    } else {
      const saveElems = Array.from(document.querySelectorAll('#updatedTable'));
      saveElems.map((elem: HTMLElement) => {
        elem.click();
      });
    }
    this.updateDetail = null;
    this.showUpdateButton = false;
  }
}
