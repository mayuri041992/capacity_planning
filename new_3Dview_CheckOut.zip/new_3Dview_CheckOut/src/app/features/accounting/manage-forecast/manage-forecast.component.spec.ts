import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit, Output, EventEmitter, Input, AfterViewInit, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppService } from '../../../core/services/app-service/app.service';
import { MessageService } from 'primeng/api';
import { catchError, debounceTime, map, switchMap } from 'rxjs/operators';
import { Observable, of, Subject } from 'rxjs';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { ManageForecastComponent } from './manage-forecast.component';
import { SvgComponent } from '../../../shared/components/svg/svg.component';
import { FormsModule } from '@angular/forms';
import { ActionComponent } from '../action/action.component';
import { TableManageComponent } from '../table-manage/table-manage.component';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('ManageForecastComponent', () => {
  let component: ManageForecastComponent;
  let fixture: ComponentFixture<ManageForecastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, NgbModule],
      declarations: [ManageForecastComponent, SvgComponent, ActionComponent],
      providers: [ForecastLineService, AppService, MessageService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageForecastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test selected function and searchData value', () => {
    const item = {
      item: null
    };
    component.selected(item);
    expect(component.selected).toBeDefined();
    expect(component.searchData).toEqual(null);

  });

  it('should test selected function and searchData value', () => {

    component.onUpdate(event);
    expect(component.onUpdate).toBeDefined();
  });

  it('should test onClear function and searchData value', () => {
    const item = {
      item: null
    };
    const event = {
      target: {
        value: ''
      }
    };
    component.searchInput = '';
    component.selected(item);
    component.onClear(event);
    expect(component.searchData).toEqual('');
    expect(component.onClear).toBeDefined();
  });
});
