import { Component, OnInit, Output, EventEmitter, Input, AfterViewInit, OnDestroy } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AppService } from '../../../core/services/app-service/app.service';
import { catchError, debounceTime, map, switchMap } from 'rxjs/operators';
import { Observable, of, Subject } from 'rxjs';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';

@Component({
  selector: 'app-manage-forecast',
  templateUrl: './manage-forecast.component.html',
  styleUrls: ['./manage-forecast.component.scss']
})
export class ManageForecastComponent implements OnInit, AfterViewInit, OnDestroy {
  @Output() updatedManage = new EventEmitter();
  removeStyle;
  public searchInput;
  searchData;
  constructor(private services: AppService, private forecastLineService: ForecastLineService) {}
  ngOnInit() {
    // // tslint:disable-next-line:no-string-literal
    // document.querySelector('.li-bottom ul')['style'].visibility = 'hidden';
    // // tslint:disable-next-line:no-string-literal
    // document.querySelector('.li-bottom .Arrow-top')['style'].visibility = 'hidden';
    // this.removeStyle = document.querySelector('.left-nav-li  a');
    // this.removeStyle.classList.add('removeHover');
  }
  ngAfterViewInit() {
  this.searchData = this.searchInput;
  this.forecastLineService.setSearchText(this.searchInput);
  }
  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      switchMap(term =>
        this.services.search(term).pipe(
          catchError(() => {
            return of([]);
          }))
      )
    )
  public onClear(event: any) {
    if ((event.target as HTMLInputElement).value === '') {
      this.searchInput = '';
      this.onSearchData();
    }
  }
  public onSearchData() {
    this.searchData = this.searchInput;
    this.forecastLineService.setSearchText(this.searchData);
  }
  selected(item) {
    this.searchInput = item.item;
    this.onSearchData();
  }
  onUpdate(event) {}
  ngOnDestroy() {
    this.forecastLineService.setSearchText('');
    // tslint:disable-next-line:no-string-literal
    // document.querySelector('.li-bottom ul')['style'].visibility = 'visible';
    // // tslint:disable-next-line:no-string-literal
    // document.querySelector('.li-bottom .Arrow-top')['style'].visibility = 'visible';
    // this.removeStyle.classList.remove('removeHover');
  }
}
