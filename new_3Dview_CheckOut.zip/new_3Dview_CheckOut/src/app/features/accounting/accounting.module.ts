import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ForecastTabsComponent } from './forecast-tabs/forecast-tabs.component';
import { ToastModule } from 'primeng/toast';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { UploadForecastComponent } from './upload-forecast/upload-forecast.component';
import { ManageForecastComponent } from './manage-forecast/manage-forecast.component';
import { TableAccountingComponent } from './table-accounting/table-accounting.component';
import { FormsModule } from '@angular/forms';
import { TableManageComponent } from './table-manage/table-manage.component';
import { ActionComponent } from './action/action.component';

export const routes: Routes = [{ path: '', component: ForecastTabsComponent }];
@NgModule({
  declarations: [ ForecastTabsComponent, UploadForecastComponent, ManageForecastComponent,
     TableAccountingComponent, TableManageComponent, ActionComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    NgbModule,
    FormsModule,
    ToastModule
  ],
   exports: [
    RouterModule
  ],
   entryComponents: [UploadForecastComponent, ManageForecastComponent]
})
export class AccountingModule { }
