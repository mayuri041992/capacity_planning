import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter, AfterViewInit } from '@angular/core';
import * as XLSX from 'ts-xlsx';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { AppService } from '../../../core/services/app-service/app.service';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';

@Component({
  selector: 'app-upload-forecast',
  templateUrl: './upload-forecast.component.html',
  styleUrls: ['./upload-forecast.component.scss']
})
export class UploadForecastComponent implements OnInit, AfterViewInit {
  // removeStyle;
  cancelTable = true;
  fileData = null;
  fileName = 'No file chosen';
  arrayBuffer: any;
  public showActionComponent = false;
  public showButton: boolean;
  public failed = false;
  public success = false;
  public showValidMsg: boolean;
  uploadData = new Subject<{ fileType: string, data: object[] }>();
  uploadDataStat = { success: { count: 0, data: [] }, failed: { count: 0, data: [] }};
  @ViewChild('fileStatusModal') fileStatusModal: ElementRef;
  @ViewChild('fileUpload') fileUpload: ElementRef;
  successMessage: string;
  dangerMessage: string;

  constructor(private modalService: NgbModal, private forecastLineService: ForecastLineService, private services: AppService) {
    this.uploadData.subscribe((uploadData) => {
      this.validateUploadData(uploadData);
      // tslint:disable-next-line:no-string-literal
      this.uploadDataStat.success.data = uploadData.data.filter(_ => _['status'] === 'success');
      this.uploadDataStat.success.count = this.uploadDataStat.success.data.length;
      // tslint:disable-next-line:no-string-literal
      this.uploadDataStat.failed.data = uploadData.data.filter(_ => _['status'] === 'failed');
      this.uploadDataStat.failed.count = this.uploadDataStat.failed.data.length;
      this.modalService.open(this.fileStatusModal);
      this.cancelTable = true;
    });
  }

  ngOnInit() {
    this.forecastLineService._success.subscribe((message) => this.successMessage = message);
    this.forecastLineService._success.pipe(debounceTime(2000)).subscribe(() => this.successMessage = null);
    this.forecastLineService._danger.subscribe((message) => this.dangerMessage = message);
    this.forecastLineService._danger.pipe(debounceTime(2000)).subscribe(() => this.dangerMessage = null);
    // // tslint:disable-next-line:no-string-literal
    // document.querySelector('.li-bottom ul')['style'].visibility = 'hidden';
    // // tslint:disable-next-line:no-string-literal
    // document.querySelector('.li-bottom .Arrow-top')['style'].visibility = 'hidden';
    // this.removeStyle = document.querySelector('.left-nav-li  a');
    // this.removeStyle.classList.add('removeHover');
  }
  ngAfterViewInit() { }

  validateUploadData(uploadData): object[] {
    if (uploadData.fileType === 'xlsx' || uploadData.fileType === 'xls' || uploadData.fileType === 'csv') {
      uploadData.data = this.validateXLSX(uploadData.data);
      return uploadData.data;
    }
    // if (uploadData.fileType === 'csv') {
    //   uploadData.data = this.validateCSV(uploadData.data);
    // }
  }

  validateCSV(uploadJSON: object[]) {
    const code = '1141 Code';
    const site = 'Site Name';
    return uploadJSON.map((json) => {
      let dataStatusObject = { ...json, status: 'success' };
      if (((json['1141 Code'] === 0 || '') && (json['Site Name'] === 0 || ''))) {
        dataStatusObject = { ...json, status: 'failed' };
        return dataStatusObject;
      }
      let jsonKeys = Object.keys(json);
      // remove 1141 code
      jsonKeys.indexOf(code) !== -1 ?
        (jsonKeys.splice(jsonKeys.indexOf(code), 1))
        : (jsonKeys = jsonKeys);
      // remove Site name
      jsonKeys.indexOf(site) !== -1 ?
        (jsonKeys.splice(jsonKeys.indexOf(site), 1))
        : (jsonKeys = jsonKeys);
      let allValuesAvail = jsonKeys.length !== 0 ? true : false;
      if (allValuesAvail) {
        allValuesAvail = jsonKeys.every((key) => !isNaN(json[key]) && Number.isInteger(json[key]));
        dataStatusObject = allValuesAvail ? { ...json, status: 'success' } : { ...json, status: 'failed' };
      } else {
        dataStatusObject = { ...json, status: 'failed' };
      }
      return dataStatusObject;
    });
  }

  validateXLSX(uploadJSON: object[]) {
    const code = '1141 Code';
    const site = 'Site Name';
    return uploadJSON.map((json) => {
      let dataStatusObject = { ...json, status: 'success' };
      if (!(json['1141 Code'] || json['Site Name'])) {
        dataStatusObject = { ...json, status: 'failed' };
        return dataStatusObject;
      }
      // check all keys
      let jsonKeys = Object.keys(json);
      // remove 1141 code
      jsonKeys.indexOf(code) !== -1 ?
        (jsonKeys.splice(jsonKeys.indexOf(code), 1))
        : (jsonKeys = jsonKeys);

      // remove Site name
      jsonKeys.indexOf(site) !== -1 ?
        (jsonKeys.splice(jsonKeys.indexOf(site), 1))
        : (jsonKeys = jsonKeys);
      let allValuesAvail = jsonKeys.length !== 0 ? true : false;
      if (allValuesAvail) {
        allValuesAvail = jsonKeys.every((key) => !isNaN(json[key]));
        dataStatusObject = allValuesAvail ? { ...json, status: 'success' } : { ...json, status: 'failed' };
      } else {
        dataStatusObject = { ...json, status: 'failed' };
      }
      return dataStatusObject;
    });
  }
  incomingfile(event) {
    this.fileData = event.target.files[0];
    const inputValue = (document.getElementById('file-upload') as HTMLInputElement).value;
    this.fileName = (inputValue.split('\\')).pop();
  }

  Upload() {
    if (this.fileName !== 'No file chosen') {
      const fileReader = new FileReader();
      fileReader.onload = (e) => {
        this.processFile(fileReader);
      };
      fileReader.readAsArrayBuffer(this.fileData);
    }
  }

  processFile(fileReader: FileReader) {
    this.arrayBuffer = fileReader.result;
    const data = new Uint8Array(this.arrayBuffer);
    const arr = new Array();
    for (let i = 0; i !== data.length; ++i) {
      arr[i] = String.fromCharCode(data[i]);
    }
    // tslint:disable-next-line:quotemark
    const bstr = arr.join("");
    const workbook = XLSX.read(bstr, { type: 'binary'});
    const firstSheetName = workbook.SheetNames[0];
    const firstWorkSheet = workbook.Sheets[firstSheetName];
    const uploadJSON = XLSX.utils.sheet_to_json(firstWorkSheet, { raw: true });
    // const headerKey =  ['Site Name', '1141 Code', 'FastE forecast', 'GigE forecast', 'HE 10G forecast', 'BB 10G forecast'];
    // tslint:disable-next-line:max-line-length
    const headerKey =  ['Site Name', '1141 Code', 'FastE Ethernet', 'GigE Ethernet', '10G Ethernet', '10G Broadband', '10G WMC', '10G WMC-Apollo', '10G WMC-TEF', '10G HE', '10G Backhaul', '10G PRTC'];
    const keys  = Object.keys(uploadJSON[0]);
    this.showValidMsg = true;
    keys.forEach((da) => {
      if (headerKey.indexOf(da) === -1) {
        this.showValidMsg = false;
      }
    });

    // console.log(this.showValidMsg);
   // console.log(uploadJSON);
    const ext = this.fileData.name.split('.').pop();
    if (ext === 'csv' || ext === 'xlsx' || ext === 'xls')  {
      this.uploadData.next({ fileType: ext, data: uploadJSON });
      }
  }

  seeResultOnGrid(status) {
    // tslint:disable-next-line:object-literal-shorthand
    this.forecastLineService.settableData({ status: status, data: this.uploadDataStat[status].data });
    this.showActionComponent = true;
    this.modalService.dismissAll();
    if (status === 'success') {
      this.failed = true;
      this.success = false;
    } else {
      this.failed = false;
      this.success = true;
    }
    this.showButton = true;
  }
  onSubmit(event: any) {
    this.removeChooseFile(event);
    this.showButton = event;
    this.fileData = {};
    // this.dateUpdated = '09 july,2019';
    // this.einUpdated = '8888828'
  }

  onCancel(event: any) {
    this.removeChooseFile(event);
    this.cancelTable = event;
  }
  modelCancel(event: any) {
    this.removeChooseFile(event);
    this.cancelTable = false;
    this.modalService.dismissAll();
  }
  onDownClick() {
    this.services.DownloadXLSX();
  }
  removeChooseFile(event: any) {
    const fileUploadELem: HTMLInputElement = this.fileUpload.nativeElement;
    fileUploadELem.value = '';
    // tslint:disable-next-line:quotemark
    const eventJS = document.createEvent("UIEvents");
    // tslint:disable-next-line:quotemark
    eventJS.initUIEvent("change", true, true, window, 1);
    fileUploadELem.dispatchEvent(eventJS);
    this.fileName = 'No file chosen';
  }
  // ngOnDestroy() {
  //   // // tslint:disable-next-line:no-string-literal
  //   // document.querySelector('.li-bottom ul')['style'].visibility = 'visible';
  //   // // tslint:disable-next-line:no-string-literal
  //   // document.querySelector('.li-bottom .Arrow-top')['style'].visibility = 'visible';
  //   // this.removeStyle.classList.remove('removeHover');
  // }
}

