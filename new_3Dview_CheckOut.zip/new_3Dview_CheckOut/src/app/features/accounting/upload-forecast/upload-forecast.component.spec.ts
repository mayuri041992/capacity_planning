import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit, Output, EventEmitter, Input, AfterViewInit, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Subject, of } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { AppService } from '../../../core/services/app-service/app.service';
import { ForecastLineService } from '../../../core/services/product-line-forecast-service/product-line-forecast.service';
import { UploadForecastComponent } from './upload-forecast.component';
import { HttpClient, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MessageService } from 'primeng/api';

describe('UploadForecastComponent', () => {
  let component: UploadForecastComponent;
 // let forecastLineService: ForecastLineService;
  let fixture: ComponentFixture<UploadForecastComponent>;
  const fileReader = new FileReader();
  const mockData = { "fileType": "csv", "data": [{ "1141 Code": "AA", "Site Name": "ABERDARE", "FastE forecast": 0, "GigE forecast": 46, "HE 10G forecast": 24, "BB 10G forecast": 33, "status": "success" }] } 
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgbModule, HttpClientTestingModule],
      declarations: [UploadForecastComponent],
      providers: [AppService, MessageService, ForecastLineService, NgbModal],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadForecastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
   // component.uploadData = new Subject<{ fileType: string, data: object[] }>();
  });

  it('should create', () => {
    // spyOn(forecastLineService, '_success').and.callFake(() => {
    //   return {
    //     then: (resolve, reject)  => resolve('some data')
    //   };
    // });
    const forecastLineService = fixture.debugElement.injector.get(ForecastLineService);

    forecastLineService._success.next('some data');
    spyOn(forecastLineService, '_success').and.returnValue(of('some data'));
    // component.uploadData.subscribe( data =>  expect(data).toEqual({fileType: 'cst', data: [] }));
    // expect(component.options.animation.onComplete).toHaveBeenCalled();
    forecastLineService._danger.next('some data');
    spyOn(forecastLineService, '_danger').and.returnValue(of('some data'));
    expect(component).toBeTruthy();
    component.uploadData.next(mockData);
    spyOn(component, 'uploadData').and.returnValue(of(JSON.parse(JSON.stringify(mockData))));
   // expect(component.uploadData).toHaveBeenCalled();
  });


  it('should check the onCancel()', () => {
    expect(component.onCancel(event)).toBeFalsy();
  });

  it('should check the onDownClick()', () => {
    expect(component.onDownClick()).toBeFalsy();
  });

  // it('should check the ngOnDestroy()', () => {
  //   expect(component.ngOnDestroy()).toBeDefined();
  // });
  it('should check the seeResultOnGrid()', () => {


    component.uploadDataStat = { success: { count: 0, data: [] }, failed: { count: 0, data: [] } };
    component.seeResultOnGrid('success');
    expect(component.seeResultOnGrid).toBeDefined();
  });

  it('should check the seeResultOnGridElse()', () => {

    component.uploadDataStat = { success: { count: 0, data: [] }, failed: { count: 0, data: [] } };
    component.seeResultOnGrid('failed');
    expect(component.seeResultOnGrid).toBeDefined();
  });
  it('should check the Upload()', () => {
    const fileName = 'No file chosen11';
    // tslint:disable-next-line:no-shadowed-variable
    const fileReader = new FileReader();
    fileReader.onload =  () => {
      component.processFile(fileReader);
    };
    // component.processFile(fileReader);
    expect(component.processFile).toBeDefined();


    // component.Upload();
    // expect(component.Upload).toBeDefined();
  });
  it('should check the Upload()', () => {
    const fileName = 'No file chosen11';
    component.Upload();
    expect(component.Upload).toBeDefined();
  });

  // it('should check the incomingfile()', () => {
  //   const event = {
  //     target: {
  //       files: ['sdf', 'wes']
  //     }
  //   };
  //   expect(component.incomingfile(event)).toBeFalsy();
  // });

  it('should check the validateXLSX()', () => {
    const uploadJSON = [{ '1141 Code': 'BSE/K' },
    { 'BB 10G forecast': '13866' },
    { 'FastE forecast': '1256' },
    { 'GigE forecast': '14155' },
    { 'HE 10G forecast': '15966' },
    { 'Site Name': 'BRYNMAWR' },
    { id: 10273 }];
    component.validateXLSX(uploadJSON);
    expect(component.validateXLSX).toBeDefined();
  });
  it('should check the validateXLSX() ? condition', () => {
    const uploadJSON = [{ '1141 Code': 'BSE/K' },
    { 'BB 10G forecast': '13866' },
    { 'FastE forecast': '1256' },
    { 'GigE forecast': '14155' },
    { 'HE 10G forecast': '15966' },
    { 'Site Name': '0' }];
    component.validateXLSX(uploadJSON);
    expect(component.validateXLSX).toBeDefined();
  });

  it('should check the validateXLSX() ? condition for length>0 ', () => {
    const uploadJSON = [{ '1141 Code': 'BSE/K',
     'BB 10G forecast': '13866' ,
     'FastE forecast': '1256' ,
     'GigE forecast': '14155' ,
     'HE 10G forecast': '15966' ,
     'Site Name': '0' }];
    const json = {'1141 Code': 'ABW/K', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
    'FastE forecast': 10, status: 'success'};
    const jsonKeys = Object.keys(json);
    component.validateXLSX(uploadJSON);
    expect(component.validateXLSX).toBeDefined();
  });
  it('should check the validateXLSX() ? condition for length>0 ', () => {
    const uploadJSON = [{ '1141 Code': 'BSE/K',
     'BB 10G forecast': '13866' ,
     'FastE forecast': '1256' ,
     'GigE forecast': '14155' ,
     'HE 10G forecast': '15966' ,
     'Site Name': '0' }];
    const json = {'1141 Code': '', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 'a', 'BB 10G forecast': 'b',
     'FastE forecast': 'c', };
    const jsonKeys = Object.keys(json);
    component.validateXLSX(uploadJSON);
    expect(component.validateXLSX).toBeDefined();
  });
  it('should check the validateCSV()', () => {
    const uploadJSON = [{ '1141 Code': 'BSE/K' },
     {'BB 10G forecast': '13866'} ,
     {'FastE forecast': '1256' },
     {'GigE forecast': '14155' },
     {'HE 10G forecast': '15966'} ,
    {'Site Name': '0'} ,
    { id: 10273 }];
    component.validateCSV(uploadJSON);
    expect(component.validateCSV).toBeDefined();
  });
  it('should check the validateCSV() ? condition', () => {
    const uploadJSON = [{ '1141 Code': 0 },
    { 'BB 10G forecast': '13866' },
    { 'FastE forecast': '1256' },
    { 'GigE forecast': '14155' },
    { 'HE 10G forecast': '15966' },
    { 'Site Name': 0 },
    { id: 10273 }];
    component.validateCSV(uploadJSON);
    expect(component.validateCSV).toBeDefined();
  });

  it('should check the validateCSV() ? condition 000', () => {
    const uploadJSON = [
      { '1141 Code': 0, 'Site Name': 0, 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
      'FastE forecast': 10 }];
    const json = {'1141 Code': 'ABW/K', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
      'FastE forecast': 10, status: 'success'};
    const jsonKeys = Object.keys(json);
    component.validateCSV(uploadJSON);
    expect(component.validateCSV).toBeDefined();
  });
  it('should check the validateCSV() ? condition 000', () => {
    const uploadJSON = [
      { '1141 Code': 'ABW/K', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
      'FastE forecast': 10 }];
    const json = {'1141 Code': 'ABW/K', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
      'FastE forecast': 10, status: 'success'};
    const jsonKeys = Object.keys(json);
   // console.log(jsonKeys);
    component.validateCSV(uploadJSON);
    expect(component.validateCSV).toBeDefined();
  });
  it('should check the validateUploadData() for xlsx', () => {
    const uploadData = { fileType: 'xlsx' ,
    data: [
      { '1141 Code': 'ABW/K', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
      'FastE forecast': 10 }]
    };
    component.validateUploadData(uploadData);
    component.validateXLSX(uploadData.data);
    expect(component.validateUploadData).toBeDefined();
  });
  it('should check the validateUploadData() for xls', () => {
    const uploadData = { fileType: 'xls',
    data: [
      { '1141 Code': 'ABW/K', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
      'FastE forecast': 10 }] };
    component.validateUploadData(uploadData);
    component.validateXLSX(uploadData.data);
    expect(component.validateUploadData).toBeDefined();
  });
  it('should check the validateUploadData() for csv', () => {
    const uploadData = { fileType: 'csv' ,
    data: [
      { '1141 Code': 'ABW/K', 'Site Name': '', 'GigE forecast': '', 'HE 10G forecast': 20, 'BB 10G forecast': 100,
      'FastE forecast': 10 }]
  };
    component.validateUploadData(uploadData);
    component.validateXLSX(uploadData.data);
    expect(component.validateUploadData).toBeDefined();
  });

  it('should check the onSubmit()', () => {
    const event = {
      target: {
        files: ['sdf', 'wes']
      }
    };
    component.onSubmit(event);
    expect(component.onSubmit).toBeDefined();
  });

  // it('should check the processFile()', () => {
  //   // tslint:disable-next-line:no-shadowed-variable
  //   let fileReader = new FileReader();
  //   const ext = 'xlxs';
  //   // fileReader.onload =  () => {
  //   //   component.processFile(fileReader);
  //   // };
  //   fileReader = {...fileReader };
  //   component.processFile(fileReader);
  //   expect(component.processFile).toBeDefined();
  // });
  it('should check the onSubmit()', () => {
    component.ngOnInit();
    expect(component.ngOnInit).toBeDefined();
  });
  it('should check the modelCancel()', () => {
    const modalService =  TestBed.get(NgbModal);
    spyOn (modalService, 'dismissAll').and.callThrough();
    component.modelCancel(event);
    expect(modalService.dismissAll).toHaveBeenCalled();
  });
});

