import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogoutComponent } from './shared/components/logout/logout.component';
import { AccessGurad } from './core/access-guards/access-guard';
import { DashboardCapacityComponent } from './components/dashboard-capacity/dashboard-capacity.component';
import { DetailedSiteComponent } from './components/detailed-site/detailed-site.component';
import { DiversityReportComponent } from './components/divercity-report/divercity-report.component';
import { ChassisViewComponent } from './components/chassis-view/chassis-view.component';


const routes: Routes = [
    { path: '', redirectTo: 'srimsCapacityPlanning', pathMatch: 'full'},
    { path: 'srimsCapacityPlanning', redirectTo: 'dashboard', pathMatch: 'full'},
    { path: 'logout', component: LogoutComponent},
    { path: 'forecast', loadChildren: './features/accounting/accounting.module#AccountingModule',
     canActivate: [AccessGurad]},
    { path: 'dashboard',
      loadChildren: './components/capacity-planning.module#CapacityPlanningModule',
      canActivate: [AccessGurad]
    },
    { path: 'capacity-dashboard', component: DashboardCapacityComponent },
    { path: 'siteDetails', component: DetailedSiteComponent },
    { path: 'diversity', component: DiversityReportComponent},
    { path: 'chassisView', component: ChassisViewComponent },
    ];

@NgModule({
imports: [RouterModule.forRoot(routes, { useHash: true, onSameUrlNavigation: 'reload'})],
exports: [RouterModule]
})
export class AppRoutingModule { }
